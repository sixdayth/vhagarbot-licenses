// cdp-read.js — อ่านสถานะกระเป๋า/Zen จากหน้าเกม (อ่านอย่างเดียว)
// ใช้: node cdp-read.js [js-expression]  (ไม่ใส่ = ใช้ค่า default ด้านล่าง)
const fs = require('fs');
const path = require('path');
const t = fs.readFileSync(path.join(__dirname, 'profiles', 'Caelmora-1', 'DevToolsActivePort'), 'utf8').split(/\r?\n/);
const PORT = t[0].trim(), BR = t[1].trim();

const DEF = `(function(){
  var S = window.S, byId = {}, orbSlots = [];
  try { S.panels.inv.forEach(function (v, k) {
    if (!v || v.id == null) return;
    byId[v.id] = (byId[v.id] || 0) + (v.dur || v.n || 1);
    if ([11778, 11779, 11781, 11782, 11784].indexOf(v.id) >= 0) orbSlots.push(k + ':' + v.id + 'x' + (v.dur || v.n));
  }); } catch (e) {}
  var names = {};
  [11778, 11779, 11781, 11782, 11784].forEach(function (i) {
    try { var d = S.items[i]; if (d) names[i] = (d.name && d.name[1]) || String(i); } catch (e) {}
  });
  var bagUsed = 0; try { S.panels.inv.forEach(function (v, k) { if (v && v.id != null && k >= ((S.bagCfg && S.bagCfg.first) || 0)) bagUsed++; }); } catch (e) {}
  return JSON.stringify({ zen: S.me.zen, map: S.info.map, bagUsed: bagUsed, orbTotals: byId, orbSlotsLeft: orbSlots, names: names });
})()`;

const EXPR = process.argv[2] || DEF;
let id = 0; const waiters = {};
const ws = new WebSocket(`ws://127.0.0.1:${PORT}${BR}`);
ws.addEventListener('message', (ev) => { const o = JSON.parse(ev.data); if (o.id && waiters[o.id]) { const x = waiters[o.id]; delete waiters[o.id]; o.error ? x.rej(new Error(JSON.stringify(o.error))) : x.res(o.result); } });
const send = (m, p, s) => new Promise((res, rej) => { const mid = ++id; waiters[mid] = { res, rej }; ws.send(JSON.stringify({ id: mid, method: m, params: p || {}, sessionId: s })); });

(async () => {
  await new Promise((res, rej) => { ws.addEventListener('open', res); ws.addEventListener('error', rej); });
  const list = await (await fetch(`http://127.0.0.1:${PORT}/json/list`)).json();
  const pg = list.filter((x) => x.type === 'page' && /caelmora/.test(x.url))[0];
  if (!pg) { console.log('ไม่เจอแท็บเกม'); process.exit(1); }
  const a = await send('Target.attachToTarget', { targetId: pg.id, flatten: true });
  const sid = a.sessionId;
  await send('Runtime.enable', {}, sid);
  const r = await send('Runtime.evaluate', { expression: EXPR, returnByValue: true }, sid);
  let v = r && r.result ? r.result.value : null;
  if (r && r.exceptionDetails) console.log('JS ERROR', JSON.stringify(r.exceptionDetails).slice(0, 300));
  else { try { console.log(JSON.stringify(JSON.parse(v), null, 1)); } catch (e) { console.log(v); } }
  ws.close(); process.exit(0);
})().catch((e) => { console.error('ERR', e.message); process.exit(1); });
