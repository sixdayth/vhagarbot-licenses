// ============================================================
//  updater.js — ระบบอัปเดตตัวเองของ CaelmoraBot (โหมดโฟลเดอร์ / node)
// ------------------------------------------------------------
//  หลักการทำงาน (ฝั่งเครื่องเพื่อน — เพื่อนไม่ต้องกดอะไรเลย)
//   1) ตอนเปิดบอท + ทุก ๆ 30 นาที → ดึง version.json จาก GitHub
//      รูปแบบ { "latest": "0.1.1", "url": "<ลิงก์ zip>", "notes": "..." }
//   2) ถ้าเวอร์ชันใหม่กว่า → รอ "จังหวะปลอดภัย" (ตัวละครอยู่ในเมือง, ไม่ได้เดินทาง,
//      ไม่ได้ฟาร์ม, วงวน Voyage ปิดอยู่) แล้วค่อยอัปเดต — กำลังตีบอสอยู่ไม่ขาด
//   3) โหลด zip → แตกไฟล์ → ทับเฉพาะไฟล์โค้ด
//      ❗ ไม่แตะ config.json / profiles / logs / node_modules / start.bat เด็ดขาด
//   4) config.json จะถูก "รวมค่า": ค่าที่เพื่อนตั้งไว้คงเดิม + ค่าใหม่ของเวอร์ชันใหม่
//   5) เขียนไฟล์ .restart แล้วปิดตัวเอง → start.bat จะเปิด node ใหม่ให้เอง
//
//  กันวนลูป: .update-marker.json จำไว้ว่าอัปเดตเป็นเวอร์ชันอะไรไปแล้ว
//            ถ้าพัง 3 ครั้งติดกันจะหยุดพยายามเอง (ต้องแก้ manual)
// ============================================================
'use strict';
const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');
const { spawnSync } = require('child_process');
const buildinfo = require('./buildinfo');

const APP_DIR = process.pkg ? path.dirname(process.execPath) : __dirname;
const MARKER_FILE = path.join(APP_DIR, '.update-marker.json');
const RESTART_FLAG = path.join(APP_DIR, '.restart');
const TMP_DIR = path.join(APP_DIR, '.update');

// ---------- สิ่งที่ไม่ให้ทับเด็ดขาด (ข้อมูลของเพื่อนเอง) ----------
const KEEP_FILES = new Set(['config.json', 'start.bat', 'github-token.txt', '.license-cache.json', '.device-id', '.update-marker.json', 'licenses.json', '.restart']);
const KEEP_DIRS = new Set(['profiles', 'logs', 'dash-app', 'node_modules', '.update', '.git', '.trash', '.publish']);

const MAX_FAIL = 3;
const st = {
  enabled: !!buildinfo.autoUpdate,
  current: buildinfo.version || '0.0.0',
  latest: null, available: false, notes: '', zipUrl: '',
  phase: 'idle', // idle|dev|checking|uptodate|available|waiting-safe|downloading|installing|restarting|error
  msg: '', at: Date.now(), fail: 0, nextTry: 0,
};
function setPhase(p, m) { st.phase = p; st.msg = m || ''; st.at = Date.now(); return st; }

// ---------- ของพื้นฐาน ----------
function log(m) { console.log('[update] ' + m); }

function get(url, timeoutMs = 12000) {
  return new Promise((resolve, reject) => {
    const mod = url.startsWith('https') ? https : http;
    const req = mod.get(url, { timeout: timeoutMs, headers: { 'Cache-Control': 'no-cache', 'User-Agent': 'CaelmoraBot' } }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) { res.resume(); return get(res.headers.location, timeoutMs).then(resolve, reject); }
      if (res.statusCode !== 200) { res.resume(); return reject(new Error('HTTP ' + res.statusCode)); }
      const chunks = []; let n = 0;
      res.on('data', (c) => { n += c.length; if (n > 6e7) { req.destroy(); reject(new Error('ไฟล์ใหญ่ผิดปกติ')); } else chunks.push(c); });
      res.on('end', () => resolve(Buffer.concat(chunks)));
    });
    req.on('error', reject);
    req.on('timeout', () => req.destroy(new Error('timeout')));
  });
}
async function getJson(url) { return JSON.parse((await get(url)).toString('utf8')); }

// เทียบเวอร์ชัน a.b.c
function isNewer(latest, current) {
  const a = String(latest).split('.').map((x) => parseInt(x, 10) || 0);
  const b = String(current).split('.').map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < 3; i++) { const d = (a[i] || 0) - (b[i] || 0); if (d > 0) return true; if (d < 0) return false; }
  return false;
}

function readMarker() { try { return JSON.parse(fs.readFileSync(MARKER_FILE, 'utf8')); } catch (e) { return null; } }
function writeMarker(o) { try { fs.writeFileSync(MARKER_FILE, JSON.stringify(o)); } catch (e) {} }

function rmrf(p) { try { fs.rmSync(p, { recursive: true, force: true }); } catch (e) {} }

// ---------- รวม config: ค่าเพื่อนชนะ, ค่าใหม่ที่ถูกเพิ่มเข้ามาจะได้ไป ----------
function mergeConfig(base, over) {
  // base = config.json จากเวอร์ชันใหม่ | over = config.json ที่เพื่อนใช้อยู่
  if (Array.isArray(base) && Array.isArray(over)) {
    const out = [];
    for (let i = 0; i < Math.max(base.length, over.length); i++) {
      if (i >= base.length) out.push(over[i]);
      else if (i >= over.length) out.push(base[i]);
      else out.push(mergeConfig(base[i], over[i]));
    }
    return out;
  }
  if (base && typeof base === 'object' && !Array.isArray(base) && over && typeof over === 'object' && !Array.isArray(over)) {
    const out = {};
    for (const k of Object.keys(base)) out[k] = (k.charAt(0) === '_' || over[k] === undefined) ? base[k] : mergeConfig(base[k], over[k]);
    for (const k of Object.keys(over)) if (!(k in base)) out[k] = over[k];
    return out;
  }
  return over === undefined ? base : over;
}

// ---------- คัดลอกไฟล์จากโฟลเดอร์ที่แตก zip มาทับ (ข้ามของห้ามแตะ) ----------
function collect(dir, rel, out) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const r = rel ? rel + '/' + e.name : e.name;
    if (e.isDirectory()) { if (!KEEP_DIRS.has(e.name)) collect(path.join(dir, e.name), r, out); }
    else out.push(r);
  }
  return out;
}
function installFiles(srcRoot) {
  const list = collect(srcRoot, '', []);
  const copied = [];
  for (const rel of list) {
    const name = rel.split('/').pop();
    if (KEEP_FILES.has(name) || KEEP_DIRS.has(rel.split('/')[0])) continue;
    const dst = path.join(APP_DIR, rel);
    fs.mkdirSync(path.dirname(dst), { recursive: true });
    fs.copyFileSync(path.join(srcRoot, rel), dst);
    copied.push(rel);
  }
  return copied;
}

// ---------- ขั้นตอนหลัก ----------
async function check(force) {
  if (!st.enabled) return setPhase('dev', 'โหมด dev — ไม่อัปเดตตัวเอง (เครื่องนี้เป็นต้นฉบับ)');
  const now = Date.now();
  if (!force && now < st.nextTry) return st;
  setPhase('checking', 'กำลังเช็กเวอร์ชันใหม่...');
  let doc;
  try { doc = await getJson(buildinfo.updateUrl); }
  catch (e) {
    st.fail++; st.nextTry = now + 5 * 60000;
    return setPhase('error', 'เช็กเวอร์ชันไม่สำเร็จ (' + e.message + ') — ครั้งที่ ' + st.fail + '/' + MAX_FAIL);
  }
  st.fail = 0;
  st.latest = doc.latest || '0.0.0';
  st.zipUrl = doc.url || '';
  st.notes = doc.notes || '';
  const mk = readMarker();
  const already = !!(mk && mk.applied === st.latest); // ติดตั้งเวอร์ชันนี้ไปแล้ว → ไม่ทำซ้ำ (กันวนลูป)
  st.available = !already && !!st.zipUrl && isNewer(st.latest, st.current);
  if (!st.available) return setPhase('uptodate', already ? ('อัปเดตเป็น v' + st.latest + ' เรียบร้อยแล้ว') : ('เป็นเวอร์ชันล่าสุด v' + st.current + ' แล้ว'));
  return setPhase('available', 'มีเวอร์ชันใหม่ v' + st.latest + ' — กำลังรอจังหวะปลอดภัย');
}

// ติดตั้งจากโฟลเดอร์ที่แตก zip แล้ว: รวม config → ทับโค้ด → npm install ถ้าจำเป็น
// แยกเป็นฟังก์ชันเดียวเพื่อให้ทดสอบได้โดยไม่ต้องต่อเน็ต
function installFrom(srcRoot) {
  const out = { copied: 0, configMerged: false, configMsg: '', npmRan: false, npmMsg: '' };
  // อ่าน "ลายเซ็น dependency" ของเดิมก่อนทับ (ถ้าอ่านทีหลังจะเทียบไม่ได้อีกเลย)
  const depSig = (p) => { try { const j = JSON.parse(fs.readFileSync(p, 'utf8')); return JSON.stringify(j.dependencies || {}); } catch (e) { return ''; } };
  const oldDeps = depSig(path.join(APP_DIR, 'package.json'));

  // 1) รวม config ก่อน (กันค่าที่เพื่อนตั้งไว้หาย)
  try {
    const curCfg = JSON.parse(fs.readFileSync(path.join(APP_DIR, 'config.json'), 'utf8'));
    const newCfg = JSON.parse(fs.readFileSync(path.join(srcRoot, 'config.json'), 'utf8'));
    fs.writeFileSync(path.join(APP_DIR, 'config.json'), JSON.stringify(mergeConfig(newCfg, curCfg), null, 2));
    out.configMerged = true; out.configMsg = 'รวมค่าตั้งใหม่แล้ว';
  } catch (e) { out.configMsg = 'รวม config ไม่สำเร็จ: ' + e.message; }

  // 2) ทับไฟล์โค้ด (ข้ามของห้ามแตะทั้งหมด)
  const copied = installFiles(srcRoot);
  out.copied = copied.length;

  // 3) ถ้า dependency เปลี่ยนจริง → npm install ให้เอง
  //    เทียบจาก package.json ไม่ใช่ package-lock (ล็อกของเพื่อนถูก npm เขียนทับตอนติดตั้งครั้งแรก)
  try {
    const newDeps = depSig(path.join(srcRoot, 'package.json')) || depSig(path.join(APP_DIR, 'package.json'));
    if (oldDeps && newDeps && oldDeps !== newDeps) {
      setPhase('installing', 'กำลังติดตั้ง dependency ใหม่ (npm install) ...');
      const rr = spawnSync('npm', ['install', '--omit=dev', '--no-audit', '--no-fund'], { cwd: APP_DIR, encoding: 'utf8', timeout: 600000, shell: true });
      out.npmRan = true;
      out.npmMsg = rr.status === 0 ? 'dependency เรียบร้อย' : 'npm install ไม่สำเร็จ (code ' + rr.status + ')';
    }
  } catch (e) { out.npmMsg = 'ข้าม npm install: ' + e.message; }
  return out;
}

// ดาวน์โหลด + ติดตั้ง (เรียกเมื่อ "ปลอดภัย" แล้วเท่านั้น)
async function apply() {
  if (!st.available || !st.zipUrl) return { ok: false, msg: 'ไม่มีอะไรต้องอัปเดต' };
  const from = st.current, to = st.latest;
  try {
    setPhase('downloading', 'กำลังดาวน์โหลด v' + to + ' ...');
    rmrf(TMP_DIR); fs.mkdirSync(path.join(TMP_DIR, 'zip'), { recursive: true });
    const zipPath = path.join(TMP_DIR, 'update.zip');
    fs.writeFileSync(zipPath, await get(st.zipUrl, 120000));
    const size = fs.statSync(zipPath).size;
    if (size < 10000) throw new Error('ไฟล์ zip เล็กผิดปกติ (' + size + ' bytes) — อาจโหลดไม่ครบ');
    log('ดาวน์โหลดเสร็จ ' + (size / 1048576).toFixed(1) + ' MB');

    setPhase('installing', 'กำลังแตกไฟล์และติดตั้ง v' + to + ' ...');
    const exDir = path.join(TMP_DIR, 'next');
    const ps = "Expand-Archive -LiteralPath '" + zipPath + "' -DestinationPath '" + exDir + "' -Force";
    const r = spawnSync('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', ps], { encoding: 'utf8', timeout: 120000 });
    if (r.status !== 0) throw new Error('แตกไฟล์ไม่สำเร็จ: ' + (r.stderr || r.stdout || 'code ' + r.status).slice(0, 200));
    const srcRoot = fs.existsSync(path.join(exDir, 'server.js')) ? exDir
      : (fs.readdirSync(exDir).map((d) => path.join(exDir, d)).find((p) => fs.existsSync(path.join(p, 'server.js'))) || null);
    if (!srcRoot) throw new Error('ไม่เจอ server.js ใน zip — ฟอร์มแพ็กไม่ตรงที่คาด');

    const res = installFrom(srcRoot);
    log('ทับไฟล์โค้ด ' + res.copied + ' ไฟล์ · ' + res.configMsg + (res.npmMsg ? ' · ' + res.npmMsg : ''));

    writeMarker({ from, applied: to, at: Date.now() });
    rmrf(TMP_DIR);
    st.available = false;
    const extra = (res.configMerged ? ' (รวมค่าตั้งแล้ว)' : ' ⚠️ ' + res.configMsg) + (res.npmMsg ? ' + ' + res.npmMsg : '');
    setPhase('restarting', 'อัปเดต v' + from + ' → v' + to + ' สำเร็จ' + extra + ' — กำลังเปิดใหม่');
    return { ok: true, msg: st.msg, from, to };
  } catch (e) {
    st.fail++;
    st.nextTry = Date.now() + 10 * 60000;
    setPhase('error', 'อัปเดตล้มเหลว: ' + e.message + ' (ครั้งที่ ' + st.fail + '/' + MAX_FAIL + ')');
    rmrf(TMP_DIR);
    return { ok: false, msg: st.msg };
  }
}

// บอก start.bat ให้เปิด node ใหม่ (เขียนธง .restart แล้ว server จะ exit เอง)
function requestRestart() { try { fs.writeFileSync(RESTART_FLAG, JSON.stringify({ at: Date.now(), to: (readMarker() || {}).applied || st.latest })); return true; } catch (e) { return false; } }

function publicState() {
  return {
    enabled: st.enabled, current: st.current, latest: st.latest, available: st.available,
    phase: st.phase, msg: st.msg, notes: st.notes, at: st.at, fail: st.fail,
    giveUp: st.fail >= MAX_FAIL, applied: (readMarker() || {}).applied || null,
  };
}

module.exports = { check, apply, installFrom, requestRestart, publicState, setPhase, isNewer, mergeConfig, KEEP_FILES, KEEP_DIRS, RESTART_FLAG, MAX_FAIL };
