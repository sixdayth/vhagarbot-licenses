// ============================================================
//  accounts.js — เครื่องยนต์ "หลายบัญชี" ของ VhagarBot (แกนกลาง ไม่ผูกเกม)
// ------------------------------------------------------------
//  1 Account = 1 หน้าต่าง Chrome + 1 โปรไฟล์ (ล็อกอินคนละบัญชีเกม) + ผู้เฝ้าของตัวเอง
//  server.js จะสร้าง Account ตามรายการใน config.accounts[] แล้วรวมสถานะส่งให้แดชบอร์ด
//  ทุกอย่างที่เกี่ยวข้องกับ "ตัวเกม" (อ่านค่า, เดินทาง, ขาย, ซื้อยา, แพ็กเก็ต)
//  อยู่ใน game-adapter.js ทั้งหมด — ไฟล์นี้แค่ "เรียกใช้" ผ่านตัวแปร GAME
//  ★ ทำเกมใหม่ → เปลี่ยนแค่ game-adapter.js ไฟล์เดียว ไม่ต้องแตะไฟล์นี้
// ============================================================
'use strict';
const fs = require('fs');
const path = require('path');
const puppeteer = require('puppeteer-core');
const buildinfo = require('./buildinfo');
const GAME = require('./game-adapter');

const BASE_DIR = process.pkg ? path.dirname(process.execPath) : __dirname;
const PROFILES_ROOT = path.join(BASE_DIR, 'profiles');
const RELEASE = !!buildinfo.release;
const DEV_ONLY = new Set(buildinfo.devOnly || []);
const isDevOnly = (k) => RELEASE && DEV_ONLY.has(k);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ข้อความต้นฉบับของ lootfilter.js — ส่งเข้าหน้าเกมเป็น opts.lfSrc (ไฟล์เดียวใช้ได้ 2 ฝั่ง)
let LF_SRC = '';
try { LF_SRC = fs.readFileSync(path.join(BASE_DIR, 'lootfilter.js'), 'utf8'); } catch (e) { console.log('[lootfilter] ไม่พบ lootfilter.js — โหมดกฎจะปิดตัว'); }
function jitterLoop(fn, baseMs, spread = 0.25) {
  let stopped = false;
  const run = async () => {
    if (stopped) return;
    try { await fn(); } catch (e) {}
    if (stopped) return;
    setTimeout(run, Math.max(200, Math.round(baseMs * (1 + (Math.random() * 2 - 1) * spread))));
  };
  setTimeout(run, Math.round(baseMs));
  return () => { stopped = true; };
}

// 🧭 zoneSlack = "ยอมให้วิ่งเควสในพื้นที่เลเวลสูงกว่าเราได้กี่เลเวล" (ปุ่มบนแดชบอร์ด หน้าตั้งค่าเควส)
//   ค่าเดิม 6 = พฤติกรรมเดียวกับเวอร์ชันก่อน · พิมพ์มั่ว/ค่าว่าง → กลับไป 6 (ห้ามเป็น NaN เด็ดขาด
//   เพราะ area <= Lv + NaN = false ทุกตัว = บอทจะเลิกเลือกเควสไปเลยทั้งที่มีเควสทำได้)
function questZoneSlack(qc) {
  const raw = qc && qc.zoneSlack;
  if (raw === null || raw === undefined || raw === '') return 6; // ยังไม่เคยตั้ง (config เก่า) = ใช้ค่าเดิม
  const v = +raw;
  return isNaN(v) ? 6 : Math.min(30, Math.max(0, v));
}

class Account {
  constructor(cfg, index, gameUrl, viewport, getGlobal, saveFn) {
    this.cfg = cfg;            // { name, enabled, farmMap, role }
    this.index = index;
    this.gameUrl = gameUrl;
    this.viewport = viewport;
    this.getGlobal = getGlobal; // fn() → liveConfig (ค่ารวม)
    this.saveFn = saveFn || (() => {}); // บันทึกลงไฟล์ config
    this.browser = null; this.page = null; this.cdp = null;
    this.timers = [];
    this.logs = []; // บันทึกการทำงาน (timestamped)
    this.gameInfo = { selfId: null, name: cfg.name || null, job: null, lv: null, mapId: null, hp: null, maxHp: null, sp: null, maxSp: 1 };
    this.state = {
      name: cfg.name, enabled: !!cfg.enabled, farmMap: cfg.farmMap || '', role: cfg.role || 'farm',
      connected: false, pageTitle: '', farmOn: false,
      ws: { in: 0, out: 0 }, gameStats: null, traveling: false, travelNote: '',
      lastFarmMap: null, lastError: '', autoWatch: { count: 0 }, potion: { count: 0, lastAt: 0 },
      startedAt: Date.now(), running: false, paused: false,
    };
  }

  get global() { return this.getGlobal(); }
  // settings ต่อบัญชี: ค่ารวม (global) เป็น default, cfg.settings ทับทีละตัว
  S() {
    const g = this.global;
    const s = this.cfg.settings || {};
    const pick = (k) => (s[k] !== undefined ? s[k] : g[k]);
    return {
      humanDelay: pick('humanDelay'), autoPotion: pick('autoPotion'), autoWatch: pick('autoWatch'),
      sellConfig: pick('sellConfig'), autoTown: pick('autoTown'), enterCharacter: pick('enterCharacter'),
      autoFarm: pick('autoFarm'), buyPotion: pick('buyPotion'), autoLogin: pick('autoLogin'), voyFarm: pick('voyFarm'), lootFilter: pick('lootFilter'), worldBoss: pick('worldBoss'), quest: pick('quest'), wsLog: g.wsLog,
    };
  }
  log(msg) {
    this.logs.push({ t: new Date().toLocaleTimeString('th-TH', { hour12: false }), msg });
    if (this.logs.length > 120) this.logs.shift();
  }
  // เตือนแบบไม่ spam: พิมพ์เฉพาะ key เดิมห่างจากครั้งก่อน >= everyMs (ดีฟอลต์ 90 วิ)
  logOnce(key, msg, everyMs) {
    const iv = everyMs || 90000, now = Date.now();
    this._onceAt = this._onceAt || {};
    if (this._onceAt[key] && now - this._onceAt[key] < iv) return false;
    this._onceAt[key] = now; this.log(msg); return true;
  }
  townMaps() { const aw = this.S().autoWatch; return (aw && aw.townMaps) || GAME.TOWN_MAPS; }

  // 🕓 เช็คตารางเกิดบอสแยกชาแนล (หน้าต่าง #bosswin = ปุ่ม L) → คืนชาแนลที่บอสเกิดอยู่ (หรือใกล้เกิดสุด)
  async bossChannel(mapId) {
    if (!this.page) return null;
    try {
      await this.page.keyboard.press('KeyL').catch(() => {});
      await sleep(1300);
      const sc = await this.page.evaluate(GAME.page.bossSchedule).catch(() => null);
      await this.page.keyboard.press('Escape').catch(() => {});
      if (!sc || !sc.ok) return null;
      let pool = [];
      const row = mapId != null ? (sc.rows || []).filter((r) => String(r.map) === String(mapId))[0] : null;
      if (row) pool = row.chs || [];
      if (!pool.length) (sc.rows || []).forEach((r) => { pool = pool.concat(r.chs || []); });
      const up = pool.filter((c) => c.up);
      if (up.length) { up.sort((a, b) => a.ch - b.ch); return { ch: up[0].ch, name: row ? row.name : '', upCount: up.length }; }
      const soon = pool.filter((c) => c.inSec != null).sort((a, b) => a.inSec - b.inSec)[0];
      return soon ? { wait: true, ch: soon.ch, inSec: soon.inSec, name: row ? row.name : '' } : null;
    } catch (e) { return null; }
  }
  async setPause(on) {
    const next = !!on;
    if (this.state.paused === next) return { ok: true, msg: next ? 'พักอยู่ก่อนแล้ว' : 'ไม่ได้พักอยู่' };
    this.state.paused = next;
    if (next) {
      this._lvFarmUntil = 0; this._wb = null; this._cycleBusy = false;
      if (this.page) {
        await this.page.evaluate(GAME.page.voyRoamStop).catch(() => {});
        await this.page.evaluate(GAME.page.lvHuntStop).catch(() => {});
      }
      this.log('⏸ พักบอท — บอทจะไม่ขยับ/ไม่กดสกิล/ไม่กดยา คุณควบคุมเกมได้เอง (กด ▶ เพื่อเล่นต่อ)');
    } else {
      this.log('▶ เล่นต่อ — บอทกลับมารับช่วงเอง');
    }
    return { ok: true, msg: next ? 'พักบอทแล้ว' : 'เล่นต่อแล้ว', paused: next };
  }

  async launch() {
    const exe = ['C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', 'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe', 'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe', 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe'].find((p) => fs.existsSync(p));
    if (!exe) throw new Error('หา Chrome/Edge ไม่เจอ');
    const safeName = (this.cfg.name || ('acct' + this.index)).replace(/[^\w\u0E00-\u0E7F-]/g, '_');
    const userDataDir = path.join(PROFILES_ROOT, safeName);
    if (!fs.existsSync(userDataDir)) fs.mkdirSync(userDataDir, { recursive: true });
    const x = 30 + (this.index % 4) * 40, y = 30 + Math.floor(this.index / 4) * 30;
    const headless = !!this.cfg.headless;
    // ขนาดหน้าต่าง: เดิมบังคับ defaultViewport = ค่า config "ทุกกรณี" → Chrome override device metrics
    //   ให้หน้าเกมเล็กกว่าหน้าต่างจริง แถบล่าง (ปุ่มสกิล/เม็ดเลือด) โดนตัด ต้องลากยืดเองทุกครั้ง
    //   โหมดมีหน้าต่างจึงปล่อย viewport = null ให้ Chrome ใช้ขนาดจริง + เปิดแบบ maximized (บัญชีแรก)
    const winArgs = ['--disable-blink-features=AutomationControlled', '--test-type', '--disable-infobars', '--hide-crash-restore-bubble'];
    if (headless) {
      winArgs.push(`--window-size=${this.viewport.width},${this.viewport.height}`);
    } else if (this.index === 0) {
      winArgs.push('--start-maximized');
    } else {
      winArgs.push(`--window-size=${this.viewport.width},${this.viewport.height}`, `--window-position=${x},${y}`);
    }
    this.browser = await puppeteer.launch({
      executablePath: exe, headless: headless, defaultViewport: headless ? this.viewport : null, userDataDir,
      args: winArgs,
    });
    this.log(headless ? 'เปิดบัญชี (โหมดซ่อนหน้าต่าง/headless)' : 'เปิดบัญชี');
    this.page = (await this.browser.pages())[0] || await this.browser.newPage();
    await this.page.evaluateOnNewDocument(() => { try { Object.defineProperty(navigator, 'webdriver', { get: () => undefined }); } catch (e) {} });
    await this.attachCdp();
    this.page.on('pageerror', (err) => { this.state.lastError = String(err.message).slice(0, 200); });
    // hook สำหรับ adapter: เปิด request interception / patch JS ของเกม / inject script ก่อนโหลดหน้า
    if (typeof GAME.preLaunch === 'function') {
      try { await GAME.preLaunch(this.page, this); } catch (e) { this.log('⚠️ preLaunch: ' + (e.message || e)); }
    }
    try { await this.page.goto(this.gameUrl, { waitUntil: 'domcontentloaded', timeout: 60000 }); this.state.connected = true; }
    catch (e) { this.state.lastError = e.message; }
    if (!headless) {
      // ขยายเต็มจอ "หลังโหลดหน้า" — เรียกตอนเพิ่ง launch แล้ว Chrome ทับด้วยขนาดเดิมจาก session-restore
      await this.maximizeWindow();
      setTimeout(() => { this.maximizeWindow(); }, 1500);
    }
    this.state.running = true;
    this.startWatchers();
    if (this.global.autoFarm && this.global.autoFarm.enabled) this.farmStart();
    return true;
  }

  // ขยายหน้าต่างเกมเต็มจอด้วย CDP: ต้อง "set ขนาดเต็มจอก่อน → ค่อย state:'maximized'"
  // (ส่ง maximize เปล่า ๆ ไม่ขยับ และ --start-maximized ก็ไว้ใจไม่ได้ — ทดสอบจริงทั้งคู่)
  async maximizeWindow() {
    try {
      if (!this.page || !this.page.target) return;
      const cdpW = await this.page.target().createCDPSession();
      const { windowId } = await cdpW.send('Browser.getWindowForTarget');
      const mw = (this.viewport && this.viewport.maxWidth) || 1920;
      const mh = (this.viewport && this.viewport.maxHeight) || 1040;
      await cdpW.send('Browser.setWindowBounds', { windowId, bounds: { left: 0, top: 0, width: mw, height: mh } });
      await new Promise((r) => setTimeout(r, 600));
      await cdpW.send('Browser.setWindowBounds', { windowId, bounds: { state: 'maximized' } });
      await cdpW.detach();
    } catch (e) { this.log('⚠️ ขยายหน้าต่างอัตโนมัติไม่สำเร็จ: ' + (e.message || e)); }
  }

  // ---------- ดักแพ็กเก็ต WebSocket → ให้ adapter ถอดรหัสเป็นค่าผู้เล่น ----------
  async attachCdp() {
    this.cdp = await this.page.createCDPSession();
    await this.cdp.send('Network.enable');
    this.cdp.on('Network.webSocketCreated', () => {});
    const logFrame = (dir, data) => {
      if (RELEASE || this.global.wsLog === false) return;
      // เก็บเฉพาะ frame ข้อความ JSON (Caelmora ใช้ CmLink JSON) — ข้าม binary (MuSocket) + ตัดยาว
      const s = typeof data === 'string' ? data : '';
      if (!s || (s[0] !== '{' && s[0] !== '[')) return;
      try { fs.appendFileSync(path.join(BASE_DIR, 'logs', 'ws-' + this.index + '.jsonl'), JSON.stringify({ t: new Date().toISOString(), dir, len: s.length, data: s.slice(0, 2000) }) + '\n'); } catch (e) {}
    };
    this.cdp.on('Network.webSocketFrameReceived', (ev) => {
      const data = ev.response?.payloadData || '';
      this.state.ws.in++;
      try {
        const gi = GAME.decodeWorldFrame(data);
        if (gi) this.mergeGameInfo(gi);
      } catch (e) {}
      logFrame('in', data);
    });
    this.cdp.on('Network.webSocketFrameSent', (ev) => {
      this.state.ws.out++;
      logFrame('out', ev.response?.payloadData || '');
    });
  }
  mergeGameInfo(gi) {
    const g = this.gameInfo;
    if (!g.selfId && gi.selfId) g.selfId = gi.selfId;
    if (gi.hp != null) g.hp = gi.hp;
    if (gi.sp != null) { g.sp = gi.sp; if (g.sp > g.maxSp) g.maxSp = g.sp; }
    if (gi.mapId) g.mapId = gi.mapId;
    if (gi.maxHp) g.maxHp = gi.maxHp;
    if (gi.name) g.name = gi.name;
    if (gi.job) g.job = gi.job;
    if (gi.lv) g.lv = gi.lv;
  }

  startWatchers() {
    const g = () => this.S();
    // ผู้อ่านค่า + AUTO ยา
    this.timers.push(jitterLoop(async () => {
      if (!this.page) return;
      const s = await this.page.evaluate(GAME.page.readStats).catch(() => null);
      if (!s) return;
      // log ตอนตาย/ฟื้น/เลเวลอัพ/เปลี่ยนแมพ
      const prev = this._lastS || {};
      // 📈 บันทึกเส้นทาง HP (80 ตัวอย่างล่าสุด) ใช้ตอบตอนตายว่า "ร่วงยังไง" ไม่ใช่เดา
      (this._hpTrace = this._hpTrace || []).push({ t: Date.now(), hp: s.hp, maxHp: s.maxHp, sp: s.sp, maxSp: s.maxSp });
      if (this._hpTrace.length > 80) this._hpTrace.shift();
      if (s.dead && !prev.dead) {
        (this._deaths = this._deaths || []).push(Date.now());
        const tr = this._hpTrace.slice(-10);
        const pc = tr.map((x) => (x.maxHp ? Math.round((x.hp / x.maxHp) * 100) : 0));
        const span = tr.length > 1 ? Math.round((Date.now() - tr[0].t) / 1000) : 0;
        const cx = await this.page.evaluate(GAME.page.deathContext).catch(() => null);
        this.log('☠️ ตาย — HP ' + (pc.length ? pc.join('%→') + '%' : '?') + ' (ย้อนหลัง ~' + span + ' วิ)' +
          (cx ? ' · AUTO=' + (cx.autoOn ? 'เปิด' : 'ปิด') + ' · ชาร์จยาเลือด ' + (cx.hpFlask == null ? '?' : cx.hpFlask) + '/' + (cx.hpFlaskMax == null ? '?' : cx.hpFlaskMax + (cx.mpFlask != null ? (' (มานา ' + cx.mpFlask + ')') : '')) + ' · ศัตรูใกล้สุด ' + (cx.enemyDist == null ? '-' : cx.enemyDist) + ' ช่อง · ' + (cx.onIsle ? 'บนเกาะ' : 'map ' + cx.map) : ''));
      }
      if (!s.dead && prev.dead) this.log('✅ ฟื้นแล้ว');
      if (prev.lv != null && s.lv != null && s.lv > prev.lv) this.log('⬆️ เลเวลอัพ → ' + s.lv);
      if (prev.mapId && s.mapId && s.mapId !== prev.mapId) this.log('🧭 ไป ' + (s.zone || s.mapId));
      this._lastS = s;
      this.state.gameStats = s;
      const ap = g().autoPotion;
      if (ap && ap.enabled && !this.state.paused && !s.dead && s.maxHp > 0) {
        const towns = this.townMaps();
        if (!towns.includes(s.mapId)) {
          const ratio = s.hp / s.maxHp, now = Date.now(); let cd;
          if (ratio <= 0.2) cd = 650 + Math.random() * 400; else if (ratio <= 0.35) cd = 1300 + Math.random() * 700; else cd = (ap.cooldownMs ?? 2500) * (0.85 + Math.random() * 0.4);
          // เลือด: ยิงแพ็กเก็ต flask ของเกมจริง (k=0) — เกณฑ์ default 65% (เกมตั้ง autoPotion=70)
          if (ratio <= (ap.threshold ?? 0.65) && now - (this.state.potion.lastAt || 0) > cd) {
            this.state.potion.lastAt = now; this.state.potion.count++;
            const fr = await this.page.evaluate(GAME.page.useFlask, 0).catch(() => null);
            if (fr && fr.noCharge) this.logOnce('flaskHp', '🧪 ชาร์จขวดเลือดหมด (' + (fr.msg || '') + ') — กดยาเลือดไม่ได้ชั่วคราว ชาร์จจะรีเองตอนฆ่ามอน (ไม่ต้องกลับเมือง)');
          }
          // มานา: k=1 — เกณฑ์ default 30% ตามที่เกมตั้ง (autoPotionMp=30)
          const sr = s.maxSp ? (s.sp / s.maxSp) : 1;
          if (sr <= (ap.mpThreshold ?? 0.3) && now - (this._mpPotAt || 0) > 4000) {
            this._mpPotAt = now;
            const fm = await this.page.evaluate(GAME.page.useFlask, 1).catch(() => null);
            if (fm && fm.noCharge) this.logOnce('flaskMp', '🧪 ชาร์จขวดมานาหมด — สกิลจะไม่มีมานาใช้ชั่วคราว ชาร์จจะรีเองตอนฆ่ามอน (ไม่ต้องกลับเมือง)');
          }
        }
      }
    }, 1000, 0.3));
    // ผู้เฝ้า AUTO
    this.timers.push(jitterLoop(async () => {
      const aw = g().autoWatch; if (!aw || aw.enabled === false) return;
      if (this.state.paused) return; // ⏸ พัก = ไม่สั่ง AUTO
      if (this._fRoam && this._fRoam.movingToWp) return; // กำลังเดินไปขึ้นวาร์ป = อย่าเปิด AUTO กลับ (มันจะดึงออกนอกทาง)
      // กันวนลูปตาย: ตาย >=3 ครั้งใน 3 นาที = ไม่ใช่แค่ "ไม่กด AUTO" (บอทจะเดินไปตายต่อ)
      //   แต่ต้องหยุดเดินไปหาบอส → ปิดตัวเดินบนเกาะ → ออกเกาะ → กลับเมือง → พัก 5 นาที
      const now = Date.now();
      this._deaths = (this._deaths || []).filter((t) => now - t < 3 * 60000);
      if (this._deaths.length >= 3) {
        const qc = g().quest || {};
        if (qc.enabled) {
          // เควสนำเลเวล = ตายบ่อย → หยุดเควส แล้วไปฟาร์มมอนที่เลเวลใกล้ตัว/ต่ำกว่าก่อน (ตามที่ผู้ใช้สั่ง)
          //   ⚠️ ต้องยกเลิกงาน "ออกเรือให้เควส" ด้วย ไม่งั้นลูปเรือจะพากลับไปเกาะเดิมแล้วตายซ้ำ
          if (this._qVoy) this.qVoyFail('ตาย 3 ครั้งใน 3 นาที = เกาะนี้แข็งเกิน');
          if (!this._lvFarmUntil || now > this._lvFarmUntil) {
            const slack = (qc.lvSlack == null ? 0 : +qc.lvSlack);
            const mins = Math.max(3, +qc.farmMin || 15);
            await this.page.evaluate(GAME.page.questStop).catch(() => {});
            this._lvFarmUntil = now + mins * 60000;
            const lv = (this.state.gameStats || {}).lv || 0;
            await this.page.evaluate(GAME.page.lvHuntStart, { slack, towns: this.townMaps() }).catch(() => {});
            this.log('⛔ ตาย 3 ครั้งใน 3 นาที = เควสนำเลเวล → หยุดเควส แล้วฟาร์มมอนเลเวล ≤ ' + (lv + slack) + ' เป็นเวลา ' + mins + ' นาที (จบแล้วกลับไปวิ่งเควสเอง)');
          }
          this._deaths = [];
          return;
        }
        if (!this._retreatUntil || now > this._retreatUntil) {
          this._retreatUntil = now + 5 * 60000; this._deaths = [];
          this.log('⛔ ตาย 3 ครั้งใน 3 นาที → ปิดตัวเดิน, ออกจากเกาะ, กลับเมือง แล้วพัก 5 นาที (กันเดินไปตายซ้ำ)');
          await this.page.evaluate(GAME.page.voyRoamStop).catch(() => {});
          const lv = await this.page.evaluate(GAME.page.wbLeaveIsle).catch(() => null);
          if (lv && lv.ok && lv.msg && lv.msg.indexOf('ไม่ได้อยู่บนเกาะ') < 0) this.log('🏾 ' + lv.msg.replace('(ไปบอสโลก)', '(พักหลังตายบ่อย)'));
          await sleep(7000);
          await this.goTown();
        }
        return;
      }
      if (this._retreatUntil && now < this._retreatUntil) return; // ช่วงพัก: ไม่สั่ง AUTO
      const towns = this.townMaps();
      const st = await this.page.evaluate(GAME.page.probeAuto).catch(() => null);
      if (!st || !st.online || !st.hasPlayer || st.dead || st.on || st.traveling || towns.includes(st.mapId)) return;
      await this.page.evaluate(GAME.page.enableAuto);
      this.state.autoWatch.count++;
    }, 5000, 0.3));
    // จำ map ล่าสุด + กลับเมืองเมื่อกระเป๋าเต็ม
    this.timers.push(jitterLoop(async () => {
      const s = await this.readGame(); if (!s) return;
      if (!s.inTown && !s.traveling && !s.dead && s.mapId && (!this.state.lastFarmMap || this.state.lastFarmMap.id !== s.mapId)) this.state.lastFarmMap = { id: s.mapId, name: s.mapName };
    }, 8000, 0.3));
    this.timers.push(jitterLoop(async () => {
      const at = g().autoTown; if (!at || !at.enabled || !(at.fullPct > 0)) return;
      if (this.state.paused) return; // ⏸ พัก = ไม่สั่งกลับเมือง
      const s = await this.readGame(); if (!s || s.dead || s.traveling || s.inTown) return;
      if (s.pct >= at.fullPct) this.runCycle();
    }, 15000, 0.3));
    // ผู้เฝ้าซื้อยา: ยาใกล้หมด → กลับเมืองไปซื้อ → กลับฟาร์ม
    this.timers.push(jitterLoop(async () => {
      const bp = g().buyPotion; if (!bp || !bp.enabled) return;
      if (this.state.paused) return; // ⏸ พัก = ไม่สั่งไปซื้อยา
      const gs = this.state.gameStats; if (!gs || !gs.name) return; // ยังไม่เข้าเกม
      const hp = gs.potions || 0, sp = gs.spPotions || 0;
      const needHp = bp.hp && bp.hp.on && hp < (bp.hp.min || 0);
      const needSp = bp.sp && bp.sp.on && sp < (bp.sp.min || 0);
      if (!needHp && !needSp) return;
      if (this._cycleBusy) return;
      this.runBuyCycle(needHp, needSp);
    }, 20000, 0.25));
    // เชื่อมต่อใหม่ + เลือกตัวละคร + ติดตามเดินทาง + title
    // ⚠️ autoLogin ต้องเปิดใน config เท่านั้น (default ปิด) — กันบอทกด Guest เองตอนผู้ใช้จะล็อกอินปกติ
    this.timers.push(jitterLoop(async () => {
      const al = g().autoLogin;
      if (al && al.enabled) {
        const st = await this.page.evaluate(GAME.page.probeReconnect).catch(() => null);
        if (st) {
          if (st.ss) await this.page.evaluate(GAME.page.clickServer, { guest: !!al.guest, user: al.user || '', pass: al.pass || '' }).catch(() => {});
          else if (st.cs) {
            const want = (g().enterCharacter && g().enterCharacter.enabled) ? String(g().enterCharacter.name || '').trim() : '';
            await this.page.evaluate(GAME.page.enterCharacter, want).catch(() => {});
          }
        }
      }
      const t = await this.page.evaluate(GAME.page.probeTravel).catch(() => null);
      if (t) { this.state.traveling = t.on; this.state.travelNote = t.note; }
      try { this.state.pageTitle = await this.page.title(); this.state.connected = !this.page.isClosed(); } catch (e) { this.state.connected = false; }
    }, 3000, 0.3));
    // 🚢 Voyage Farm Loop — วนถี่ขึ้นตอนอยู่บนเกาะ (ตัว roam จริงรันในหน้าเกมทุก 1.5 วิ)
    this.timers.push(jitterLoop(async () => {
      const vf = g().voyFarm;
      // 🚢 serving = ลูปนี้กำลังทำงานให้เควส (ขั้น k:'far' เช่น E1 “ออกเรือครั้งแรก”)
      //   ต้องรันต่อแม้ผู้ใช้ปิดสวิตช์ voyFarm ไว้ เพราะครั้งนี้ “ตัวเควสเอง” เป็นคนสั่งออกเรือ
      const serving = !!this._qVoy;
      if (!serving && (!vf || !vf.enabled)) return;
      if (this.state.paused) return; // ⏸ พัก = ไม่ออกเรือ/ไม่ซื้อสมุด
      if (this._fRoam && !this._qVoy) return; // ผู้ใช้สั่งฟาร์มmap เอง = อย่าเพิ่งออกเรือสะสมของ
      if (this._wb) return; // ภารกิจบอสโลกกำลังรัน = พักวงวนชั่วคราว (ไม่ปิดค่าที่ผู้ใช้ตั้ง)
      if (this._retreatUntil && Date.now() < this._retreatUntil) {
        // เพิ่งตายติดกัน 3 รอบ = ไม่ออกเรือ — ถ้ากำลังทำเพื่อเควสต้องยกเลิก ไม่งั้นค้างทั้งระบบ
        // (ลูปเควสยอมให้ลูปเรือขับ ส่วนลูปเรือก็หยุด = ไม่มีใครทำอะไรเลย)
        if (serving) this.qVoyFail('เพิ่งตายติดกันหลายรอบ — พัก 5 นาที ไม่ออกเรือต่อ');
        return;
      }
      // เกราะชั้นที่ 2: ตอนเปิดโหมดเควส ตัวจับตายบ่อยจะไม่ตั้ง _retreatUntil แต่ตั้ง _lvFarmUntil (ไปฟาร์มมอนก่อน)
      //   ถ้ายังดันออกเรือให้เควส = พากลับไปเกาะให้ตายซ้ำ → ยกเลิกงานเควสทันที
      if (serving && this._lvFarmUntil && Date.now() < this._lvFarmUntil) { this.qVoyFail('เข้าโหมดฟาร์มตามเลเวลหลังตายบ่อย'); return; }
      // เปิดโหมดวิ่งเควส = อย่าออกเรือ (เดี๋ยวเควสกับ Voyage แย่งกันขับตัวละคร) ยกเว้นกรณี serving ด้านบน
      const qcm = g().quest || {};
      if (qcm.enabled && !serving) return;
      // มีบอสโลกค้างอยู่ + เปิดฟีเจอร์ = อย่าซื้อสมุดลงเรือ (เดี๋ยวผู้เฝ้าบอสโลกต้องตัดทิ้ง = เผาสมุดฟรี)
      // ⚠️ แต่ห้ามบล็อกแบบไม่มีเงื่อนไข: เจอจริง (22:11-22:23) บอสโลก Lv60 up อยู่ เรา Lv58 เข้าไม่ได้
      //    → ลูปเรือ return เงียบทุก 8 วิ ขณะที่ลูปเควสถืองาน E1 ไว้ = ตายสนิทไม่ขยับอะไรเลย
      //    2 เคสที่ต้องปล่อยผ่าน: (1) เป็นงานที่เควสสั่ง (แย่กว่าคือไม่คืบหน้า) (2) เลเวลเราไม่ถึงเงื่อนไขบอสอยู่แล้ว
      const wbc = g().worldBoss || {};
      const wbPending = wbc.enabled && this._wbState && !this._wbState.none;
      const wbCantJoin = this._wbState && this._wbState.needLv != null && this._wbState.myLv != null && this._wbState.myLv < this._wbState.needLv;
      if (wbPending && !serving && !wbCantJoin) return;
      await this.voyFarmStep(serving ? { tier: this._qVoy.tier, node: this._qVoy.node, mode: 'boss', minZen: 0 } : null);
    }, 8000, 0.25));
    // 🐉 บอสโลก — อ่าน S.wbUi.st จากเกมจริง: 'warn'=นับถอยหลัง, 'up'=เกิดแล้ว, st=null=ตาย/จบงาน
    this.timers.push(jitterLoop(async () => {
      const wb = g().worldBoss || {};
      if (this.state.paused) return; // ⏸ พัก = ไม่ไปบอสโลก
      if (this._wb || this._cycleBusy || this._voyBusy) return;
      if (!this.page || this.page.isClosed()) return;
      const gs = this.state.gameStats; if (!gs || !gs.name) return; // ยังไม่เข้าเกม
      const st = await this.page.evaluate(GAME.page.worldBoss).catch(() => null);
      if (!st || !st.hasUi) return;
      this._wbState = Object.assign({ busy: false, seenAt: Date.now() }, st); // ให้อ่านโชว์บนแดชบอร์ดเสมอ แม้ปิดอยู่
      if (!wb.enabled || st.none) return;
      if (st.needLv != null && st.myLv != null && st.myLv < st.needLv) {
        this._wbCoolUntil = Date.now() + 30 * 60000;
        this.logOnce('wblv', '🐉 บอสโลก (รังมังกร) ต้อง Lv ' + st.needLv + ' — เรา Lv ' + st.myLv + ' เข้าไม่ได้ ข้ามไปก่อน (ลองใหม่ใน 30 นาที)', 600000);
        return;
      }
      if (this._wbCoolUntil && Date.now() < this._wbCoolUntil) return; // พัก 5 นาทีหลังล้มเหลว/สำเร็จ (กันวนเผาสมุด)
      const goAt = Math.max(20, +wb.goAtSec || 180);
      const shouldGo = st.state === 'up' || (st.leftSec != null && st.leftSec <= goAt);
      if (!shouldGo) return;
      await this.worldBossRun(st, { goAt, giveUp: Math.max(30, +wb.giveUpSec || 180) });
    }, 15000, 0.2));
    // 📜 โหมดวิ่งเควส — สั่งระบบเควสของเกมเอง (journal.go) แล้วเฝ้า S.aq: เราไม่เขียนเควสเอนจินใหม่
    this.timers.push(jitterLoop(async () => {
      if (!this.page || this.page.isClosed()) return;
      const qc = g().quest || {};
      // ผู้ใช้ปิดโหมดวิ่งเควสระหว่างที่เราออกเรือให้ = ยกเลิกงานทันที (ลูปเรือต้องหยุดตามสวิตช์ของผู้ใช้)
      if (this._qVoy && !qc.enabled) this.qVoyFail('ผู้ใช้ปิดโหมดวิ่งเควส');
      if (this.state.paused) return; // ⏸ พัก = ไม่แตะเควส/ไม่กดบทพูด
      if (this._fRoam) return; // ผู้ใช้สั่ง "ฟาร์ม map นี้" เอง = ลูปเควสพัก ไม่แย่งกันขับตัวละคร
      // 🧭 เพดานโซน = เลเวลเรา + zoneSlack (ผู้ใช้ปรับบนแดชบอร์ด) — คำนวณครั้งเดียว ใช้ทั้งเลือกเควสและติดป้ายให้แดชบอร์ด
      const zq = this.qZone();
      const lvNow = zq.lv, fits = zq.fits;
      const st = await this.page.evaluate(GAME.page.questStatus).catch(() => null);
      if (st && st.ok) {
        this.qDecorate(st); // ใส่ st.ceiling + x.far ให้แดชบอร์ดแสดงตรงกับที่บอทตัดสินใจ
        this._qState = Object.assign({ seenAt: Date.now() }, st); // ให้อ่านโชว์บนแดชบอร์ดเสมอ แม้ปิดโหมด
      }
      // กล่องบทพูดเควสเปิดอยู่ → กด "ต่อไป" ให้เอง (ไม่งั้นตัวยืนค้าง) ทำเฉพาะตอนโหมดเควสเกี่ยวของ
      if ((qc.enabled || (st && st.running)) && Date.now() - (this._talkAt || 0) > 6000) {
        this._talkAt = Date.now();
        const ta = await this.page.evaluate(GAME.page.talkAdvance).catch(() => null);
        if (ta && ta.ok) this.log('💬 กด "' + ta.clicked + '" ต่อ (กล่อง ' + ta.box + ')');
      }
      if (!qc.enabled || this._wb || this._cycleBusy || this._voyBusy) return;
      const gs = this.state.gameStats; if (!gs || !gs.name) return;
      // 🚢 มีงาน "ออกเรือให้เควส" อยู่ = วงวน Voyage เป็นคนขับแต่ผู้เดียว ลูปนี้ทำได้แค่ตรวจงาน
      //   (ห้ามสั่ง go() ซ้ำ — ต้นเหตุ log เดิมเด้งทุก 20 วิตอน E1 ยืนติดโต๊ะนำร่อง)
      if (this._qVoy) { this.qVoyCheck(st); return; }
      // ช่วง "ฟาร์มตามเลเวล" (หลังตายบ่อยเพราะเควสนำเลเวล) — อย่าเพิ่งกลับไปวิ่งเควส
      if (this._lvFarmUntil && Date.now() < this._lvFarmUntil) {
        const g0 = this.state.gameStats || {};
        if (g0.mapId && this.townMaps().includes(String(g0.mapId))) {
          this._lvFarmUntil = 0; this._lvTargetMap = null;
          await this.page.evaluate(GAME.page.lvHuntStop).catch(() => {});
          this.log('🏠 กลับถึงเมืองแล้ว (Lv' + (g0.lv || '?') + ') → จบโหมดฟาร์มตามเลเวล, ทำเรื่องเมืองต่อ (ฝากคลัง/ขาย) แล้วจะกลับไปวิ่งเควสเอง');
          this.runCycle();
          return;
        }
        const lg = await this.page.evaluate(GAME.page.lvHuntLog).catch(() => null);
        if (lg) this.logOnce('lvhunt', lg, 20000);
        // แมพระดับสูงกว่าเรา = ไม่มีมอนเลเวลใกล้ตัวให้ตีแน่นอน → ย้ายแมพ (ใช้ mapArea/mapPen ของเกม)
        //   ล็อกเป้าหมายไว้แล้วยิงซ้ำ: ตอนเดินไปจุดเวย์พอยต์ ตัวละครลอด "ประตูแมพ" ไปถึงแมพข้างเคียงได้
        //   ถ้าคำนวณใหม่ทุกทีจะเด้งไปมาไม่ถึงสักที (เจอจริง: Frostpeak → Sunken Ruins → ...)
        const g2 = this.state.gameStats || {}, lv = g2.lv || 0;
        const maps = await this.page.evaluate(GAME.page.mapInfo).catch(() => []);
        const here = (maps || []).filter((m) => String(m.id) === String(g2.mapId))[0];
        if (this._lvTargetMap != null && here && String(here.id) === String(this._lvTargetMap)) { this._lvTargetMap = null; this.log('🌾 ถึงแมพฟาร์มแล้ว (พื้นที่ ' + here.area + ' · เรา Lv' + lv + ')'); }
        if (this._lvTargetMap == null && lv && here && here.area > lv + 1) {
          const cand = (maps || []).filter((m) => m.wp && m.area <= lv + 1 && m.pen <= lv).sort((a, b2) => b2.area - a.area);
          if (cand.length) this._lvTargetMap = cand[0].id;
          else this.log('🌾 ไม่พบแมพที่เลเวลเหมาะ (เรา Lv' + lv + ') — จะตีมอนที่ใกล้ที่สุดในแมพนี้แทน');
        }
        if (this._lvTargetMap != null && Date.now() - (this._lvMoveAt || 0) > 20000) {
          this._lvMoveAt = Date.now();
          const t = (maps || []).filter((m) => String(m.id) === String(this._lvTargetMap))[0] || { name: 'map ' + this._lvTargetMap, area: '?' };
          const r = await this.page.evaluate(GAME.page.warpTo, this._lvTargetMap).catch(() => null);
          this.log('🌾 ย้ายไปฟาร์ม ' + t.name + ' (พื้นที่ ' + t.area + ' · เรา Lv' + lv + ')' + (here && String(here.id) !== String(this._lvTargetMap) ? (' · ตอนนี้อยู่ ' + here.name + ' พื้นที่ Lv' + here.area) : '') + ' · ' + ((r && r.msg) || ''));
        }
        return;
      }
      if (this._lvFarmUntil) {
        this._lvFarmUntil = 0; this._lvTargetMap = null;
        await this.page.evaluate(GAME.page.lvHuntStop).catch(() => {});
        this.log('📜 ครบกำหนดฟาร์มตามเลเวล — กลับไปวิ่งเควสต่อ');
      }
      if (!st || !st.ok) return;
      if (st.running) {
        const q = (st.list || []).filter((x) => x.id === st.running.q)[0];
        this.logOnce('qrun', '📜 วิ่งเควส: ' + ((q && q.name) || st.running.q) + (q ? (' ขั้น ' + q.step + ' · ' + q.have + '/' + q.need + ' · ' + q.text) : '') + ' · เฟส ' + st.running.phase, 45000);
        // เกมเดินข้ามแมพให้เองไม่ได้ (เจอจริง: เควส 2.7 เป้า map 5 แต่ตัวยืนนิ่งใน map 2) → ช่วยดัน
        const sig = st.running.q + '|' + st.map + '|' + st.px + ',' + st.py;
        const now2 = Date.now();
        if (this._qSig !== sig) { this._qSig = sig; this._qSigAt = now2; }
        else if (now2 - (this._qSigAt || now2) > 25000) {
          this._qSigAt = now2;
          const tgtMap = st.target && st.target[0];
          // ครั้งที่ 2 ของการติดนิ่ง → เช็คตารางเกิดบอสก่อน (ผู้ใช้สั่ง: ไปแล้วไม่เจอบอส ให้ดูว่าบอสเกิดชาแนลไหนแล้วย้ายไป)
          const nsig = st.running.q + ':' + (tgtMap != null ? tgtMap : st.map);
          this._qNudge = this._qNudge || {};
          this._qNudge[nsig] = (this._qNudge[nsig] || 0) + 1;
          if (this._qNudge[nsig] >= 2 && (!this._qChAt || now2 - this._qChAt > 120000)) {
            this._qChAt = now2; this._qNudge[nsig] = 0;
            const bc = await this.bossChannel(tgtMap != null ? tgtMap : st.map);
            if (bc && bc.ch) {
              const cg = await this.page.evaluate(GAME.page.chGo, bc.ch).catch(() => null);
              this.log((cg && cg.ok ? '🔀 ' : '⚠️ ') + 'ไม่เจอบอส ' + (st.running.q || '') + ' → ตารางบอกชาแนล ' + bc.ch + (bc.upCount ? (' (' + bc.upCount + ' ชาแนลที่บอสเกิด)') : (bc.wait ? (' (อีก ' + Math.round((bc.inSec || 0) / 60) + ' นาที)') : '')) + ' · ' + ((cg && cg.msg) || 'ย้ายไม่สำเร็จ'));
              return;
            }
            this.logOnce('qchnone', '🔀 เช็คตารางเกิดบอสแล้วไม่เจอข้อมูลชาแนลที่บอสเกิด — เดินหาต่อ', 120000);
          }
          let nd;
          if (tgtMap != null && tgtMap !== st.map) nd = await this.page.evaluate(GAME.page.warpTo, tgtMap).catch((e) => ({ ok: false, msg: e.message }));
          else nd = await this.page.evaluate(GAME.page.questNudge).catch((e) => ({ ok: false, msg: e.message }));
          this.log((nd && nd.ok ? (nd.pending ? '🚶 ' : '🧭 ') : '⚠️ ') + ((nd && nd.msg) || 'ช่วยดันเควสไม่สำเร็จ') + (st.target ? (' · เป้า map ' + st.target[0] + ' (' + st.target[1] + ',' + st.target[2] + ')') : ''));
        }
        // แตะ "เสาหมายทาง" ข้างทางไว้ก่อนตาย (เกมฟื้นที่เสาที่ติดแล้ว และไม่เสีย XP)
        if (st.running.phase === 'walk') {
          const pl = await this.page.evaluate(GAME.page.pillarNear, 16).catch(() => null);
          const one = pl && pl.list && pl.list[0];
          if (one) {
            const tag = st.map + ':' + one.k;
            this._pillars = this._pillars || {};
            if (!this._pillars[tag] || Date.now() - this._pillars[tag] > 120000) {
              this._pillars[tag] = Date.now();
              await this.page.evaluate((q) => { try { window.__walk(q.x, q.y); } catch (e) {} }, one).catch(() => {});
              this.log('🕯 เดินไปแตะ ' + one.name + ' (ห่าง ' + one.d + ') — ตายจะได้เกิดตรงนี้ ไม่ต้องเดินไกล');
            }
          }
        }
        return;
      }
      const lv = lvNow; // เลเวล + เพดานโซน (zSlack/fits) คำนวณไว้ตั้งแต่ต้น tick นี้แล้ว
      const runnable = (st.list || []).filter((x) => x.canRun);
      const core = runnable.filter((x) => x.line === 'core' && fits(x));
      const pool = core.length ? core : runnable.filter((x) => fits(x));
      if (!pool.length) {
        const over = runnable.filter((x) => !fits(x))[0];
        if (over && lv) {
          // ไม่มีเควสที่โซนใกล้ตัว → อย่ายืนเฉย ๆ ให้ไปตีมอนเลเวลเหมาะก่อน (จบแล้วกลับมาวิ่งเควสเอง)
          if (!this._lvFarmUntil || Date.now() > this._lvFarmUntil) {
            const mins = Math.max(3, +qc.farmMin || 15);
            const slack = (qc.lvSlack == null ? 0 : +qc.lvSlack);
            this._lvFarmUntil = Date.now() + mins * 60000;
            await this.page.evaluate(GAME.page.lvHuntStart, { slack, towns: this.townMaps() }).catch(() => {});
            this.log('📜 ไม่มีเควสที่โซนใกล้ตัว (ใกล้สุดคือ ' + over.name + ' พื้นที่ Lv' + over.area + ' · เรา Lv' + lv + ' · เพดานโซน Lv' + (zq.ceiling || '?') + ' ปรับได้ที่หน้าตั้งค่าเควส) → ไปฟาร์มมอน ≤ ' + (lv + slack) + ' ' + mins + ' นาที');
          }
          return;
        }
        const blocked = (st.list || [])[0];
        this.logOnce('qnone', '📜 ไม่มีเควสที่วิ่งอัตโนมัติได้ตอนนี้' + (st.whyNot || (blocked && blocked.why) ? (' — ' + (st.whyNot || blocked.why)) : ((st.list || []).length ? '' : ' — เควสที่เปิดอยู่หมดแล้ว')), 120000);
        return;
      }
      // บางเควส noRun() ว่าวิ่งได้ แต่ journal.go() ไม่เริ่มให้ → อย่าลองซ้ำตัวเดิมถี่ ๆ (log จะ spam ทุก 20 วิ)
      //   _qFail = พักสั้น 2 นาที (ลองใหม่ได้) | _qHard = พัก 10 นาที สำหรับเควสที่ "ลงมือทำจริงแล้วไม่ผ่าน"
      //   (เจอจริง: E1 ออกเรือไม่สำเร็จ → พัก 2 นาที แต่บรรทัดล้าง _qFail ข้างล่างทำให้ย้อนมาลองทุก 20 วิ)
      this._qFail = this._qFail || {}; this._qHard = this._qHard || {};
      const hardOk = (x) => !this._qHard[x.id] || Date.now() - this._qHard[x.id] > 10 * 60000;
      let fresh = pool.filter(hardOk).filter((x) => !this._qFail[x.id] || Date.now() - this._qFail[x.id] > 120000);
      if (!fresh.length && pool.some(hardOk)) {
        this._qFail = {}; // ทุกตัวยังพอทำได้ ถูกพักครบ 2 นาทีแล้ว → ล้างแล้วลองใหม่ (เคยปล่อยบอทนั่งเฉย 30 นาที)
        fresh = pool.filter(hardOk);
        this.logOnce('qretry', '📜 ลองเควสที่ข้ามไว้อีกครั้ง (' + fresh.map((x) => x.id).join(', ') + ')', 180000);
      }
      if (!fresh.length) {
        // เหลือแต่เควสที่ล้มเหลวจริงภายใน 10 นาที → อย่ายืนวน ลองตัวเดิมซ้ำ ๆ ให้อดทนไปฟาร์มมอนก่อน
        const mins0 = Math.max(3, +qc.farmMin || 15);
        if (!this._lvFarmUntil || Date.now() > this._lvFarmUntil) {
          const slack0 = (qc.lvSlack == null ? 0 : +qc.lvSlack);
          this._lvFarmUntil = Date.now() + mins0 * 60000;
          await this.page.evaluate(GAME.page.lvHuntStart, { slack: slack0, towns: this.townMaps() }).catch(() => {});
          this.log('📜 เควสที่พอทำได้ลองแล้วไม่ผ่านใน 10 นาที (' + pool.map((x) => x.id).join(', ') + ') → ไปฟาร์มมอน ≤ ' + (lv + slack0) + ' ' + mins0 + ' นาที แล้วค่อยกลับมาลอง');
        }
        return;
      }
      const q2 = (st.tracked && fresh.filter((x) => x.id === st.tracked)[0]) || fresh[0];
      // 🚢 ขั้นของเควสคือ "ออกเรือ" (k:'far') = ระบบวิ่งเควสของเกมทำไม่ได้เอง (พาไปยืนติดโต๊ะนำร่องแล้วจบ)
      //   → ส่งต่อให้วงวน Voyage: ซื้อสมุด → ลงเรือ → พุ่งบอสเกาะ → เก็บของ → กลับ แล้วเกมจะนับขั้นให้
      if (q2.k === 'far') { await this.qVoyStart(q2); return; }
      const r = await this.page.evaluate(GAME.page.questGo, q2.id);
      if (r && !r.ok) {
        this._qFail[q2.id] = Date.now();
        this.logOnce('qfail' + q2.id, '⚠️ เควส ' + q2.id + ' (' + q2.name + ') เกมไม่ยอมให้วิ่งอัตโนมัติ: ' + ((r && r.msg) || '') + ' → ข้ามไปก่อน', 120000);
      } else {
        delete this._qFail[q2.id];
        // เกมตั้ง S.aq ให้ = "เริ่มแล้ว" แต่ไม่ได้แปลว่าคืบ (บางเควสเกมล้างเองในไม่กี่วิ เช่น E1)
        //   ใช้ logOnce กัน log เด้งทุก 20 วิ — ตัวจับความคืบหน้า (qVoyCheck / qSig ติดนิ่ง) จะจัดการต่อ
        this.logOnce('qstart' + q2.id, '📜 ' + ((r && r.msg) || 'สั่งวิ่งเควส') + ' → ' + q2.name + ' (' + q2.step + ') ' + q2.text, 300000);
      }
    }, 20000, 0.2));
    // 🧹 ผู้เฝ้า "ฟาร์ม map ที่ผู้ใช้เลือก" — ตัวเดินจริงรันในหน้าเกมทุก 1.5 วิ เราแค่ kick + เก็บ log + จัดการรอบฝากของ
    this.timers.push(jitterLoop(async () => {
      const fr = this._fRoam; if (!fr) return;
      if (this.state.paused || this._wb || this._cycleBusy || this._voyBusy) return;
      if (!this.page || this.page.isClosed()) return;
      // ⚠️ state.traveling = "ฮีโร่มี path กำลังเดิน" (probeTravel) ไม่ใช่ "กำลังข้ามแมพ"
      //   เอามาไว้บนสุดไม่ได้ = ลูปจะ return ทิ้งเกือบตลอดเพราะตัวละครเดินตลอดเวลา (เจอจริง: เงียบ 4 นาที)
      // ยังไปไม่ถึงแมพที่สั่ง (warpTo คืนค่า "กำลังเดินไปจุดเวย์พอยต์" ก่อนถึงจริง) → ยังไม่ kick roam
      const gsNow = this.state.gameStats || {};
      if (gsNow.mapId != null && String(gsNow.mapId) !== String(fr.map)) {
        // ต้องเดินไปจุดเวย์พอยต์ก่อนขึ้นวาร์ป — ถ้า AUTO เปิดอยู่ มันจะเล็งมอนแล้วดึงเราออกนอกทาง
        //   (เจอจริง: ยืนวนใน Sky Citadel 4 นาทีไม่ถึงจุดวาร์ปสักที เพราะมอนรอบตัวเยอะ)
        if (!fr.movingToWp) {
          fr.movingToWp = true;
          const ao = await this.page.evaluate(GAME.page.autoOff, 'เดินไปขึ้นวาร์ปไป map ' + fr.map).catch(() => null);
          if (ao && ao.ok) this.log('⏸ ' + ao.msg + ' (กัน AUTO ดึงออกนอกทาง)');
        }
        if (Date.now() > (fr.nextWarpAt || 0)) {
          fr.nextWarpAt = Date.now() + 15000;
          await this.warpTo(fr.map);
        }
        return;
      }
      if (fr.movingToWp) { fr.movingToWp = false; this.log('🧹 ถึง map ' + fr.map + ' แล้ว — เริ่มกวาด (ตัวเดินจะเปิด AUTO เอง)'); }
      const P = (fn, arg) => this.page.evaluate(fn, arg).catch(() => null);
      const rs = await P(GAME.page.voyRoamStart, this.fieldOpts(fr.mode));
      if (rs && rs.msg) this.log(rs.msg);
      const rl = await P(GAME.page.voyRoamLog);
      if (Array.isArray(rl)) rl.forEach((x) => x && this.log(x));
      const st = await P(GAME.page.fieldRoamState);
      fr.last = st;
      if (st && st.done) { // กระเป๋าเต็ม / หลุดเข้าเมือง → ฝากของ+ขาย แล้วกลับมาแมพเดิมเอง (วงวนครบวงจร)
        this.log('🔁 ' + (st.done === 'bag' ? 'กระเป๋าเต็ม' : 'กลับเข้าเมือง') + ' → ไปฝากของ/ขาย แล้วจะกลับมาฟาร์ม map ' + fr.map + ' ต่อเอง');
        await P(GAME.page.voyRoamStop);
        await this.runCycle();
        if (this._fRoam === fr) { await this.warpTo(fr.map); this.log('🧹 กลับมาฟาร์ม map ' + fr.map + ' ต่อ'); }
        return;
      }
      // 🐉 โหมดเน้นบอส: อ่านตารางเกิดบอส (เมนู L) เป็นระยะ — บอกว่าอีกกี่นาทีจะเกิด + ย้ายชาแนลถ้าตัวที่ alive อยู่คนละชาแนล
      if (fr.mode === 'boss' && Date.now() > fr.nextSchedAt) {
        fr.nextSchedAt = Date.now() + 3 * 60000;
        const bc = await this.bossChannel(fr.map);
        if (bc && bc.ch) {
          if (bc.upCount) {
            const cg = await P(GAME.page.chGo, bc.ch);
            this.log('🔀 ตารางบอส map ' + fr.map + ': เกิดแล้วที่ชาแนล ' + bc.ch + ' (' + bc.upCount + ' ชาแนลที่มีบอส) · ' + ((cg && cg.msg) || 'ย้ายไม่สำเร็จ'));
          } else {
            this.log('⏳ ตารางบอส map ' + fr.map + ' ชาแนล ' + bc.ch + ': อีก ~' + Math.max(1, Math.round((bc.inSec || 0) / 60)) + ' นาทีจะเกิด → กวาดหา/ฟาร์มรอบนี้ไปก่อน');
          }
        }
      }
    }, 6000, 0.2));
  }

  // ---------- 🐉 ภารกิจบอสโลก: พักทุกวงวน → ออกเกาะ → ไปรัง → ตี → กลับเมือง → วนต่อ ----------
  async worldBossRun(st, cfg) {
    if (this._wb) return;
    const P = (fn, arg) => this.page.evaluate(fn, arg).catch((e) => ({ error: e.message }));
    const g = () => this.S();
    const lair = st.map || 27;
    this._wb = { t0: Date.now(), map: lair, name: st.name || 'บอสโลก', phase: 'go' };
    this._wbState = Object.assign({ busy: true, at: Date.now() }, st, { phase: 'go' });
    this._cycleBusy = true; // กัน runCycle/ฝากคลัง กับ voyFarmStep มาขัดจังหวะเรา
    this.log('🐉 บอสโลก' + (st.state === 'up' ? ' ปรากฏแล้ว' : ' อีก ' + Math.max(0, st.leftSec) + ' วิ') +
      ' → หยุดวงวนไปตี: ' + this._wb.name + ' (แมพ ' + lair + (st.ch != null ? ', ชาแนล ' + st.ch : '') + ')');
    try {
      await P(GAME.page.voyRoamStop);                       // ปิดตัวเดินอัตโนมัติบนเกาะก่อน
      // บอสโลกแยกตามชาแนล (ทดสอบแล้ว: ไปผิดชาแนล = ถึงรังแต่มองไม่เห็นบอส) → ย้ายชาแนลก่อนเดินทาง
      if (st.ch != null) {
        const cg = await P(GAME.page.chGo, st.ch);
        this.log((cg && cg.ok ? '🔀 ' : '⚠️ ') + ((cg && cg.msg) || 'ย้ายชาแนลไม่สำเร็จ') + ' (บอสอยู่ชาแนล ' + st.ch + ')');
        await sleep(4000);
      }
      const lv = await P(GAME.page.wbLeaveIsle);
      if (lv && lv.ok && lv.msg && lv.msg.indexOf('ไม่ได้อยู่บนเกาะ') < 0) {
        this.log('🏾 ' + lv.msg);
        // สำคัญ: ต้องรอให้เกมพาขึ้นฝั่งจริงก่อน — ถ้ายิง wpgo ทับตอนกำลังออกเกาะ เซิร์ฟจะทิ้งแพ็กเก็ต
        //   (ทดสอบสด 28/10: วาร์ปแล้วไปโผล่ Solhaven แทนรังมังกร)
        for (let i = 0; i < 24; i++) {
          await sleep(1500);
          const on = await P(GAME.page.wbOnIsle);
          if (!on || !on.run) break;
        }
      }
      // เดินทางไปรัง: ส่งซ้ำได้ทุก 6 วิ จนกว่าจะถึง (กันแพ็กเก็ตหลุด) เพดาน 90 วิ
      let arrived = false; const tGo = Date.now(); let lastSend = 0, tries = 0;
      while (Date.now() - tGo < 90000) {
        const s = await P(GAME.page.readStats);
        if (s && String(s.mapId) === String(lair)) { arrived = true; break; }
        if (Date.now() - lastSend > 6000) {
          lastSend = Date.now(); tries++;
          const wp = await P(GAME.page.warpTo, lair);
          this.log('🧭 วาร์ปไปรังบอสโลก (ครั้งที่ ' + tries + '): ' + ((wp && wp.msg) || 'ไม่สำเร็จ'));
        }
        await sleep(1500);
      }
      if (!arrived) { this.log('⚠️ ไปรังบอสโลกไม่สำเร็จใน 90 วิ — พัก 5 นาทีก่อนลองใหม่'); this._wb.failed = true; return; }
      this._wb.phase = 'fight'; if (this._wbState) this._wbState.phase = 'fight';
      await P(GAME.page.enableAuto);
      this._wb.progAt = Date.now(); this._wb.lastHp = null;
      const tFight = Date.now();
      while (Date.now() - tFight < 40 * 60000) {
        const cur = await P(GAME.page.worldBoss);
        if (cur && cur.none) { this.log('🏆 บอสโลกถูกปราบแล้ว (เกมรีเซ็ตสถานะ) — กลับเมือง'); this._wb.killed = true; break; }
        const sb = await P(GAME.page.wbStatus, this._wb.name);
        if (this._wbState && sb) { this._wbState.phase = 'fight'; this._wbState.bossHp = sb.boss ? sb.boss.hp : null; this._wbState.players = sb.players; this._wbState.at = Date.now(); }
        if (sb && sb.boss) {
          this._wb.bossHp = sb.boss.hp;
          if (this._wb.lastHp == null || (sb.boss.hp != null && sb.boss.hp < this._wb.lastHp)) this._wb.progAt = Date.now();
          this._wb.lastHp = sb.boss.hp;
          if (Date.now() - this._wb.progAt > cfg.giveUp * 1000) {
            this.log('⚠️ ยืนตี ' + cfg.giveUp + ' วิ เลือดบอสไม่ลด (ผู้เล่นรอบตัว ' + sb.players + ' คน — เกมต้องได้อย่างน้อย 10) → ถอยกลับมาวนต่อ');
            this._wb.gaveUp = true; break;
          }
        } else if (Date.now() - this._wb.progAt > cfg.giveUp * 1000) {
          this.log('⚠️ ' + cfg.giveUp + ' วิ มองไม่เห็นบอสในรัง → ถอยกลับมาวนต่อ'); this._wb.gaveUp = true; break;
        }
        await sleep(5000);
      }
      if (!this._wb.killed && !this._wb.gaveUp) this.log('⌛ ครบ 40 นาทีในรังบอสโลก — ถอยกลับเมือง');
    } finally {
      const res = this._wb || {};
      this._wb = null; this._cycleBusy = false;
      // พักก่อนลองรอบใหม่: ปราบสำเร็จ=2 นาที, ไม่สำเร็จ/ถอย=5 นาที
      //   (เคยทดสอบสดแล้ววนซ้ำ "ออกเรือ→ถูกตัดไปบอส→วาร์ปไม่ทัน→กลับมาซื้อสมุดลงเรือ" เผา 10,000 Zen/รอบ)
      this._wbCoolUntil = Date.now() + (res.killed ? 120000 : 300000);
      if (this._wbState) { this._wbState.busy = false; this._wbState.phase = null; }
      await P(GAME.page.goTown);
      this.log('♻️ จบภารกิจบอสโลก — วงวน Voyage เดิมทำงานต่อเอง' + (g().voyFarm && g().voyFarm.enabled ? '' : ' (วงวน Voyage ถูกปิดไว้ ต้องเปิดเองถ้าอยากวนต่อ)'));
    }
  }

  async readGame() {
    return this.page.evaluate(GAME.page.readState, this.townMaps()).catch(() => null);
  }

  humanWait(base) { const hd = this.S().humanDelay; if (hd && hd.enabled !== false && hd.minSec > 0) { const mn = hd.minSec * 1000, mx = Math.max(mn, (hd.maxSec || hd.minSec) * 1000); return mn + Math.random() * (mx - mn); } return base; }

  async farmLoop() {
    while (this.state.farmOn) {
      const actions = (this.S().autoFarm && this.S().autoFarm.actions) || [];
      for (const act of actions) {
        if (!this.state.farmOn) break;
        try {
          if (act.type === 'key') { await this.page.keyboard.down(act.key); await sleep(55 + Math.random() * 40); await this.page.keyboard.up(act.key); }
          else if (act.type === 'click') { await this.page.mouse.move(act.x + (Math.random() * 8 - 4), act.y + (Math.random() * 8 - 4)); await sleep(50 + Math.random() * 50); await this.page.mouse.down(); await sleep(50 + Math.random() * 40); await this.page.mouse.up(); }
        } catch (e) { this.state.lastError = e.message; }
        await sleep(this.humanWait(act.intervalMs || 1000));
      }
      if (!actions.length) await sleep(1000);
    }
  }
  farmStart() { if (this.state.farmOn || !this.page) return { ok: false, msg: 'ไม่พร้อม' }; if (!(this.S().autoFarm.actions || []).length) return { ok: false, msg: 'ยังไม่มีคำสั่งฟาร์ม' }; this.state.farmOn = true; this.log('▶️ เริ่มฟาร์ม (กดสกิลอัตโนมัติ)'); this.farmLoop(); return { ok: true, msg: 'เริ่มฟาร์มแล้ว' }; }
  farmStop() { this.state.farmOn = false; this.log('⏹ หยุดฟาร์ม'); return { ok: true, msg: 'หยุดฟาร์มแล้ว' }; }

  // ---------- 🧹 ฟาร์ม "map ที่ผู้ใช้เลือกเอง" (โหมด กวาดทั้งแมพ / เน้นฆ่าบอส) ----------
  //   เดิมปุ่ม "ไปฟาร์ม" ทำแค่ วาร์ปไปแมพ แล้ว AUTO ของเกมตีเฉพาะมอนใกล้ตัว = ยืนจุดเดิมทั้งวัน
  //   โหมดนี้เพิ่มตัวเดินกวาดทั้งแมพ (ตารางจุดที่เดินได้) + ไม่กรองเลเวล (ผู้ใช้เลือก map เอง)
  fieldOpts(mode) {
    const vf = this.S().voyFarm || {};
    return {
      field: true, mode: mode === 'boss' ? 'boss' : 'hunt',
      filter: this.S().lootFilter || { mode: 'game' },
      bagPct: +vf.bagPct || 85,          // ใช้เกณฑ์ "เต็มแล้วไปฝาก" ชุดเดียวกับวงวน Voyage
      lootSec: +vf.lootSeconds || 15,    // เวลาเก็บของหลังบอสตาย (ค่าที่ผู้ใช้ตั้งไว้แล้ว)
      towns: this.townMaps(), lfSrc: LF_SRC,
    };
  }
  fieldRoamOff(why) {
    if (!this._fRoam) return;
    this._fRoam = null;
    if (this.page && !this.page.isClosed()) this.page.evaluate(GAME.page.voyRoamStop).catch(() => {});
    if (why) this.log('⏹ หยุดฟาร์มmap: ' + why);
  }
  async farmMapMode(id, mode) {
    if (!id) return { ok: false, msg: 'ยังไม่ได้เลือกแผนที่' };
    if (!mode || mode === 'off') { this.fieldRoamOff('ย้ายแมพธรรมดา (ไม่ได้เลือกโหมดฟาร์ม)'); return this.warpTo(id); }
    // ล็อกคนขับคนเดียว: ผู้ใช้สั่ง "ฟาร์ม map นี้" = อย่าให้เควส/โหมดฟาร์มตามเลเวล/วงวนเรือ มาแย่งกันเดิน
    this.fieldRoamOff('เปลี่ยนแมพ/โหมดที่สั่งใหม่');
    if (this._qVoy) this.qVoyFail('ผู้ใช้สั่งฟาร์มmap เอง');
    if (this._lvFarmUntil) { this._lvFarmUntil = 0; await this.page.evaluate(GAME.page.lvHuntStop).catch(() => {}); }
    this._fRoam = { mode, map: String(id), t0: Date.now(), nextSchedAt: 0, nextWarpAt: Date.now() + 30000 };
    const r = await this.warpTo(id);
    this.log(mode === 'boss'
      ? '🐉 ฟาร์มmap ' + id + ' โหมด "เน้นฆ่าบอส" — กวาดหาบอสทั้งแมพ ตีแล้วเก็บของ แล้วกวาดรอบรอตัวเกิดใหม่ (ไม่จำกัดเลเวล)'
      : '🧹 ฟาร์มmap ' + id + ' โหมด "กวาดทั้งแมพ" — เดินครอบคลุมทั้งแมพ เก็บของ ตีทุกอย่างที่เจอ (ไม่จำกัดเลเวล)');
    return r;
  }

  async goTown() { const r = await this.page.evaluate(GAME.page.goTown).catch((e) => ({ ok: false, msg: e.message })); if (r.ok) this.log('🏠 ' + r.msg); return r; }
  async warpTo(id) { const r = await this.page.evaluate(GAME.page.warpTo, id).catch((e) => ({ ok: false, msg: e.message })); if (r.ok) this.log('🔥 ' + r.msg); return r; }
  async approachShop() { await this.page.evaluate(GAME.page.approachShop).catch(() => {}); }

  async sellPreview() { try { return await this.page.evaluate(GAME.page.analyzeSell, this.S().sellConfig || {}); } catch (e) { return { error: e.message }; } }
  async sellRun(what) { try { const r = await this.page.evaluate(GAME.page.sellExecute, GAME.page.analyzeSell.toString(), this.S().sellConfig || {}, what || 'all'); if (r.ok) this.log('💰 ' + r.msg); return r; } catch (e) { return { ok: false, msg: e.message }; } }

  // ซื้อยาที่ร้าน: ต้องใกล้ NPC → วนซื้อจนครบ
  async buyPotionsInShop(needHp, needSp) {
    const bp = this.S().buyPotion || {};
    const plan = [];
    if (needHp && bp.hp) plan.push({ pid: bp.hp.size || GAME.POTION.hp.size, n: bp.hp.buy || 100 });
    if (needSp && bp.sp) plan.push({ pid: bp.sp.size || GAME.POTION.sp.size, n: bp.sp.buy || 100 });
    if (!plan.length) return { ok: false, msg: 'ไม่ได้เลือกยาที่จะซื้อ' };
    return this.page.evaluate(GAME.page.buyPotions, plan).catch((e) => ({ ok: false, msg: e.message }));
  }

  async runCycle() {
    if (this._cycleBusy) return; this._cycleBusy = true;
    try {
      let s = await this.readGame();
      if (s && !s.inTown) await this.goTown();
      for (let i = 0; i < 100; i++) { await sleep(3000); s = await this.readGame(); if (s && s.inTown && !s.traveling) break; }
      // เดินไปหน้าร้านจริง (approachShop ของจริง — เดิมเป็น stub แล้วรอ nearShop ที่แปลว่า "เปิดหน้าต่างร้าน" จึงหน่วงฟรี ~100 วิ)
      let ap = null;
      if (s && s.inTown) {
        ap = await this.page.evaluate(GAME.page.approachShop).catch(() => null);
        for (let i = 0; i < 30 && !(ap && ap.ok); i++) { await sleep(2000); ap = await this.page.evaluate(GAME.page.approachShop).catch(() => null); }
      }
      await sleep(1500);
      const cfg = this.S().sellConfig || {};
      if (cfg.materials && cfg.materials.enabled) await this.sellRun('mats');
      if (cfg.gear && cfg.gear.enabled) await this.sellRun('gear');
      // 💰 ขาย "ของที่เกินโควตา" (ช่องติ๊กในหน้า เก็บของ: ถ้ามีเกินให้ขายทิ้งทุกครั้งที่กลับเมือง)
      const lf = this.S().lootFilter || {}, cap = lf.cap || {};
      if (cap.sellOver && (cap.items || []).length) {
        if (ap && ap.ok) {
          const plan = await this.page.evaluate(GAME.page.sellExcessPlan, cap).catch(() => null);
          if (plan && plan.ok && plan.total) {
            this.log('💰 เกินโควตา: ' + (plan.detail || []).filter((x) => x.indexOf('เกิน') >= 0).join(' · ') + ' → ขายที่ ' + (ap.name || 'ร้านค้า'));
            const rr = await this.page.evaluate(GAME.page.sellExcessRun, plan.list).catch((e) => ({ ok: false, msg: e.message }));
            this.log((rr && rr.ok ? '💰 ' : '⚠️ ') + ((rr && rr.msg) || 'ขายไม่สำเร็จ')
              + (rr && rr.sold && rr.sold.length ? (' · ' + rr.sold.join(', ')) : '')
              + (rr && rr.skipped && rr.skipped.length ? (' · ข้าม: ' + rr.skipped.join(', ')) : ''));
          } else if (plan && plan.ok) this.logOnce('capOk', '💸 ไม่มีของเกินโควตาที่ตั้งไว้ (' + cap.items.length + ' ชื่อ × ' + (cap.max || 20) + ' ชิ้น)');
        } else this.log('⚠️ ' + ((ap && ap.msg) || 'หาร้านค้าไม่สำเร็จ') + ' — ข้ามการขายของเกินโควตา');
      }
      const t = this.state.lastFarmMap || (this.cfg.farmMap ? { id: this.cfg.farmMap } : null);
      if (t && t.id) await this.warpTo(t.id);
    } catch (e) { this.state.lastError = e.message; } finally { this._cycleBusy = false; }
  }

  async runBuyCycle(needHp, needSp) {
    if (this._cycleBusy) return; this._cycleBusy = true;
    try {
      this.log('💊 ยาใกล้หมด → กลับเมืองไปซื้อ');
      let s = await this.readGame();
      if (s && !s.inTown) await this.goTown();
      for (let i = 0; i < 100; i++) { await sleep(3000); s = await this.readGame(); if (s && s.inTown && !s.traveling) break; }
      s = await this.readGame(); if (s && s.inTown && !s.nearShop) { await this.approachShop(); for (let i = 0; i < 40; i++) { await sleep(2500); s = await this.readGame(); if (s && s.nearShop) break; } }
      await sleep(1500);
      const r = await this.buyPotionsInShop(needHp, needSp);
      this.log(r.ok ? ('✅ ซื้อยาแล้ว ' + r.bought + ' ขวด (-' + (r.spent || 0).toLocaleString() + ' เหรียญ)') : ('⚠️ ซื้อยาไม่สำเร็จ: ' + r.msg));
      const t = this.state.lastFarmMap || (this.cfg.farmMap ? { id: this.cfg.farmMap } : null);
      if (t && t.id) await this.warpTo(t.id);
    } catch (e) { this.state.lastError = e.message; } finally { this._cycleBusy = false; }
  }

  // ---------- 🚢 Voyage Farm Loop ----------
  // config.voyFarm = { enabled, isle (node), tier (สมุดเป้าหมาย 2..15), bagPct, minZen, lootSeconds (วิ: เก็บของหลังบอสตายกี่วิค่อยออกเกาะ) }
  // ตัวเลือกที่ส่งเข้าตัวเดินในหน้าเกม (รวม src ของกฎกรองของด้วย)
  roamOpts(vf) {
    const v = vf || this.S().voyFarm || {};
    return {
      filter: this.S().lootFilter || { mode: 'game' },
      mode: v.mode || 'hunt',
      bagPct: v.bagPct || 85,
      minZen: v.minZen || 0,
      lootSec: +v.lootSeconds || 15,
      lfSrc: LF_SRC,
    };
  }
  voyFarmStop(reason) {
    const g = this.getGlobal();
    if (g.voyFarm) g.voyFarm.enabled = false;
    const acc = (g.accounts || [])[this.index];
    if (acc && acc.settings && acc.settings.voyFarm) acc.settings.voyFarm.enabled = false;
    try { this.saveFn(); } catch (e) {}
    this.log('⏹ หยุดวงวน Voyage: ' + reason);
  }
  // ---------- 🚢 "ออกเรือให้เควส" (ขั้นเควสประเภท k:'far') ----------
  //   เจอจริง: เควส E1 "ออกเรือครั้งแรก" — journal.go() ของเกมพาตัวละครไปยืนที่โต๊ะนำร่อง
  //   (วัดจริง: ยืนห่างโต๊ะ 0 ช่อง) แล้วยืนเฉย เพราะระบบวิ่งเควสของเกมออกเรือ/ตีบอสเกาะเองไม่ได้
  //   ฝั่งเราทำวงวน Voyage ครบอยู่แล้ว (ซื้อสมุด → รวมสมุด → ลงเรือ → พุ่งบอส → เก็บของ → กลับ)
  //   เลยส่งต่องานให้วงวนนั้น พร้อม "ล็อกคนขับ" ไว้ที่ตัวเดียว (ลูปเควสจะไม่สั่ง go()/ดันตัวละครอีก)
  async qVoyStart(x) {
    const vf = this.S().voyFarm || {};
    const node = (vf.isle | 0) || 1;
    const tier = Math.max(1, Math.min(15, x.tier | 0 || 1));
    this._qVoy = { qid: x.id, name: x.name || x.id, tier, node, t0: Date.now(), trips: 0, step0: x.step || '', have0: x.have | 0 };
    // สั่งเกมให้ "ติดตาม" เควสครั้งนี้ครั้งเดียว (บางเควสต้องให้เกมรู้ก่อนถึงจะนับขั้น) — ห้ามเรียกซ้ำ
    try { await this.page.evaluate(GAME.page.questGo, x.id); } catch (e) {}
    this.log('🚢 เควส ' + this._qVoy.qid + ' (' + this._qVoy.name + ') สั่งให้ออกเรือ → วงวน Voyage รับช่วง: '
      + 'ซื้อสมุดอันดับ ' + this._qVoy.tier + ' → เกาะ node ' + this._qVoy.node + ' → พุ่งบอสเกาะ → กลับ (เกมจะนับขั้นให้เอง, ไม่สั่ง go() ซ้ำ)');
    return this._qVoy;
  }
  // เช็กทุก tick ของลูปเควส: เควสขยับหรือยัง / ติดอยู่ที่เดิมเกินไปไหม
  qVoyCheck(st) {
    const v = this._qVoy; if (!v) return;
    if (!st || !st.ok) return; // อ่านเกมไม่สำเร็จ = รอบนี้ยังไม่สรุป (เซิร์ฟเวอร์ช้า/กำลังโหลดแมพ)
    const x = (st.list || []).filter((q) => q.id === v.qid)[0];
    const mins = Math.round((Date.now() - v.t0) / 60000);
    if (!x) { this._qVoy = null; this.log('✅ เควส ' + v.qid + ' (' + v.name + ') หายจากรายการที่ทำได้ = เกมรับว่าเสร็จแล้ว (' + mins + ' นาที) → กลับมาวิ่งเควสต่อ'); return; }
    if ((x.step || '') !== v.step0 || (x.have | 0) > v.have0) {
      this._qVoy = null;
      this.log('✅ เควส ' + v.qid + ' (' + v.name + ') คืบแล้ว: ขั้น ' + v.step0 + ' ' + v.have0 + '/' + (x.need || 1) + ' → ' + x.step + ' ' + x.have + '/' + (x.need || 1) + ' (' + mins + ' นาที) → กลับมาวิ่งเควสต่อ');
      return;
    }
    if (v.trips >= 2) {
      this.qVoyFail('ออกเรือ ' + v.trips + ' รอบแล้วยังไม่เข้าเกาะ' + (v.inParty
        ? ' — ตอนสั่งลงเรือเราอยู่ในปาร์ตี้ (เกมไม่ให้ออกเรือซ้อนถ้าเพื่อนในปาร์ตี้กำลังออกเรืออยู่) ให้ออกจากปาร์ตี้ก่อนแล้วค่อยใหม่'
        : ' — เกมอาจนับอย่างอื่นที่ไม่ใช่บอสเกาะ'));
      return;
    }
    if (Date.now() - v.t0 > 20 * 60000) { this.qVoyFail('เกิน 20 นาทีแล้วยังไม่คืบ'); return; }
    this.logOnce('qvoy', '🚢 กำลังออกเรือให้เควส ' + v.qid + ' (' + v.name + ') ผ่านไป ' + mins + ' นาที รอบที่ ' + (v.trips || 0), 120000);
  }
  // ยกเลิกงาน + แบล็กลิสต์เควสชั่วคราว (ลูปเควสจะข้ามไปเลือกอย่างอื่น / ไม่มีเควสก็ไปฟาร์มมอนเอง)
  //   หมายเหตุ: ไม่แตะสวิตช์ voyFarm ใน config เด็ดขาด — ของใครของมัน
  qVoyFail(reason) {
    const v = this._qVoy; if (!v) return;
    this._qVoy = null;
    this._qFail = this._qFail || {}; this._qHard = this._qHard || {};
    this._qFail[v.qid] = Date.now();
    this._qHard[v.qid] = Date.now(); // พักหนัก 10 นาที — การออกเรือ 1 รอบกินทั้งเงิน+เวลา ห้ามย้อนมาลองทุก 20 วิ
    this.log('⚠️ ออกเรือให้เควส ' + v.qid + ' (' + v.name + ') ไม่สำเร็จ: ' + reason + ' → พักเควสนี้ 10 นาที แล้วไปฟาร์มมอนต่อ');
    // ถ้าเพิ่งยกเลิกกลางเกาะ = อย่าทิ้งให้โหมดอื่นไปเดินตีมอนแข็งบนเกาะต่อ → สั่งออกจากเกาะ
    if (this.page && !this.page.isClosed()) {
      this.page.evaluate(GAME.page.wbLeaveIsle).then((r) => {
        if (r && r.ok && r.msg && r.msg.indexOf('ไม่ได้อยู่บนเกาะ') < 0) this.log('🏾 ' + r.msg.replace('(ไปบอสโลก)', '(ยกเลิกเควสออกเรือ)'));
      }).catch(() => {});
    }
  }

  // ov = ค่าที่ "คนสั่ง" จำเป็นต้องกำหนดเอง (เควสประเภทออกเรือจะระบุ tier/เกาะ และบังคับโหมดพุ่งบอส)
  //   ถ้าไม่ส่งมา = ใช้ค่าจากแดชบอร์ดของผู้ใช้ตามเดิม (โหมดวงวนปกติ)
  async voyFarmStep(ov) {
    if (this._voyBusy || this._cycleBusy) return;
    if (!this.page || this.page.isClosed()) return;
    this._voyBusy = true;
    try {
      const vf = Object.assign({}, this.S().voyFarm || {}, ov || {});
      // ทำเพื่อเควส → ห้ามเขียนค่าลง config (สวิตช์ voyFarm บนแดชบอร์ดของผู้ใช้ต้องเหมือนเดิม) ให้ใช้ qVoyFail
      const stopFn = (why) => (ov ? this.qVoyFail(why) : this.voyFarmStop(why));
      const tier = Math.max(1, Math.min(15, vf.tier | 0 || 15));
      const node = vf.isle | 0;
      if (!node) { stopFn('ยังไม่ได้เลือกเกาะปลายทาง'); return; }
      const P = (fn, arg) => this.page.evaluate(fn, arg).catch((e) => ({ error: e.message }));
      let d = await P(GAME.page.voyagePanel);
      if (!d || d.error) { this.log('⚠️ Voyage: ยังไม่พร้อม (' + ((d && (d.error || d.msg)) || 'ไม่มีข้อมูล') + ')'); return; }
      // เพิ่งสั่งลงเรือ: เซิร์ฟยังไม่ตั้ง S.voyUi.run ทันที (กำลังโหลดเกาะ) → ถ้ายิงซ้ำจะ "ออกเดินทาง" ซ้ำทุก 8 วิ
      //   (เจอจริง: 4 ครั้งใน 45 วินาที) ให้นั่งรอเรือเทียบฝั่งก่อน
      if (ov && this._qVoy && this._qVoy.lastSailAt && !d.onIsle && Date.now() - this._qVoy.lastSailAt < 90000) {
        this.logOnce('qvoywait', '🚢 รอเรือเทียบฝั่ง (สั่งออกเดินทางไป ' + Math.round((Date.now() - this._qVoy.lastSailAt) / 1000) + ' วิ แล้ว)', 25000);
        return;
      }

      // === ขา 1: อยู่บนเกาะ → kick ตัวเดินต่อเนื่องในหน้าเกม (tick 1.5 วิ) แล้วเก็บ log มาแสดง ===
      if (d.onIsle) {
        const rs = await P(GAME.page.voyRoamStart, this.roamOpts(vf));
        if (rs && rs.msg) this.log(rs.msg);
        const rl = await P(GAME.page.voyRoamLog);
        if (Array.isArray(rl)) rl.forEach((x) => x && this.log(x)); else if (rl) this.log(rl);
        if (vf.minZen > 0 && d.zen != null && d.zen < vf.minZen) stopFn('เงินเหลือ ' + d.zen.toLocaleString());
        return;
      }

      // === ขา 2: ต้องอยู่ map ที่มีโต๊ะ (เมือง 0/2) — ติดบนเกาะ/ที่อื่น → วาร์ปกลับก่อน ===
      if (d.map != null && d.map !== '0' && d.map !== '2' && d.map !== 0 && d.map !== 2) {
        this.log('🧭 ไม่ได้อยู่เมือง (map ' + d.map + ') → วาร์ปกลับ Solhaven ก่อน');
        await this.warpTo('2');
        await sleep(8000);
      }
      d = await P(GAME.page.voyagePanel); if (!d || d.error) return;

      // === ขา 2.5: กระเป๋าเต็ม → เดินไปฝากของกับ "คาฟี ผู้ดูแลคลัง" (แทนที่จะเลิกวน) ===
      const keepEach = Math.max(0, +vf.keepOrbCount || 20);
      const KEEP_ORBS = { 11778: keepEach, 11779: keepEach, 11781: keepEach, 11782: keepEach }; // ปลุกพลัง/เสริมพลัง/เลื่อนขั้น/นักปราชญ์
      const bpct = (d.bag && d.bag.pct) || 0;
      const fullAt = vf.bagPct || 85;
      if (bpct >= fullAt) {
        // 📦 ทางลัดพรีเมียม: กดปุ่ม "ฝากทั้งหมด/ฝากเข้าแท็บพิเศษ" ของเกม (ฝากได้ทุกที่ ไม่ต้องเดินหาคาฟี)
        if (vf.bulkStash) {
          const bb = await P(GAME.page.stashBulk, { specialTabs: !!vf.bulkSpecial });
          this.log('📦 ' + ((bb && bb.msg) || 'ใช้ทางลัดพรีเมียมไม่สำเร็จ: ' + ((bb && bb.msg) || '')));
          await sleep(3500);
          d = await P(GAME.page.voyagePanel); if (!d || d.error) return;
        }
        const bpct2 = (d.bag && d.bag.pct) || 0;
        if (bpct2 >= fullAt) {
          this.log('📦 กระเป๋าเต็ม ' + bpct2 + '% (' + d.bag.used + '/' + d.bag.cap + ' ช่อง) → ไปฝากที่คาฟี เหลือออร์บไว้ใช้อย่างละ ' + keepEach);
          const dep = await P(GAME.page.stashDeposit, { keep: KEEP_ORBS, tab: 0, lfSrc: LF_SRC });
          const depMsg = (dep && dep.msg) || 'ไม่ได้รับคำตอบจากการฝากของ';
          String(depMsg).split('\n').forEach((ln, i) => { if (ln.trim()) this.log((i === 0 ? '📦 ' : '') + ln.trim()); });
          if (!dep || !dep.done) return; // ยังเดินไปหา NPC / เปิดหน้าคลัง → ทำต่อรอบถัดไป
          d = await P(GAME.page.voyagePanel); if (!d || d.error) return;
        }
        const pctNow = (d.bag && d.bag.pct) || 0;
        if (pctNow >= 95) { stopFn('กระเป๋าเกือบเต็ม ' + pctNow + '% และฝากเพิ่มไม่ได้ — ต้องเคลียร์คลัง/ซื้อแผ่นคลังก่อน'); return; }
        if (pctNow >= fullAt) this.log('⚠️ ฝากได้บางส่วน กระเป๋ายังอยู่ ' + pctNow + '% — จะลองฝากใหม่รอบถัดไป');
      }

      // === ขา 3: หา/สร้างสมุดอันดับเป้าหมาย ===
      // หมายเหตุสำคัญ: "รวมสมุด" ของเกมกิน 3 เล่มที่ **อันดับเดียวกันและความหายากเดียวกัน**
      // และร้านขายแต่แบบ "ปกติ" (rar 0) → นับรวมข้ามความหายากไม่ได้เด็ดขาด (เคยทำให้ซื้อเกิน+รวมไม่ออกวนลูป)
      const RAR = ['ปกติ', 'เมจิก', 'แรร์', 'Unique'];
      const need = d.trade || 3;
      const scan = () => {
        const cs = (d && d.charts) || [];
        const g = {};
        for (const c of cs) { const k = (c.tier | 0) + '|' + (c.r | 0); (g[k] = g[k] || []).push(c); }
        const groups = Object.keys(g).map((k) => { const p = k.split('|').map(Number); return { tier: p[0], r: p[1], n: g[k].reduce((a, c) => a + (c.n || 1), 0) }; });
        // เลือกลำดับความสำคัญ: อันดับ "สูงกว่าหรือเท่าที่ตั้งไว้" ก่อน (มี 15 ในกระเป๋า = ใช้ 15 ไม่ต้องซื้อ 14)
        return { cs, groups, best: GAME.pickChart(cs, tier) };
      };
      const logCharts = (tag) => {
        const cs = scan().cs;
        this.log('🧾 ' + tag + ': ' + (cs.length ? cs.map((c) => `อันดับ ${c.tier} ×${c.n || 1} [${RAR[c.r | 0] || 'r' + (c.r | 0)}]`).join(' + ') : 'ไม่มีสมุดในกระเป๋า'));
      };
      logCharts('สมุดในกระเป๋าตอนถึงโต๊ะ');

      // ร้านขายสมุดได้ถึงอันดับ d.buy (=14) → ซื้อตรงเล่มเดียวจบ
      // การ "รวม" เป็นการเสี่ยงดวง แพ้=เสีย 3 เล่ม จึงใช้เฉพาะอันดับที่ร้านไม่ขาย (15) เท่านั้น
      const BUY_MAX = d.buy || 14;
      let s = scan();
      let chart = s.best;
      if (!chart && tier <= BUY_MAX) {
        const unit = (d.prices && d.prices[tier - 1]) || 0;
        if (vf.minZen > 0 && d.zen != null && d.zen - unit < vf.minZen) { stopFn('เงินไม่พอซื้อสมุดอันดับ ' + tier + ' (เหลือ ' + (d.zen || 0).toLocaleString() + ' ต้องใช้ ' + unit.toLocaleString() + ')'); return; }
        this.log('🛒 ซื้อสมุดอันดับ ' + tier + ' ตรง ๆ (' + unit.toLocaleString() + ' Zen) — ร้านขายถึงอันดับ ' + BUY_MAX + ' ไม่ต้องเสี่ยงรวม');
        await P(GAME.page.voyAction, { what: 'buy', tier });
        for (let w = 0; w < 12; w++) { // รอของเข้ากระเป๋าจริง (เซิร์ฟช้าได้ถึง ~20 วิ — เดิมรอ 10 วิแล้วเข้าใจผิดว่าไม่เข้า)
          await sleep(1800);
          d = await P(GAME.page.voyagePanel); if (!d || d.error) continue;
          s = scan(); chart = s.best;
          if (chart) break;
        }
        if (!chart) { stopFn('ซื้อสมุดอันดับ ' + tier + ' ไม่เข้ากระเป๋า (เซิร์ฟไม่ตอบ — อาจติด limit รายวัน)'); return; }
        logCharts('หลังซื้อ');
      } else if (!chart) {
        const mixed = s.groups.filter((x) => x.tier === tier - 1);
        if (mixed.length > 1) this.log('ℹ️ มีสมุดอันดับ ' + (tier - 1) + ' ปนกันหลายความหายาก (' + mixed.map((x) => RAR[x.r] + ' ×' + x.n).join(', ') + ') — จะนับ/ซื้อเติมเฉพาะแบบปกติ');
        // กลุ่มที่รวมได้ทันที (ครบ need) — เอาความหายากสูงสุดก่อน
        let ready = s.groups.filter((x) => x.tier === tier - 1 && x.n >= need).sort((a, b) => b.r - a.r)[0] || null;
        // ยังไม่ครบ → ซื้อเติมลงกลุ่ม "ปกติ" (rar 0) เพราะร้านขายแบบเดียว
        let topUp = ready || s.groups.filter((x) => x.tier === tier - 1 && x.r === 0)[0] || { tier: tier - 1, r: 0, n: 0 };
        let attempts = 0;
        while (!chart && attempts++ < 8) {
          let have = topUp.n;
          if (have < need) {
            const unit = (d.prices && d.prices[tier - 2]) || 0;
            let buyFail = 0;
            while (have < need && buyFail < 3) {
              if (vf.minZen > 0 && d.zen != null && d.zen - unit < vf.minZen) { stopFn('เงินไม่พอซื้อสมุด (เหลือ ' + d.zen.toLocaleString() + ')'); return; }
              this.log('🛒 ซื้อสมุดอันดับ ' + (tier - 1) + ' แบบปกติ (' + have + '/' + need + ')' + (attempts > 1 ? ' [ลองครั้งที่ ' + attempts + ']' : ''));
              await P(GAME.page.voyAction, { what: 'buy', tier: tier - 1 });
              const prev = have;
              for (let w = 0; w < 5; w++) { // รอของเข้ากระเป๋าจริงก่อน (เซิร์ฟช้าได้) กันซื้อเกิน
                await sleep(1600);
                d = await P(GAME.page.voyagePanel); if (!d || d.error) continue;
                have = scan().groups.filter((x) => x.tier === tier - 1 && x.r === 0).reduce((a, x) => a + x.n, 0);
                if (have > prev) break;
              }
              if (have <= prev) buyFail++;
            }
            if (have < need) { stopFn('ซื้อสมุดไม่ผ่าน (เซิร์ฟไม่ตอบ — อาจติด limit รายวัน)'); return; }
          }
          logCharts('ก่อนรวมสมุด');
          this.log('🎲 รวมสมุดอันดับ ' + (tier - 1) + ' ×' + need + ' [แบบ' + RAR[topUp.r] + '] → อันดับ ' + tier + ' (เสี่ยงดวงครั้งที่ ' + attempts + ')');
          await P(GAME.page.voyAction, { what: 'trade', tier: tier - 1 });
          for (let w = 0; w < 8; w++) { // เซิร์ฟตอบ trade ช้าได้ — poll สูงสุด ~15 วิ
            await sleep(2000);
            d = await P(GAME.page.voyagePanel); if (!d || d.error) continue;
            s = scan(); chart = s.best;
            if (chart) break;
          }
          if (!chart) {
            logCharts('หลังรวม (ดวงไม่ออก)');
            this.log('🎲 รวมไม่สำเร็จ ซื้อใหม่ลองอีกที');
            s = scan();
            topUp = s.groups.filter((x) => x.tier === tier - 1 && x.r === 0)[0] || { tier: tier - 1, r: 0, n: 0 };
          }
        }
        if (!chart) { stopFn('รวมสมุด ' + (attempts - 1) + ' ครั้งไม่ผ่านเลย (ซวยจริง) — เติมเงินแล้วเปิดใหม่'); return; }
      }

      // === ขา 4: พยายามอัปเป็นแรร์ — ทำไม่ได้ให้ลงเรือตามสภาพ (ห้ามหยุดวงวน ห้ามวนลูป) ===
      //   ⚠️ ยกเว้นตอน "ออกเรือให้เควส" (มี ov): เควสแค่ต้องการจบการเดินทาง 1 ครั้ง
      //   การเผาออร์บเลื่อนขั้น 2 เม็ดกับสมุด 500 Zen = ขาดทุนชัดเจน (เจอจริงรอบ 22:09)
      if (ov && (chart.r | 0) < 2) this.log('🚢 (ทำเพื่อเควส ' + this._qVoy.qid + ') ข้ามการใช้ออร์บอัปแรร์ — ลงเรือแบบ ' + (RAR[chart.r | 0] || chart.r) + ' พอ เควสต้องการแค่จบการเดินทาง');
      else if ((chart.r | 0) < 2) {
        const o = d.orbs || {};
        // มีแค่ "เลื่อนขั้น" ตัวเดียวที่เปลี่ยน เมจิก → แรร์ (ปลุกพลัง/เสริมพลังช่วยไม่ได้)
        if (!(o.ascension >= 1)) {
          this.log('⚠️ ไม่มีออร์บเลื่อนขั้นในกระเป๋า → ลงเรือด้วยสมุดอันดับ ' + chart.tier + ' แบบ ' + (RAR[chart.r | 0] || chart.r) + ' ก่อน (มีแต่ปลุกพลัง/เสริมพลังอัปเป็นแรร์ไม่ได้)');
        } else {
          this.log('✨ ใช้ออร์บอัปสมุดอันดับ ' + chart.tier + ' → แรร์ (เลื่อนขั้นในกระเป๋า ' + (o.ascension || 0) + ' เม็ด)');
          const orbRes = await P(GAME.page.voyAction, { what: 'orb', s: chart.slot });
          this.log('✨ ' + ((orbRes && orbRes.msg) || 'ไม่มีผลตอบ'));
          await sleep(2000);
          d = await P(GAME.page.voyagePanel);
          if (d && !d.error) { s = scan(); if (s.best) chart = s.best; }
          if ((chart.r | 0) < 2) this.log('⚠️ อัปเป็นแรร์ไม่สำเร็จ (rar=' + (chart.r | 0) + ') — จะลงเรือตามที่มี ไม่หยุดวงวน');
        }
      }
      if (chart && (chart.tier | 0) > tier) this.log('📈 ใช้สมุดอันดับ ' + chart.tier + ' ที่มีอยู่ในกระเป๋า (สูงกว่าที่ตั้งไว้ ' + tier + ') — ประหยัดไม่ต้องซื้อใหม่');
      logCharts('สมุดที่จะใช้ลงเรือ');

      // === ขา 5: ออกเดินทาง ===
      this.log('🚢 ออกเดินทาง → เกาะ node ' + node + ' (สมุดอันดับ ' + chart.tier + ' แบบ ' + (RAR[chart.r | 0] || chart.r) + ')');
      const r = await P(GAME.page.voyAction, { what: 'sail', node, s: chart.slot });
      if (r && r.ok === false) this.log('⚠️ ' + r.msg);
      else {
        if (ov && this._qVoy) { this._qVoy.trips = (this._qVoy.trips || 0) + 1; this._qVoy.lastSailAt = Date.now(); this._qVoy.inParty = !!d.inParty; } // นับรอบ + เวลา + สถานะปาร์ตี้ (ไว้บอกสาเหตุตอนไม่เข้าเกาะ)
        setTimeout(() => { // ถึงเกาะแล้วเริ่มเดินทันที (ตรวจ onIsle ก่อน ไม่งั้นห้าม kick)
          this.page.evaluate(GAME.page.voyagePanel).then((on) => {
            if (on && on.onIsle) {
              return this.page.evaluate(GAME.page.voyRoamStart, this.roamOpts(this.S().voyFarm));
            }
          }).catch(() => {});
        }, 5000);
      }
    } catch (e) { this.state.lastError = e.message; } finally { this._voyBusy = false; }
  }

  async command(action, payload) {
    if (!this.page) return { ok: false, msg: 'บัญชียังไม่พร้อม' };
    if (action === 'farm-on') return this.farmStart();
    if (action === 'farm-off') return this.farmStop();
    if (action === 'town') { this.fieldRoamOff('ผู้ใช้สั่งกลับเมือง'); return this.goTown(); }
    if (action === 'farmmap') return this.farmMapMode(payload.map, payload.mode);
    if (action === 'farm-map-stop') { this.fieldRoamOff('ผู้ใช้กดหยุด'); return { ok: true, msg: 'หยุดโหมดฟาร์มmap แล้ว' }; }
    if (action === 'cycle-now') { this.runCycle(); return { ok: true, msg: 'เริ่มรอบขาย' }; }
    if (action === 'reload') { if (isDevOnly('reload')) return { ok: false, msg: 'ปิดใช้ในเวอร์ชันนี้' }; await this.page.reload({ waitUntil: 'domcontentloaded' }).catch(() => {}); return { ok: true, msg: 'รีเฟรชแล้ว' }; }
    if (action === 'dump-dom') { if (isDevOnly('dumpcode')) return { ok: false, msg: 'ปิดใช้ในเวอร์ชันนี้' }; const h = await this.page.content(); fs.writeFileSync(path.join(BASE_DIR, 'logs', 'dom-' + this.index + '.html'), h); return { ok: true, msg: 'ดึงโค้ดเกมแล้ว' }; }
    if (action === 'ws-clear') { if (isDevOnly('clearstats')) return { ok: false, msg: 'ปิดใช้ในเวอร์ชันนี้' }; return { ok: true, msg: 'ล้างสถิติแล้ว' }; }
    if (action === 'pause') { const want = (payload && payload.on !== undefined) ? !!payload.on : !this.state.paused; return this.setPause(want); }
    if (action === 'quest-run') { const r = await this.page.evaluate(GAME.page.questGo, (payload && (payload.qid || payload.quest)) || ''); if (r && r.ok) this.log('📜 (สั่งเอง) ' + r.msg); return r; }
    if (action === 'quest-stop') { const r = await this.page.evaluate(GAME.page.questStop).catch((e) => ({ ok: false, msg: e.message })); if (r && r.ok) { this._lvFarmUntil = 0; await this.page.evaluate(GAME.page.lvHuntStop).catch(() => {}); } return r; }
    if (action === 'quest-auto') { const q = Object.assign({}, this.S().quest || {}, { enabled: !!(payload && payload.on) }); const acc = (this.getGlobal().accounts || [])[this.index]; if (acc) { acc.settings = acc.settings || {}; acc.settings.quest = q; try { this.saveFn(); } catch (e) {} } return { ok: true, msg: q.enabled ? 'เปิดโหมดวิ่งเควสอัตโนมัติ' : 'ปิดโหมดวิ่งเควสอัตโนมัติ' }; }
    if (action === 'quest-refresh') { const st = await this.page.evaluate(GAME.page.questStatus).catch((e) => ({ ok: false, msg: e.message })); if (st && st.ok) { this.qDecorate(st); this._qState = Object.assign({ seenAt: Date.now() }, st); } return st; }
    return { ok: false, msg: 'คำสั่งไม่ถูกต้อง' };
  }

  async screenshot() { if (isDevOnly('view') || !this.page) return null; try { return await this.page.screenshot({ type: 'png' }); } catch (e) { return null; } }

  // 🧭 แหล่งเดียวของ "เพดานโซน" — เลเวลเรา + zoneSlack (ปุ่มบนแดชบอร์ด หน้าตั้งค่าเควส)
  //   fits(x) = เควสนี้อยู่ในโซนที่บอทยอมเดินไปทำ (area ของแมพเป้าหมาย <= เพดาน)
  //   ถ้ายังอ่านเลเวลไม่ได้ (lv=0) ถือว่าผ่านหมด — เดิมโค้ดก็ทำแบบนี้ กันบอทไม่เลือกเควสเลยตอนข้อมูลยังไม่มา
  qZone() {
    const qc = this.S().quest || {};
    const lv = (this.state.gameStats || {}).lv || 0;
    const zSlack = questZoneSlack(qc);
    return { lv, zSlack, ceiling: lv ? lv + zSlack : null, fits: (x) => !lv || x.area == null || x.area <= lv + zSlack };
  }
  // ติดป้ายให้แดชบอร์ด: x.far = เควสที่เกมยอม แต่บอทเมินเพราะโซนไกลเกินเพดาน (คนละเหตุผลกับ "เกมไม่ให้วิ่ง")
  qDecorate(st) {
    if (!st || !st.ok) return st;
    const z = this.qZone();
    st.ceiling = z.ceiling;
    (st.list || []).forEach((x) => { x.far = !!(x.canRun && !z.fits(x)); });
    return st;
  }

  status() {
    const s = this.state;
    return {
      index: this.index, name: s.name, enabled: s.enabled, running: s.running, connected: s.connected,
      pageTitle: s.pageTitle, farmOn: s.farmOn, paused: !!s.paused, ws: s.ws, gameStats: s.gameStats, traveling: s.traveling,
      travelNote: s.travelNote, lastFarmMap: s.lastFarmMap, lastError: s.lastError, headless: !!this.cfg.headless,
      autoWatch: { count: s.autoWatch.count }, potion: { count: s.potion.count },
      wb: this._wbState || null,
      fRoam: this._fRoam ? { mode: this._fRoam.mode, map: this._fRoam.map, minAgo: Math.round((Date.now() - this._fRoam.t0) / 60000), pts: (this._fRoam.last && this._fRoam.last.pts) || 0, i: (this._fRoam.last && this._fRoam.last.i) || 0, cycles: (this._fRoam.last && this._fRoam.last.cycles) || 0, here: (this._fRoam.last && this._fRoam.last.map) != null ? String(this._fRoam.last.map) : null } : null,
      quest: this._qState ? { lv: this._qState.lv, next: this._qState.next, tracked: this._qState.tracked, running: this._qState.running, whyNot: this._qState.whyNot, total: this._qState.total, ceiling: this._qState.ceiling, list: this._qState.list || [], voyFor: this._qVoy ? { qid: this._qVoy.qid, name: this._qVoy.name, tier: this._qVoy.tier, node: this._qVoy.node, trips: this._qVoy.trips || 0, minAgo: Math.round((Date.now() - this._qVoy.t0) / 60000) } : null, lvFarmLeftSec: this._lvFarmUntil && this._lvFarmUntil > Date.now() ? Math.round((this._lvFarmUntil - Date.now()) / 1000) : 0 } : null,
      settings: this.cfg.settings || null, log: this.logs.slice(-40),
      uptimeSec: Math.floor((Date.now() - s.startedAt) / 1000),
    };
  }

  async stop() { this.timers.forEach((stop) => { try { stop(); } catch (e) {} }); this.timers = []; this.state.farmOn = false; this.state.running = false; try { if (this.browser) await this.browser.close(); } catch (e) {} this.browser = null; this.page = null; }
}

module.exports = { Account };
