// ============================================================
//  buildinfo.js — ค่าประจำบิลด์ (CaelmoraBot)
// ------------------------------------------------------------
//  เครื่องคนพัฒนา (เครื่องคุณ): release=false, autoUpdate=false
//     → ไม่ดึงอัปเดตตัวเอง + มีปุ่ม 📦 ปล่อยเวอร์ชันใหม่บนแดชบอร์ด
//
//  ตอนกด "📦 ปล่อยเวอร์ชันใหม่" ระบบจะคัดโค้ดไปสร้าง zip ของเพื่อน
//  แล้วเขียน buildinfo.js "ใน zip นั้น" เป็น autoUpdate=true (และ release
//  ตามสวิตช์ล็อกเครื่อง) — ไฟล์ในเครื่องคุณไม่ถูกเปลี่ยน ยกเว้นเลขเวอร์ชัน
//
//  เลขเวอร์ชันต้องเพิ่มขึ้นทุกครั้ง (เทียบแบบ 1.0.0 → 1.0.1) ไม่งั้นเพื่อนไม่อัปเดต
// ============================================================
module.exports = {
  app: 'CaelmoraBot',
  version: '1.0.6',

  // true = เวอร์ชันเพื่อน (ล็อกเครื่อง + ซ่อนเมนู dev) | false = dev (ครบทุกอย่าง)
  release: false,

  // 🔗 URL ไฟล์ licenses.json บน GitHub (repo ที่ตั้งไว้ = vhagarbot-licenses)
  //    ตัว VhagarBot "อ่าน" ไฟล์นี้ / บอทอนุมัติ Discord "เขียน" ไฟล์เดียวกัน
  licenseUrl: 'https://raw.githubusercontent.com/sixdayth/vhagarbot-licenses/main/licenses.json',

  // ---------- 🔄 ระบบอัปเดตอัตโนมัติ (เวอร์ชันเพื่อนจะ fetch ตัวนี้เอง) ----------
  //    ไฟล์ version.json รูปแบบ: { "latest": "1.0.1", "url": "<ลิงก์ zip>", "notes": "มีอะไรใหม่" }
  updateUrl: 'https://raw.githubusercontent.com/sixdayth/vhagarbot-licenses/main/caelmora/version.json',
  updateRepo: 'sixdayth/vhagarbot-licenses', // repo สาธารณะ (เพื่อนไม่ต้องมี token)
  updateBranch: 'main',
  updatePath: 'caelmora',                    // โฟลเดอร์ใน repo ที่เก็บ zip + version.json
  autoUpdate: true,                         // false = เครื่อง dev (ห้ามดึงตัวเอง) | true = เวอร์ชันเพื่อน (ตอนปล่อยอัปเดตจะเขียนเป็น true ให้อัตโนมัติ)

  // ถ้าเน็ตหลุด อนุญาตให้ใช้ต่อได้ภายในกี่ชั่วโมง (นับจากที่ตรวจสำเร็จล่าสุด)
  graceHours: 72,

  // เมนู dev ที่ซ่อน/ปิดในเวอร์ชันเพื่อน (ปล่อยเป็นค่า default ได้)
  devOnly: ['packet', 'dumpcode', 'clearstats', 'view', 'reload'],
};
