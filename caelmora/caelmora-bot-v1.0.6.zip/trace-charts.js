// trace-charts.js — ตามรอย "สมุดนำร่อง" จาก log แพ็กเก็ตจริง (อ่านอย่างเดียว)
const fs = require('fs');
const readline = require('readline');

const FILE = process.argv[2] || 'C:\\Users\\meiji\\Documents\\caelmora-bot\\logs\\ws-0.jsonl';
const SINCE = process.argv[3] || '2026-10-28T00:00';   // UTC
const CHART_MIN = 14848, CHART_MAX = 14900;
const ORB = { 11778: 'ปลุกพลัง', 11779: 'เสริมพลัง', 11781: 'เลื่อนขั้น', 11782: 'นักปราชญ์' };

function localBkk(iso) { const d = new Date(iso); return d.toLocaleString('th-TH', { timeZone: 'Asia/Bangkok', hour12: false }); }

(async () => {
  const rl = readline.createInterface({ input: fs.createReadStream(FILE), crlfDelay: Infinity });
  let out = 0;
  const events = [];
  for await (const line of rl) {
    if (!line || line.length < 20) continue;
    let rec; try { rec = JSON.parse(line); } catch (e) { continue; }
    if (!rec.t || rec.t < SINCE) continue;
    let d; try { d = rec.data ? JSON.parse(rec.data) : null; } catch (e) { continue; }
    if (!d) continue;
    const dir = rec.dir;

    // คำสั่งที่บอท/เกมส่งออกแบบชัดเจน
    if (d.t === 'voy' && d.op) { events.push({ at: rec.t, dir, txt: 'voy op=' + d.op + (d.tier ? ' tier=' + d.tier : '') + (d.node != null ? ' node=' + d.node : '') + (d.s != null ? ' slot=' + d.s : '') }); continue; }
    if (d.t === 'cur') {
      const isOrb = ORB[d.s_id] || '';
      events.push({ at: rec.t, dir, txt: 'cur (ใช้ออร์บ/ย้าย) s=' + d.s + ' → to=' + d.to + (isOrb ? ' [' + isOrb + ']' : '') });
      continue;
    }
    // แพ็กเก็ตกระเป๋า: หา item id ที่เป็นสมุด
    if (d.t === 'inv' || d.i !== undefined || d.t === 'item' || d.add || d.del || d.rm) {
      const s = JSON.stringify(d);
      const ids = [];
      const re = /"?(?:id|a|n)"?:(\d{5})/g; let m;
      while ((m = re.exec(s))) { const v = +m[1]; if (v >= CHART_MIN && v <= CHART_MAX) ids.push(v); }
      if (ids.length) events.push({ at: rec.t, dir, txt: 'inv touched chart ' + ids.map((x) => 'อันดับ ' + (x - 14847)).join(',') + '  ⟨' + d.t + '⟩' });
    }
    // สถานะโต๊ะนำร่อง: lists charts
    if (d.t === 'voy' && Array.isArray(d.charts)) {
      events.push({ at: rec.t, dir, txt: 'voy state: run=' + (d.run ? (d.run.node != null ? 'node' + d.run.node : 'มีทริป') : 'ไม่มี') + ' · โต๊ะเห็นสมุด ' + d.charts.length + ' เล่ม ' + JSON.stringify(d.charts).slice(0, 120) });
    }
    out++;
  }

  console.log('อ่าน ' + out.toLocaleString() + ' แพ็กเก็ตตั้งแต่ ' + SINCE + ' (UTC) → เจอเหตุการณ์น่าสนใจ ' + events.length + ' รายการ\n');
  console.log('=== เรียงเวลา (เวลาไทย) ===');
  for (const e of events) console.log(localBkk(e.at) + '  [' + e.dir + ']  ' + e.txt);
})().catch((e) => { console.error('ERR', e.message); process.exit(1); });
