@echo off
title Caelmora Bot
cd /d "%~dp0"

REM ============================================================
REM  ตัวเปิดบอท — ไฟล์นี้ "ถาวร" ระบบอัปเดตอัตโนมัติจะไม่ทับมัน
REM  หน้าที่: เช็ค Node.js → ติดตั้ง dependency ครั้งแรก →
REM           เปิด node server.js → ถ้าบอทอัปเดตตัวเองเสร็จ (มีไฟล์ .restart)
REM           ให้วนเปิดใหม่อัตโนมัติ
REM  ห้ามแก้/เปลี่ยนชื่อไฟล์นี้หลังปล่อยให้นเพื่อน
REM  ถ้าจำเป็นจริง ๆ ให้ส่ง zip เวอร์ชันใหม่ไปให้ลงทับแทน
REM ============================================================

echo ==========================================
echo    CAELMORA BOT - DASHBOARD
echo ==========================================
echo.

REM ---- check Node.js installed ----
where node >nul 2>nul
if errorlevel 1 goto NONODE
where npm >nul 2>nul
if errorlevel 1 goto NONODE
goto HAVENODE

:NONODE
echo [X] Node.js is NOT installed on this computer.
echo.
echo     HOW TO FIX (do these 3 steps):
echo       1. Download Node.js here:  https://nodejs.org/en/download
echo          (click the big green LTS button, Windows .msi installer)
echo       2. Install it - just press Next / Next / Finish
echo       3. CLOSE this black window completely,
echo          then double-click start.bat AGAIN
echo.
echo     (Thai: ยังไม่ได้ลง Node.js - โหลดตามลิงก์ด้านบน ติดตั้งแล้ว
echo      ปิดหน้าต่างดำนี้ให้สนิท แล้วดับเบิลคลิก start.bat ใหม่อีกครั้ง)
echo.
pause
exit /b 1

:HAVENODE
if not exist "node_modules" (
    echo [1/2] First-time install, please wait 1-2 minutes...
    call npm install
    if errorlevel 1 (
        echo.
        echo INSTALL FAILED - check your internet connection, then run this file again.
        echo If you are in Thailand and it keeps failing, try:
        echo     npm config set registry https://registry.npmjs.org
        echo then run start.bat again.
        pause
        exit /b 1
    )
    echo.
)

echo   Game window + Dashboard (http://localhost:8900) will open automatically.
echo   See GUIDE-TH.md for the Thai step-by-step manual.
echo.
echo   IMPORTANT: do NOT close this black window - that stops the bot.
echo   You can minimize it. To stop the bot press Ctrl+C here.
echo.

:loop
node server.js

REM ---- บอทอัปเดตตัวเองเสร็จ? เปิดใหม่อัตโนมัติ (เพื่อนไม่ต้องทำอะไร) ----
if exist ".restart" (
    echo.
    echo   [update] installed a new version - reopening automatically in 3 seconds...
    echo.
    timeout /t 3 /nobreak >nul
    goto loop
)

echo.
echo Bot stopped.
pause
