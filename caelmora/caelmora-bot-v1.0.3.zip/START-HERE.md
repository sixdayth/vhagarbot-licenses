# 🎮 CaelmoraBot — คู่มือเริ่มต้น (อ่านไฟล์นี้เป็นอันดับแรก)

**เกม:** Caelmora / Crimson Vow — MMORPG isometric บนเบราว์เซอร์
**URL:** https://caelmora.com/
**Folder:** `C:\Users\meiji\Documents\caelmora-bot`
**Port:** `8900` (VhagarBot/Night Camp ที่ 8899 รันพร้อมกันได้)

---

## 🚀 เริ่มใช้งาน (3 ขั้นตอน)

### 1. ดับเบิลคลิก `start.bat`
จะเห็น:
- หน้าต่างสีดำ (terminal) — **อย่าปิด** (นั่นคือตัวบอท)
- หน้าต่าง Chrome ใหม่ เปิดหน้า caelmora.com อัตโนมัติ
- หน้า Dashboard ที่ `http://localhost:8900` เปิดเอง

ถ้า Chrome/Dashboard ไม่เด้งอัตโนมัติ → เปิดเอง:
- เกม: https://caelmora.com/ (ในหน้าต่าง Chrome ที่บอทเปิด)
- แดชบอร์ด: http://localhost:8900/

### 2. **ล็อกอินในเกม** (ครั้งแรกเท่านั้น)
ในหน้าต่าง Chrome ของบอท → ใส่ชื่อผู้ใช้/รหัสผ่าน → กด **"Enter game"** (หรือ "Play now (Guest)") → เลือกตัวละคร → เข้าเกม

- โพรไฟล์ถูกเก็บไว้ที่ `caelmora-bot\profiles\Caelmora-1\` — ครั้งต่อไป **บอทจะเข้าเอง**
- Cloudflare ของ caelmora บล็อก Chrome แบบซ่อนหน้าต่าง (headless) — ดังนั้น**ต้องใช้แบบเห็นหน้าต่าง** (ห้ามแก้ config `headless: true`)

### 3. **กลับไปดู Dashboard** ที่ `http://localhost:8900`
- การ์ด "Caelmora-1" จะแสดง Lv, HP/MP, แผนที่, Zen (เงิน), ยา
- กด **"เปิด AUTO ในเกม"** → บอทจะกดปุ่ม Bot ของเกมเอง (หรือ toggle `S.auto`)
- ตั้งค่าเพิ่มเติม: ปุ่ม **"⚙ ตั้งค่า"**

---

## 🛠 บอทนี้ทำอะไรได้ (Phase 1 — ตอนนี้)

| ฟีเจอร์ | สถานะ | หมายเหตุ |
|---|---|---|
| เปิดหลายบัญชี (Chrome คนละโพรไฟล์) | ✅ ใช้งานได้ | เพิ่มใน `config.json` → `accounts[]` |
| Patch `main.js` ให้เปิด `window.S` / `__net` / `__settings` | ✅ ทำงาน | เห็น log `🔧 patch main.js → V=true` |
| อ่าน Lv/HP/MP/Zen/แผนที่/ยา จากเกมสด | ✅ | ทุก ~1 วินาที |
| กดยา HP อัตโนมัติ (ปุ่ม `1`) เมื่อ HP < 50% | ✅ | มี cooldown แบบคน |
| เปิด AUTO/Bot ในเกมอัตโนมัติ | ✅ | ตรวจจับ `S.bot` / `S.auto` แล้วกดให้ |
| กลับเมือง Emberwatch (map 0) | ✅ | เรียก `__net.travel(0)` |
| วาร์ปไป map อื่น (Hollow Deep / Frostreach / Verdant Rise) | ✅ | `__net.wpGo(mapId)` |
| Auto-town เมื่อกระเป๋าเต็ม ≥ 90% | ⚠️ ตรวจจับกระเป๋า | อ่าน `.size` ของ `S.panels.inv` — ยังไม่ confirm ค่า bagCap จริง |
| หน่วงแบบคน (humanDelay) | ✅ | ทุก action มี jitter 2-5 วิ (ค่า default) |
| Reconnect อัตโนมัติเมื่อหลุด | ⚠️ best-effort | กด `#btn-guest` / `#btn-login` — ยังไม่ map ตัวเลือกตัวละคร |
| **ขายของอัตโนมัติ** | ❌ **Phase 2** | ต้องแกะ NPC/SHOP/inventory item type ก่อน |
| **ซื้อยาอัตโนมัติ** | ❌ **Phase 2** | ต้องหา item id ของ flask HP/MP ใน `S.items` |
| **เลือกตัวละครอัตโนมัติ** | ❌ **Phase 2** | ต้องดู DOM จริงตอนจอ character select |

---

## 🔬 เทคนิคหลัก: V-patch

เกม Caelmora ใช้ ES module — `const H` (state container) เป็น private ในโมดูล
ผู้พัฒนาเกมใส่ **debug hook** ไว้ใต้เงื่อนไข `V` (localhost + `?debug`):
```js
const V = /^(localhost|127\.0\.0\.1|\[::1\]|.+\.localhost|.+\.test)$/
            .test(location.hostname) && location.search.includes('debug');
if (V) {
  window.S = H;                    // ← state ทั้งหมด (hero/info/stats/ents/…)
  window.__net = ae;               // ← { sell, travel, wpGo, buy, flask, attack, cast, … }
  window.__settings = SETTINGS;    // ← autoPotion/autoSkill/autoRes/loot/filters/…
  window.__bot = cg;               // ← in-game bot handle
  window.__botWants / __botWhy / __botTurn
  window.__walk / __roll / __pick  // ← helper สำหรับเดิน/กลิ้ง/เก็บของ
}
```

**Bอทนี้ patch `js/main.js` ตอนโหลด:**
- `accounts.js` เรียก `GAME.preLaunch(page, acct)` ก่อน `page.goto`
- เปิด `page.setRequestInterception(true)` → fetch main.js จาก Node (มี User-Agent+Referer ผ่าน Cloudflare) → string-replace `const V=/…/` → `const V=!0` → `req.respond`
- **ผล:** ทุก `page.evaluate()` เข้าถึง `window.S` และ `window.__net` ได้ตรง ๆ — ไม่ต้อง decode binary WebSocket packet

**ไฟล์ที่เกี่ยวข้อง:**
- `game-adapter.js` → `preLaunch` + `page.*` ทุกฟังก์ชัน
- `accounts.js` → call site `GAME.preLaunch(this.page, this)` บรรทัด ~91

---

## 🧪 Debug / ตรวจสอบ

### ดู log ของบอท
```bash
cd C:\Users\meiji\Documents\caelmora-bot
node server.js
```
ควรเห็น: `🔧 patch main.js → V=true (เปิด window.S / __net / __settings)`

### ทดสอบ patch แบบแยก
```bash
node smoke-test.js
```
เปิด Chrome (visible) → โหลดเกม → ตรวจว่า `window.S` เป็น object → ปิดอัตโนมัติ
Output: `logs/smoke.png` (screenshot)

### เปิด DevTools ในหน้าเกม
ใน Chrome ของบอท กด **F12** → Console → พิมพ์:
```js
window.S                                    // ← object state ทั้งหมด
window.S.hero                               // ← entity player (name, lvl, rx, ry)
window.S.info                               // ← { life, mana, maxLife, maxMana }
window.S.stats                              // ← { level, exp, nextExp, points, ... }
window.S.mapArea                            // ← current map id (0..3)
window.S.mapTh                              // ← ชื่อไทยของแมพ
window.__net.wpGo(1)                        // ← วาร์ปไป Hollow Deep
window.__settings.autoPotion                // ← เปิด/ปิด auto potion ของเกมเอง
window.__settings.bot                       // ← ค่า config ของ in-game bot
```

---

## ⚙ Config (`config.json`)

| ค่า | ความหมาย |
|---|---|
| `gameUrl` | `https://caelmora.com/` |
| `accounts[].name` | ชื่อโพรไฟล์ Chrome (แต่ละบัญชี = 1 โฟลเดอร์ใน `profiles/`) |
| `accounts[].headless` | **ต้องเป็น `false`** — Cloudflare บล็อก headless |
| `accounts[].farmMap` | mapId (0/1/2/3) ให้บอทกลับไปฟาร์มหลังขายของ |
| `humanDelay.minSec/maxSec` | หน่วงระหว่าง action (แนะนำ 2-5 วิ) |
| `autoPotion.threshold` | % HP ที่inggดยา (0.5 = 50%) |
| `autoPotion.key` | ปุ่มกดยา — **Caelmora flask ผูกกับ slot 1-8** ลอง "1" |
| `autoWatch.townMaps` | แมพปลอดภัย (ห้ามกด AUTO / กินยา) = `["0"]` (Emberwatch) |
| `autoTown.fullPct` | % กระเป๋าที่จะกลับเมืองขาย (90) |
| `wsLog` | เก็บ log ws frame (`logs/ws-N.jsonl`) — ปิดได้ถ้าเปลืองดิสก์ |

**⚠️ ไม่มี auto-save** — แก้ค่าแล้วต้องกดปุ่ม **"💾 บันทึก"** ในแดชบอร์ดเสมอ

---

## 🗺 แผนที่รู้จัก (Phase 1 hardcode)

| id | ชื่อ | Lv โดยประมาณ | หมายเหตุ |
|---|---|---|---|
| 0 | Emberwatch | 1-15 | เมืองหลัก — spawn |
| 1 | Hollow Deep | 15-30 | |
| 2 | Frostreach | 30-45 | |
| 3 | Verdant Rise | 45-60 | |

*(มาจาก `CONFIG.maps` ใน js/config.js — ถ้าเกมเพิ่ม map ใหม่ต้อง update `listMaps` ใน `game-adapter.js`)*

---

## ⚠️ คำเตือน

- การใช้บอท**อาจผิด ToS** ของเกม — ความเสี่ยงแบนบัญชีเป็นของคุณ
- ใช้พอประมาณ อย่ารัน 24 ชม. ติ๊ดเดียว — เปิด-ปิดเป็นครั้งคราว
- Caelmora มี **bot ในตัวเกม** (`SETTINGS.bot`, "Bot" menu) ที่อาจเพียงพอ — CaelmoraBot only adds **multi-account + monitoring + orchestration**

---

## 📋 Phase 2 (สิ่งที่ต้องทำต่อ)

1. **แกะ shop/sell** — ดู `SellBox` + `Panels.inv` + item DB (`data/items.json`)
2. **ซื้อ flask อัตโนมัติ** — หา item id ของยา HP/MP ใน `S.items` + NPC shop
3. **เลือกตัวละครอัตโนมัติ** — DOM ของ `initCharScreens` / `showCharSelect` (ใน js/ui/charscreens.js)
4. **ตั้งค่า in-game bot (`window.__settings.bot` / `window.__botWants`)** จากแดชบอร์ด — ส่งค่า loot filter, target monster, skill rotation ฯลฯ ให้เกมรันเอง
5. **เพิ่มพอร์เทรต + expBar + mapName ภาษาไทย** ในการ์ด dashboard
6. **รองรับ map id สูงกว่า 3** (ถ้าเกมอัปเดตเพิ่ม) — เปลี่ยน `listMaps` ให้ดึงจาก `window.S.maps` (ถ้ามี)

---

## 🔗 แหล่งข้อมูล

- เกม: https://caelmora.com/
- wiki: https://caelmora.com/wiki/ (ถ้าเปิด)
- Discord ผู้พัฒนา: https://discord.gg/5gkmaDSBaf
- แม่แบบโครง: `C:\Users\meiji\Documents\VhagarBot-template\` (ดู `ADAPTER-GUIDE.md`)
