// ============================================================
//  license.js — ระบบล็อกเครื่อง + ตรวจสิทธิ์ออนไลน์ (VhagarBot)
// ------------------------------------------------------------
//  หลักการทำงาน (แบบออนไลน์ผ่านไฟล์ JSON บน GitHub):
//   1) เครื่องเพื่อนคำนวณ "Machine Code" (6 ตัว) จากฮาร์ดแวร์ (MAC/ชื่อเครื่อง/CPU/RAM)
//   2) เพื่อนส่ง Machine Code มาให้คุณ
//   3) คุณเพิ่ม Machine Code นั้นลงในไฟล์ licenses.json บน GitHub (กด commit) = อนุมัติ
//   4) ตอนเปิดบอท จะ fetch ไฟล์ JSON นั้น:
//        - มี code + ไม่หมดอายุ  → ใช้งานได้
//        - ไม่มี code            → ขึ้นหน้า "ส่งโค้ดมาให้ dev"
//        - มี code แต่หมดอายุ     → ปฏิเสธ
//        - คุณลบ code ออกจากไฟล์ → ครั้งถัดไปที่บอทตรวจ (หรือรีสตาร์ท) = ใช้ไม่ได้ (Kill Switch)
//   5) ถ้าเน็ตหลุด จะยังใช้ได้ภายใน "graceHours" นับจากที่ตรวจสำเร็จล่าสุด (กันเพื่อนเน็ตล่มแล้วใช้ไม่ได้)
//
//  ไฟล์ licenses.json (ตัวอย่างอยู่ในโฟลเดอร์):
//  {
//    "licenses": {
//      "A1B2C3": { "user": "เพื่อนก", "expires": "2026-12-31" },
//      "X9Y8Z7": { "user": "เพื่อนข", "expires": "" }        // เว้นว่าง = ไม่หมดอายุ
//    }
//  }
// ============================================================
'use strict';
const os = require('os');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const https = require('https');
const http = require('http');
const buildinfo = require('./buildinfo');

// โฟลเดอร์ที่แอปอยู่ (ตอนเป็น .exe ด้วย pkg ให้ใช้โฟลเดอร์เดียวกับไฟล์ exe)
const APP_DIR = process.pkg ? path.dirname(process.execPath) : __dirname;
const CACHE_FILE = path.join(APP_DIR, '.license-cache.json');
const B32 = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'; // ตัด I,L,O,0,1 ออก กันสับสน

// ---------- Machine Code (6 ตัว อ่านง่าย) ----------
function machineFingerprint() {
  const ifaces = os.networkInterfaces();
  const macs = [];
  for (const k of Object.keys(ifaces)) {
    for (const a of (ifaces[k] || [])) {
      if (a.mac && a.mac !== '00:00:00:00:00:00') macs.push(a.mac);
    }
  }
  const cpus = os.cpus();
  const parts = [
    os.hostname(),
    (os.userInfo && os.userInfo().username) || '',
    (cpus[0] && cpus[0].model) || '',
    String(cpus.length),
    String(os.totalmem()),
    macs.sort().join(','),
    process.platform,
  ];
  return parts.join('|');
}

function toBase32(buf, len) {
  // แปลง byte → อักขระ base32 (5 บิต/ตัว)
  let bits = 0, value = 0, out = '';
  for (const b of buf) {
    value = (value << 8) | b; bits += 8;
    while (bits >= 5) { out += B32[(value >>> (bits - 5)) & 31]; bits -= 5; }
  }
  if (bits > 0) out += B32[(value << (5 - bits)) & 31];
  return out.slice(0, len);
}

function machineCode() {
  const hash = crypto.createHash('sha256').update(machineFingerprint()).digest();
  return toBase32(hash, 6); // เช่น "K7M2X9"
}

// ---------- fetch JSON ----------
function fetchJson(url, timeoutMs = 8000) {
  return new Promise((resolve, reject) => {
    const mod = url.startsWith('https') ? https : http;
    const req = mod.get(url, { timeout: timeoutMs, headers: { 'Cache-Control': 'no-cache', 'User-Agent': 'VhagarBot' } }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return fetchJson(res.headers.location, timeoutMs).then(resolve, reject); // ตาม redirect (GitHub raw)
      }
      if (res.statusCode !== 200) { res.resume(); return reject(new Error('HTTP ' + res.statusCode)); }
      let data = '';
      res.on('data', (c) => { data += c; if (data.length > 2e6) req.destroy(); });
      res.on('end', () => { try { resolve(JSON.parse(data)); } catch (e) { reject(new Error('JSON ไม่ถูกต้อง')); } });
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(new Error('timeout')); });
  });
}

// ---------- cache (สำหรับ grace period ตอนเน็ตหลุด) ----------
function readCache() { try { return JSON.parse(fs.readFileSync(CACHE_FILE, 'utf8')); } catch (e) { return null; } }
function writeCache(obj) { try { fs.writeFileSync(CACHE_FILE, JSON.stringify(obj)); } catch (e) {} }

// ---------- ตรวจสิทธิ์ ----------
// คืนค่า { status, code, user, expires, reason }
//   status: 'ok' | 'unapproved' | 'expired' | 'net' | 'disabled' | 'notconfigured'
async function verify() {
  const code = machineCode();
  if (!buildinfo.release) return { status: 'ok', code, reason: 'dev' }; // dev build = ข้าม
  const url = buildinfo.licenseUrl;
  if (!url || url.includes('USERNAME/REPO')) return { status: 'notconfigured', code, reason: 'ยังไม่ได้ตั้ง URL ไฟล์ license' };

  let doc;
  try {
    doc = await fetchJson(url);
  } catch (e) {
    // เน็ตหลุด → ใช้ cache ถ้ายังอยู่ใน grace
    const c = readCache();
    const graceMs = (buildinfo.graceHours || 72) * 3600 * 1000;
    if (c && c.ok && c.code === code && (Date.now() - c.at) < graceMs) {
      return { status: 'ok', code, user: c.user, expires: c.expires, reason: 'grace:' + e.message };
    }
    return { status: 'net', code, reason: e.message };
  }

  const entry = (doc.licenses && doc.licenses[code]) || null;
  const now = Date.now();
  if (!entry) return { status: 'unapproved', code };
  if (entry.disabled) { writeCache({ ok: false, code, at: now }); return { status: 'disabled', code, user: entry.user }; }
  if (entry.expires) {
    const exp = new Date(entry.expires).getTime();
    if (!isNaN(exp) && now > exp) return { status: 'expired', code, user: entry.user, expires: entry.expires };
  }
  writeCache({ ok: true, code, user: entry.user, expires: entry.expires || '', at: now });
  return { status: 'ok', code, user: entry.user, expires: entry.expires || '' };
}

module.exports = { machineCode, verify };
