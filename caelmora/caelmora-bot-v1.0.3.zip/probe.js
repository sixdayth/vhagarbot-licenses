// probe.js — เชื่อมเข้า Chrome ของบอทที่กำลังรัน (read-only!) เพื่อหา field จริงของ map/class/bag
'use strict';
const puppeteer = require('puppeteer-core');
(async () => {
  const browser = await puppeteer.connect({ browserURL: 'http://127.0.0.1:54893', defaultViewport: null });
  const pages = await browser.pages();
  const page = pages.find((p) => /caelmora/.test(p.url()));
  if (!page) { console.log('ไม่เจอหน้า caelmora ใน', pages.map((p) => p.url())); process.exit(1); }
  const out = await page.evaluate(() => {
    const S = window.S; if (!S) return { err: 'no window.S' };
    const t = (v) => (v === null ? 'null' : Array.isArray(v) ? 'array[' + v.length + ']' : typeof v);
    const small = (o, n) => { try { return JSON.parse(JSON.stringify(o), (k, v) => (typeof v === 'object' && v !== null && Object.keys(v).length > (n || 12) ? '[' + Object.keys(v).length + ' keys]' : v)); } catch (e) { return String(o).slice(0, 200); } };
    const r = {
      mapArea: { type: t(S.mapArea), val: small(S.mapArea) },
      mapTh: { type: t(S.mapTh), keys: S.mapTh ? Object.keys(S.mapTh).length : 0, sample: small(S.mapTh, 8) },
      mapEn: { type: t(S.mapEn), keys: S.mapEn ? Object.keys(S.mapEn).length : 0 },
      page: { type: t(S.page), val: S.page },
      town: { type: t(S.town), keys: S.town && typeof S.town === 'object' ? Object.keys(S.town).slice(0, 15) : String(S.town) },
      towns: { type: t(S.towns), val: small(S.towns, 10) },
      gsMap: (() => { try { return { type: t(S.gs && S.gs.map), val: S.gs && S.gs.map }; } catch (e) { return 'err'; } })(),
      me: { type: t(S.me), cls: S.me && S.me.cls, keys: S.me ? Object.keys(S.me).slice(0, 25) : [] },
      classStats: { type: t(S.classStats), keys: S.classStats ? Object.keys(S.classStats).slice(0, 20) : [] },
      selChar: { type: t(S.selChar), val: small(S.selChar, 10) },
      heroLvl: S.hero && S.hero.lvl, heroName: S.hero && S.hero.name,
      bagCfg: small(S.bagCfg),
      invSize: (() => { try { return S.panels.inv.size; } catch (e) { return 'err'; } })(),
      info: small(S.info, 20),
      statsKeys: S.stats ? Object.keys(S.stats).slice(0, 25) : [],
      heroKeys: S.hero ? Object.keys(S.hero).slice(0, 30) : [],
      topKeys: Object.keys(S).slice(0, 80),
    };
    return r;
  });
  console.log(JSON.stringify(out, null, 1));
  browser.disconnect();
})().catch((e) => { console.log('probe fail:', e.message); process.exit(1); });
