/*
 * ============================================================
 *  CaelmoraBot — server.js (ตัวจัดการหลายบัญชี / multi-account)
 * ------------------------------------------------------------
 *  - อ่าน config.accounts[] → สร้าง Account (Chrome+โปรไฟล์+ผู้เฝ้า ต่อตัว)
 *  - ค่า setting รวม (humanDelay/autoPotion/autoWatch/sellConfig/autoTown/enterCharacter/autoFarm) ใช้ร่วมกัน
 *  - หน้าควบคุม (dashboard) ที่ http://localhost:8900 แสดงการ์ดแต่ละบัญชี + เพิ่ม/ลบ/คุมแยกตัว
 *    (ใช้ port 8900 เพื่อยิงคู่กับ VhagarBot/Night Camp ที่ 8899 ได้พร้อมกัน)
 *  - เวอร์ชันเพื่อน (buildinfo.release): ล็อกเครื่องผ่าน GitHub + ซ่อนเมนู dev
 * ============================================================
 */
'use strict';
const fs = require('fs');
const path = require('path');
const http = require('http');
const { exec } = require('child_process');
const buildinfo = require('./buildinfo');
const license = require('./license');
const updater = require('./updater');
const { Account } = require('./accounts');
const GAME = require('./game-adapter');

const BASE_DIR = process.pkg ? path.dirname(process.execPath) : __dirname;
const CONFIG_FILE = path.join(BASE_DIR, 'config.json');
const RELEASE = !!buildinfo.release;

// เครื่องคนพัฒนา = เครื่องที่ไม่ได้ตั้ง autoUpdate (ตอนปล่อยแพ็กเกจให้เพื่อน จะถูกเขียนเป็น true เสมอ)
// publish.js ไม่ได้ติด zip ไปกับเพื่อน → โหลดเฉพาะเครื่อง dev ไม่งั้นบอทเพื่อนจะพังตั้งแต่เปิด (Cannot find module)
const PUB_STUB = { tokenInfo: () => ({ set: false, masked: '' }), saveToken: () => false, publish: async () => ({ ok: false, msg: 'เครื่องนี้ไม่ใช่เครื่องคนพัฒนา' }), PUB_DIR: '' };
let publisher = PUB_STUB;
let DEV_MACHINE = false;
if (!buildinfo.autoUpdate) {
  try { publisher = require('./publish'); DEV_MACHINE = true; }
  catch (e) { console.log('[publish] ไม่พบเครื่องมือปล่อยเวอร์ชัน (' + e.message + ') — จะใช้เครื่องนี้เป็นคนพัฒนาไม่ได้'); }
}
const APP_NAME = buildinfo.app || 'VhagarBot';
const DEV_ONLY = new Set(buildinfo.devOnly || []);
const PORT = process.env.NB_PORT || 8900;

// เครื่องใหม่ยังไม่มี config.json → สร้างจาก template ให้ก่อน (แพ็กเกจเพื่อนส่งมาเป็น config.example.json)
if (!fs.existsSync(CONFIG_FILE)) {
  const EXAMPLE = path.join(BASE_DIR, 'config.example.json');
  if (fs.existsSync(EXAMPLE)) { try { fs.copyFileSync(EXAMPLE, CONFIG_FILE); console.log('[setup] สร้าง config.json จาก template ให้แล้ว'); } catch (e) {} }
  if (!fs.existsSync(CONFIG_FILE)) { console.error('❌ ไม่พบ config.json และไม่มี config.example.json — ดาวน์โหลด zip ไปทับโฟลเดอร์เดิมแล้วเปิดใหม่'); process.exit(1); }
}
let config = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
const liveConfig = config; // ค่ารวมที่แก้ได้ระหว่างรัน
if (RELEASE) liveConfig.wsLog = false;
if (!Array.isArray(liveConfig.accounts)) liveConfig.accounts = [{ name: 'ตัวหลัก', enabled: true, farmMap: '', role: 'farm' }];

const LOGS_DIR = path.join(BASE_DIR, 'logs');
if (!fs.existsSync(LOGS_DIR)) fs.mkdirSync(LOGS_DIR, { recursive: true });

const state = { license: { status: RELEASE ? 'checking' : 'dev', code: null } };
const accounts = []; // [{ acct, index }]
let mapsListCache = []; // แคชลิสต์แมพ (อ่านจากเกมครั้งแรกที่ได้ แล้วเก็บไว้)

function getGlobal() { return liveConfig; }

// เปิดหน้าต่างควบคุมแบบ "App Mode" (ไม่มี address bar/tab/bookmark — ดูเป็นโปรแกรม)
function openAppWindow(url) {
  const exe = ['C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', 'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe', 'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe', 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe'].find((p) => fs.existsSync(p));
  if (!exe) { exec(`start "" "${url}"`, () => {}); return; } // ไม่มี Chrome/Edge → เปิด default
  const profile = path.join(BASE_DIR, 'dash-app');
  const { spawn } = require('child_process');
  const child = spawn(exe, ['--app=' + url, '--user-data-dir=' + profile, '--no-first-run', '--no-default-browser-check', '--window-size=1180,840', '--window-position=60,40'], { detached: true, stdio: 'ignore' });
  child.unref();
}

function makeAccount(index) {
  const cfg = liveConfig.accounts[index] || {};
  return new Account(cfg, index, liveConfig.gameUrl, liveConfig.viewport, getGlobal, saveConfig);
}

function killChromeForProfile(userDataDir) {
  return new Promise((resolve) => {
    const { exec } = require('child_process');
    const needle = userDataDir.replace(/\\/g, '\\\\').replace(/[^\x00-\x7F]/g, '.'); // Thai → dot wildcard
    const ps = `Get-CimInstance Win32_Process -Filter "Name='chrome.exe'" | Where-Object { $_.CommandLine -match '${needle.replace(/'/g, "")}' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }`;
    exec(`powershell -NoProfile -Command "${ps.replace(/\n/g, ' ')}"`, () => setTimeout(resolve, 2500));
  });
}

async function launchAccount(index) {
  let entry = accounts.find((a) => a.index === index);
  if (entry && (entry.acct.state.running || entry._launching)) return { ok: true, msg: 'กำลังเปิด/เปิดอยู่แล้ว' };
  if (!entry) { entry = { index, acct: makeAccount(index), _launching: false }; accounts.push(entry); }
  entry._launching = true;
  const safeName = (entry.acct.cfg.name || ('acct' + index)).replace(/[^\w\u0E00-\u0E7F-]/g, '_');
  try {
    await entry.acct.launch();
    return { ok: true, msg: 'เปิดบัญชี ' + (entry.acct.state.name || index) };
  } catch (e) {
    // โปรไฟล์ถูกล็อกโดย Chrome ค้าง → ฆ่าแล้วลองใหม่ 1 ครั้ง
    if (/already running/i.test(e.message)) {
      console.log('[launch] โปรไฟล์ถูกล็อก → เก็บกวาด Chrome ค้างแล้วลองใหม่');
      await killChromeForProfile(path.join(BASE_DIR, 'profiles', safeName));
      try { await entry.acct.launch(); return { ok: true, msg: 'เปิดบัญชี ' + (entry.acct.state.name || index) + ' (หลังล้าง)' }; }
      catch (e2) { try { await entry.acct.stop(); } catch (_) {} accounts.splice(accounts.indexOf(entry), 1); return { ok: false, msg: e2.message }; }
    }
    try { await entry.acct.stop(); } catch (_) {}
    accounts.splice(accounts.indexOf(entry), 1);
    return { ok: false, msg: e.message };
  } finally { entry._launching = false; }
}
async function stopAccount(index) {
  const entry = accounts.find((a) => a.index === +index);
  if (entry) { await entry.acct.stop(); accounts.splice(accounts.indexOf(entry), 1); }
  return { ok: true, msg: 'ปิดบัญชีแล้ว' };
}
function acct(index) { return (accounts.find((a) => a.index === +index) || {}).acct || null; }

// ---------- จัดการบัญชี (เพิ่ม/ลบ/เปิด/ปิด) ----------
function saveConfig() { try { fs.writeFileSync(CONFIG_FILE, JSON.stringify(liveConfig, null, 2)); } catch (e) {} }

async function addAccount(name) {
  liveConfig.accounts.push({ name: name || ('บัญชี ' + (liveConfig.accounts.length + 1)), enabled: true, farmMap: '', role: 'farm' });
  saveConfig();
  await launchAccount(liveConfig.accounts.length - 1);
  return { ok: true, msg: 'เพิ่มบัญชีแล้ว — ล็อกอินในเกมในหน้าต่างใหม่ที่เปิดขึ้น' };
}
async function removeAccount(index) {
  index = +index;
  if (liveConfig.accounts.length <= 1) return { ok: false, msg: 'ต้องมีอย่างน้อย 1 บัญชี' };
  await stopAccount(index);
  liveConfig.accounts.splice(index, 1);
  // reindex accounts[]
  accounts.forEach((a, i) => { a.index = i; a.acct.index = i; a.acct.state.name = liveConfig.accounts[i].name; });
  saveConfig();
  return { ok: true, msg: 'ลบบัญชีแล้ว' };
}

// ---------- 🔄 อัปเดตอัตโนมัติ (ฝั่งเครื่องเพื่อน) ----------
let updateBusy = false;

// "จังหวะปลอดภัย" = ไม่มีใครกำลังเดินทาง/ฟาร์ม/อยู่บนเกาะ และไม่มีวงวน Voyage เปิดอยู่
function updateIsSafe() {
  if (!accounts.length) return true;
  const town = new Set(((liveConfig.autoWatch && liveConfig.autoWatch.townMaps) || GAME.TOWN_MAPS).map(String));
  for (const e of accounts) {
    const s = e.acct.status();
    if (!s.running) continue;
    if (s.traveling || s.farmOn) return false;
    const vf = (s.settings && s.settings.voyFarm) || liveConfig.voyFarm || {};
    if (vf.enabled) return false;
    if (s.connected) {
      const mapId = s.gameStats && s.gameStats.mapId;
      if (mapId == null || !town.has(String(mapId))) return false;
    }
  }
  return true;
}

async function restartForUpdate() {
  console.log('[update] หยุดทุกบัญชีอย่างนุ่มนวล แล้วเปิดใหม่ด้วยเวอร์ชันใหม่...');
  for (const e of [...accounts]) { try { await e.acct.stop(); } catch (err) {} }
  updater.requestRestart();
  setTimeout(() => process.exit(0), 1500);
}

// เช็ก + (ถ้ามีของใหม่และปลอดภัย) ติดตั้ง — return คำอธิบายสั้น ๆ ให้ UI
async function runUpdate(forceApply) {
  if (updateBusy) return { ok: false, msg: 'กำลังมีงานอัปเดตค้างอยู่' };
  updateBusy = true;
  try {
    await updater.check(true);
    let s = updater.publicState();
    if (!s.available) return { ok: true, msg: s.msg, state: s };
    if (!forceApply && !updateIsSafe()) {
      s = updater.setPhase('waiting-safe', 'มี v' + s.latest + ' — รอตัวละครกลับเข้าเมืองก่อนจะอัปเดตเอง');
      return { ok: true, msg: s.msg, state: s, waiting: true };
    }
    const r = await updater.apply();
    if (r.ok) setTimeout(() => { restartForUpdate(); }, 2500); // ให้ UI อ่านสถานะก่อน
    return { ok: r.ok, msg: r.msg, state: updater.publicState() };
  } finally { updateBusy = false; }
}

function startUpdateLoop() {
  if (!updater.publicState().enabled) { console.log('[update] เครื่องนี้เป็นเครื่อง dev — ไม่ดึงอัปเดตเอง'); return; }
  setInterval(async () => {
    if (updateBusy) return;
    const s = updater.publicState();
    if (!s.available || s.giveUp) return;
    if (updateIsSafe()) { await runUpdate(false); }
    else updater.setPhase('waiting-safe', 'มี v' + s.latest + ' — รอกลับเข้าเมือง (ตอนนี้ยังไม่ปลอดภัย)');
  }, 60 * 1000);
  setInterval(() => { if (!updateBusy) updater.check(false).catch(() => {}); }, 30 * 60000);
}

// ---------- 📦 ปล่อยเวอร์ชันใหม่ (มีเฉพาะเครื่อง dev) ----------
const pubState = { running: false, steps: [], result: null, at: 0 };
async function runPublish(body) {
  if (pubState.running) return { ok: false, msg: 'มีงานปล่อยค้างอยู่' };
  pubState.running = true; pubState.steps = ['สร้างแพ็กเกจเวอร์ชันเพื่อน...']; pubState.result = null; pubState.at = Date.now();
  try {
    if (body.token) publisher.saveToken(body.token);
    const out = await publisher.publish({ version: body.version, notes: body.notes, lockLicense: !!body.lockLicense });
    pubState.result = out;
    return out;
  } catch (e) {
    pubState.result = { ok: false, msg: e.message };
    return pubState.result;
  } finally { pubState.running = false; pubState.at = Date.now(); }
}

// ---------- API ----------
function json(res, code, obj) { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(obj)); }
async function readBody(req) { const c = []; for await (const x of req) c.push(x); return Buffer.concat(c).toString('utf8'); }

function statusPayload() {
  return {
    release: RELEASE, app: APP_NAME, version: buildinfo.version, devMachine: DEV_MACHINE, devOnly: RELEASE ? Array.from(DEV_ONLY) : [],
    update: updater.publicState(),
    publish: DEV_MACHINE ? { token: publisher.tokenInfo(), repo: buildinfo.updateRepo, branch: buildinfo.updateBranch, folder: buildinfo.updatePath, busy: pubState.running, result: pubState.result } : null,
    license: { status: state.license.status, code: state.license.code },
    accounts: liveConfig.accounts.map((a, i) => { const ac = acct(i); return ac ? ac.status() : { index: i, name: a.name, enabled: a.enabled, running: false, connected: false, farmOn: false, gameStats: null, ws: { in: 0, out: 0 }, lastFarmMap: null, uptimeSec: 0 }; }),
    global: {
      humanDelay: liveConfig.humanDelay || { enabled: true, minSec: 2, maxSec: 5 },
      autoPotion: liveConfig.autoPotion || {}, autoWatch: liveConfig.autoWatch || {},
      sellConfig: liveConfig.sellConfig || {}, autoTown: liveConfig.autoTown || {},
      enterCharacter: liveConfig.enterCharacter || {}, autoFarm: liveConfig.autoFarm || {},
      buyPotion: liveConfig.buyPotion || {},
      wsLogEnabled: liveConfig.wsLog !== false,
    },
  };
}

let server = null;
function startServer() {
  const DASHBOARD = fs.readFileSync(path.join(BASE_DIR, 'dashboard.html'));
  server = http.createServer(async (req, res) => {
    const url = new URL(req.url, `http://localhost:${PORT}`);
    const r = url.pathname; const q = url.searchParams; const id = q.get('id') || 0;
    try {
      if (req.method === 'GET' && (r === '/' || r === '/index.html')) { res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); res.end(DASHBOARD); }
      else if (req.method === 'GET' && r === '/logo.png') { try { res.writeHead(200, { 'Content-Type': 'image/png', 'Cache-Control': 'public,max-age=3600' }); res.end(fs.readFileSync(path.join(BASE_DIR, 'assets', 'icon256.png'))); } catch (e) { res.writeHead(404); res.end(); } }
      else if (req.method === 'GET' && r === '/manifest.webmanifest') { try { res.writeHead(200, { 'Content-Type': 'application/manifest+json' }); res.end(fs.readFileSync(path.join(BASE_DIR, 'manifest.webmanifest'))); } catch (e) { res.writeHead(404); res.end(); } }
      else if (req.method === 'GET' && (r === '/icons/192.png' || r === '/icons/512.png')) { const sz = r.split('/')[2].replace('.png', ''); try { res.writeHead(200, { 'Content-Type': 'image/png', 'Cache-Control': 'public,max-age=3600' }); res.end(fs.readFileSync(path.join(BASE_DIR, 'assets', 'sizes', 'i' + sz + '.png'))); } catch (e) { res.writeHead(404); res.end(); } }
      else if (req.method === 'GET' && r === '/api/status') json(res, 200, statusPayload());
      else if (req.method === 'GET' && r === '/api/screenshot') { const a = acct(id); const buf = a && await a.screenshot(); if (!buf) { json(res, 503, { error: 'ไม่ได้/ปิดอยู่' }); return; } res.writeHead(200, { 'Content-Type': 'image/png', 'Cache-Control': 'no-store' }); res.end(buf); }
      else if (req.method === 'GET' && r === '/api/warp') { const a = acct(id); if (!a) { json(res, 503, { error: 'บัญชีไม่ได้เปิดอยู่' }); return; } json(res, 200, await a.page.evaluate(GAME.page.warpPanel).catch(() => null) || { error: 'ไม่พร้อม' }); }
      else if (req.method === 'GET' && r === '/api/voyage') { const a = acct(id); if (!a) { json(res, 503, { error: 'บัญชีไม่ได้เปิดอยู่' }); return; } json(res, 200, await a.page.evaluate(GAME.page.voyagePanel).catch((e) => ({ error: e.message })) || { error: 'ไม่พร้อม' }); }
      else if (req.method === 'POST' && r === '/api/voyage') { const b = JSON.parse((await readBody(req)) || '{}'); const a = acct(b.id || 0); if (!a) { json(res, 200, { ok: false, msg: 'ไม่ได้เปิดอยู่' }); return; } const out = await a.page.evaluate(GAME.page.voyAction, b.act || {}).catch((e) => ({ ok: false, msg: e.message })); if (out && out.ok) a.log('🚢 ' + out.msg); json(res, 200, out); }
      else if (req.method === 'GET' && r === '/api/items') { const a = acct(id); if (!a) { json(res, 200, { matches: [], suggest: [], error: 'บัญชีนี้ยังไม่ได้เปิด (กด เปิด ก่อน)' }); return; } json(res, 200, await a.page.evaluate(GAME.page.findItems, q.get('q') || '').catch((e) => ({ matches: [], suggest: [], error: e.message }))); }
      else if (req.method === 'GET' && r === '/api/filters') { const a = acct(id); if (!a) { json(res, 200, { filters: [], error: 'บัญชีนี้ยังไม่ได้เปิด (กด เปิด ก่อน)' }); return; } json(res, 200, await a.page.evaluate(GAME.page.listGameFilters).catch((e) => ({ filters: [], error: e.message }))); }
      else if (req.method === 'GET' && r === '/api/maps') {
        const a = acct(id) || acct(0);
        let list = [];
        if (a && a.page) { try { list = await a.page.evaluate(GAME.page.listMaps, (liveConfig.autoWatch && liveConfig.autoWatch.townMaps) || GAME.TOWN_MAPS) || []; } catch (e) {} }
        if (list.length) mapsListCache = list; // แคชไว้ (เกมไม่เปลี่ยนชื่อแมพบ่อย)
        json(res, 200, mapsListCache); // คืนแคชเสมอ → dashboard ได้ลิสต์เร็วแม้ยังโหลดไม่เสร็จ
      }
      else if (req.method === 'GET' && r === '/api/sell/preview') { const a = acct(id); json(res, 200, a ? await a.sellPreview() : { error: 'บัญชีไม่ได้เปิดอยู่' }); }
      else if (req.method === 'POST' && r === '/api/sell/run') { const b = JSON.parse((await readBody(req)) || '{}'); const a = acct(b.id || 0); json(res, 200, a ? await a.sellRun(b.what || 'all') : { ok: false, msg: 'ไม่ได้เปิดอยู่' }); }
      else if (req.method === 'POST' && r === '/api/command') {
        const b = JSON.parse((await readBody(req)) || '{}');
        if (b.action === 'acct-add') return json(res, 200, await addAccount(b.name));
        if (b.action === 'acct-remove') return json(res, 200, await removeAccount(b.id));
        if (b.action === 'acct-launch') return json(res, 200, await launchAccount(+b.id));
        if (b.action === 'acct-stop') return json(res, 200, await stopAccount(+b.id));
        if (b.action === 'acct-headless') { const i = +b.id; if (liveConfig.accounts[i]) { liveConfig.accounts[i].headless = !!b.value; saveConfig(); await stopAccount(i); await launchAccount(i); } return json(res, 200, { ok: true, msg: b.value ? 'เปิดโหมดซ่อนหน้าต่าง (รีสตาร์ทบัญชีนี้)' : 'เปิดหน้าต่างปกติ (รีสตาร์ทบัญชีนี้)' }); }
        if (b.action === 'acct-rename') { const i = +b.id; if (liveConfig.accounts[i]) { liveConfig.accounts[i].name = b.name; const a = acct(i); if (a) { a.cfg.name = b.name; a.state.name = b.name; } saveConfig(); } return json(res, 200, { ok: true, msg: 'เปลี่ยนชื่อแล้ว' }); }
        const a = acct(b.id || 0); json(res, 200, a ? await a.command(b.action, b) : { ok: false, msg: 'บัญชีนี้ยังไม่ได้เปิด (กด เปิด ก่อน)' });
      }
      else if (req.method === 'GET' && r === '/api/config') json(res, 200, liveConfig);
      else if (req.method === 'POST' && r === '/api/config') {
        const b = JSON.parse(await readBody(req));
        const SET_KEYS = ['humanDelay', 'autoPotion', 'autoWatch', 'sellConfig', 'autoTown', 'enterCharacter', 'autoFarm', 'buyPotion', 'autoLogin', 'voyFarm', 'lootFilter'];
        // มี id → เขียน settings ของบัญชีนั้น (ต่อบัญชี) | ไม่มี → เขียนค่า default รวม
        if (b.id != null && liveConfig.accounts[+b.id]) {
          const acc = liveConfig.accounts[+b.id];
          acc.settings = acc.settings || {};
          for (const k of SET_KEYS) if (b[k] !== undefined) acc.settings[k] = b[k];
          const a = acct(+b.id); if (a) a.cfg = acc;
        } else {
          for (const k of SET_KEYS) if (b[k] !== undefined) liveConfig[k] = b[k];
          if (b.wsLog !== undefined) liveConfig.wsLog = b.wsLog;
        }
        if (RELEASE) liveConfig.wsLog = false;
        // อัปเดตชื่อ/สถานะบัญชีที่แก้
        if (Array.isArray(b.accounts)) { b.accounts.forEach((na, i) => { if (liveConfig.accounts[i]) { Object.assign(liveConfig.accounts[i], na); const a = acct(i); if (a) { a.state.name = liveConfig.accounts[i].name; a.cfg = liveConfig.accounts[i]; } } }); }
        saveConfig();
        json(res, 200, { ok: true, msg: 'บันทึกแล้ว (มีผลทันที)' });
      }
      else if (req.method === 'GET' && r === '/api/update') json(res, 200, Object.assign({ safe: updateIsSafe(), busy: updateBusy }, updater.publicState()));
      else if (req.method === 'POST' && r === '/api/update') {
        const b = JSON.parse((await readBody(req)) || '{}');
        if (b.action === 'apply') json(res, 200, await runUpdate(true));
        else json(res, 200, await runUpdate(false));
      }
      else if (r === '/api/publish') {
        if (!DEV_MACHINE) json(res, 403, { ok: false, msg: 'เมนูนี้มีเฉพาะเครื่องคนพัฒนา' });
        else if (req.method === 'GET') json(res, 200, { version: buildinfo.version, token: publisher.tokenInfo(), repo: buildinfo.updateRepo, branch: buildinfo.updateBranch, folder: buildinfo.updatePath, busy: pubState.running, result: pubState.result, steps: pubState.steps });
        else if (req.method === 'POST') {
          const b = JSON.parse((await readBody(req)) || '{}');
          if (b.action === 'token') { const ok = publisher.saveToken(b.token || ''); return json(res, 200, { ok, msg: ok ? 'บันทึก token แล้ว' : 'เขียน token ไม่สำเร็จ' }); }
          runPublish(b).then((out) => console.log('[publish] ' + (out.ok ? '✅ ' : '❌ ') + out.msg)).catch((e) => console.log('[publish] ❌ ' + e.message));
          json(res, 200, { ok: true, msg: 'เริ่มปล่อยเวอร์ชัน ' + (b.version || '?') + ' แล้ว — รอสักครู่', started: true });
        } else json(res, 405, { ok: false, msg: 'method ไม่รองรับ' });
      }
      else { res.writeHead(404); res.end('404'); }
    } catch (e) { json(res, 500, { ok: false, msg: e.message }); }
  });
  server.listen(PORT, () => { console.log(`[${APP_NAME}] หน้าควบคุม: http://localhost:${PORT}`); if (!process.env.NB_NO_OPEN) openAppWindow(`http://localhost:${PORT}`); });
}

// ---------- หน้า Activate (เวอร์ชันเพื่อน) ----------
let activationSrv = null;
function startActivationServer(onOk) {
  const ACT = fs.readFileSync(path.join(BASE_DIR, 'activation.html'));
  activationSrv = http.createServer(async (req, res) => {
    const u = new URL(req.url, `http://localhost:${PORT}`);
    if (u.pathname === '/' || u.pathname === '/index.html') { res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); res.end(ACT); }
    else if (u.pathname === '/api/license/check') { const rr = await license.verify(); state.license = rr; json(res, 200, { status: rr.status, code: rr.code, user: rr.user, expires: rr.expires }); if (rr.status === 'ok' && activationSrv) { const s = activationSrv; activationSrv = null; setTimeout(() => { try { s.close(); } catch (e) {} onOk && onOk(); }, 800); } }
    else { res.writeHead(404); res.end('404'); }
  });
  activationSrv.listen(PORT, () => { console.log('[license] ยังไม่อนุมัติ — เปิดหน้า Activate ที่ http://localhost:' + PORT); if (!process.env.NB_NO_OPEN) openAppWindow(`http://localhost:${PORT}`); });
}
function startLicenseWatch() { if (!RELEASE) return; setInterval(async () => { const rr = await license.verify(); state.license = rr; if (rr.status !== 'ok') { console.log('[license] ถูกระงับ → หยุดทุกบัญชี'); for (const e of accounts) await e.acct.stop().catch(() => {}); if (!activationSrv) startActivationServer(() => startAll().catch(() => {})); } }, 30 * 60000); }

async function startAll() {
  for (let i = 0; i < liveConfig.accounts.length; i++) { if (liveConfig.accounts[i].enabled) await launchAccount(i); }
}

async function main() {
  try { if (fs.existsSync(updater.RESTART_FLAG)) fs.unlinkSync(updater.RESTART_FLAG); } catch (e) {}
  console.log('=============================================');
  console.log(`   ${APP_NAME} v${buildinfo.version} — ${RELEASE ? 'MODE FRIEND' : 'DEV'} — ${liveConfig.accounts.length} บัญชี`);
  console.log('=============================================');
  if (RELEASE) {
    state.license = await license.verify();
    console.log(`[license] ${state.license.status} (เครื่องนี้: ${state.license.code})`);
    if (state.license.status !== 'ok') { startActivationServer(() => { startAll().then(startLicenseWatch).catch((e) => console.error(e)); }); return; }
  }
  // 🔄 เช็กอัปเดตก่อนเปิดบัญชีไหนเลย — ถ้ามีของใหม่ ติดตั้งทันที (ยังไม่มีอะไรรัน = ปลอดภัย 100%)
  try {
    await updater.check(true);
    const s = updater.publicState();
    if (s.available) {
      console.log('[update] ' + s.msg);
      const r = await updater.apply();
      if (r.ok) {
        console.log('[update] ' + r.msg);
        if (updater.requestRestart()) { console.log('[update] ปิดตัวเองเพื่อเปิดใหม่อัตโนมัติ...'); process.exit(0); }
        console.log('[update] ⚠️ เปิดใหม่เองไม่ได้นะ — ปิดหน้าต่างนี้แล้วดับเบิลคลิก start.bat ใหม่');
      } else console.log('[update] ' + r.msg);
    } else if (s.enabled) console.log('[update] ' + s.msg);
  } catch (e) { console.log('[update] เช็กไม่สำเร็จ: ' + e.message); }
  startServer();
  await startAll();
  startLicenseWatch();
  startUpdateLoop();
}
main().catch((e) => { console.error('[fatal]', e); process.exit(1); });

// ---------- ปิดอย่างสวยงาม: ปิด Chrome ทุกบัญชีเมื่อ server ออก (กันหน้าต่างค้าง/about:blank กำพร้า) ----------
async function shutdownAll() {
  console.log('\n[ปิดโปรแกรม] กำลังปิดเบราว์เซอร์ทุกบัญชี...');
  for (const entry of [...accounts]) { try { await entry.acct.stop(); } catch (e) {} }
  process.exit(0);
}
process.on('SIGINT', shutdownAll);
process.on('SIGTERM', shutdownAll);
