// ============================================================
//  game-adapter.js — "สมองที่รู้เรื่องเกม Caelmora" (CaelmoraBot)
// ------------------------------------------------------------
//  เกม: Caelmora (Crimson Vow) — MMORPG isometric ไทย
//       https://caelmora.com/
//
//  ★ กลยุทธ์พิเศษ — เกมนี้ "ปิด" global debug hooks ด้วย flag V:
//      const V = /^(localhost|127\.0\.0\.1|...)$/.test(location.hostname)
//                && location.search.includes('debug');
//      if (V) { window.S = H; window.__net = ae; window.__settings = SETTINGS; ... }
//
//  เราจึง "patch" js/main.js ตอนโหลด (ผ่าน preLaunch + request interception)
//  ให้ V=true เสมอ → window.S (=H, state ทั้งหมด) + window.__net (send actions)
//  + window.__settings + window.__bot + window.__botWants ฯลฯ ปรากฏใน console
//  → adapter ทั้งหมดอ่าน/เขียนผ่าน window.S/window.__net ได้ตรง ๆ
//
//  Object ที่ patch มาให้:
//    window.S          = H       = state container (hero/info/stats/ents/items/…)
//    window.__net      = ae      = { sell, travel, wpGo, buy, flask, attack, cast, … }
//    window.__settings = SETTINGS= autoPotion, autoSkill, autoRes, loot, filters, …
//    window.__bot      = cg      = handle ของ in-game bot (ถ้ามี)
//    window.__botWants = fn(ent, cfg) → decision
//    window.__botWhy   = last reason
//    window.__botTurn  = () => [turn, turnLeft]
//    window.__walk     = fn(path)
//    window.__roll     = fn(dir)
//    window.__pick     = fn(ent)
// ============================================================
'use strict';
const https = require('https');
const zlib = require('zlib');

// ---------- ค่าคงที่เฉพาะเกม ----------
// จาก probe สด: mapEn[0]='Caelmora' (เมืองหลวง), mapEn[2]='Solhaven' (เมืองเกิด) — มี 57 แมพทั้งหมด
// "เมืองปลอดภัย" = 0, 2 (ห้ามกด AUTO/กินยา/เดินทางอัตโนมัติในนี้)
const TOWN_MAPS = ['0', '2'];
const HOME_TOWN = { id: '0', name: 'Caelmora' };
// flask = ยา/มานา; เกมนี้ slot 1-8 ผูกกับ skill/flask — ค่า default ใช้ปุ่ม "1" (hp flask)
const POTION = { hp: { on: true, size: 'flask_hp_m', min: 5, buy: 20 }, sp: { on: false, size: 'flask_mp_m', min: 5, buy: 20 } };

// ============================================================
//  preLaunch — เปิด request interception + patch js/main.js
//  แกนกลาง (accounts.js) จะเรียก fn นี้ก่อน page.goto()
// ============================================================
function fetchText(url) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.9,th-TH,th;q=0.8',
        'Accept-Encoding': 'gzip, identity',
        'Referer': 'https://caelmora.com/',
        'sec-ch-ua': '"Chromium";v="120"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'Sec-Fetch-Dest': 'script', 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'same-origin',
      },
    }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return fetchText(new URL(res.headers.location, url).href).then(resolve, reject);
      }
      if (res.statusCode !== 200) {
        res.resume(); return reject(new Error('HTTP ' + res.statusCode + ' for ' + url));
      }
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => {
        let body = Buffer.concat(chunks);
        const enc = (res.headers['content-encoding'] || '').toLowerCase();
        try { if (enc === 'gzip') body = zlib.gunzipSync(body); else if (enc === 'br') body = zlib.brotliDecompressSync(body); } catch (e) {}
        resolve(body.toString('utf8'));
      });
      res.on('error', reject);
    });
    req.on('error', reject);
    req.setTimeout(20000, () => { try { req.destroy(new Error('timeout')); } catch (e) {} });
  });
}

// regex หาบรรทัด "ประกาศตัวแปร gate" ของโหมด debug — เกมเปลี่ยนชื่อตัวแปรทุกบิลด์
//   (บิลด์เก่าชื่อ V, บิลด์ 28/10 นี้ชื่อ M) → จับ "ตามโครง" แล้ว capture ชื่อกลับมาใช้ตอนแทนที่
//   โครงจริง: const <id>=/^(localhost|127\.0\.0\.1|...)$/.test(location.hostname)&&location.search.includes('debug')
const V_DECL_RE = /(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*\/\^[^\/]+\/\.test\(location\.hostname\)\s*&&\s*location\.search\.includes\(\s*(['"])debug\2\s*\)/;

async function preLaunch(page, acct) {
  const log = (m) => { try { acct && acct.log && acct.log(m); } catch (e) {} };
  await page.setRequestInterception(true);
  const cache = new Map();          // url → patched text (กัน fetch ซ้ำ)
  let patchedLogged = false, gateName = null;
  page.on('request', async (req) => {
    let url = '';
    try { url = req.url(); } catch (e) { return; }
    if (!/caelmora\.com\/js\/main\.js(\?|$)/.test(url)) {
      try { await req.continue(); } catch (e) {}
      return;
    }
    try {
      let text = cache.get(url);
      if (text == null) {
        const orig = await fetchText(url);
        const patched = orig.replace(V_DECL_RE, (s, id) => { gateName = id; return 'const ' + id + '=!0'; });
        if (patched === orig) {
          log('🚫 patch main.js ไม่สำเร็จ — ไม่เจอบรรทัด gate "debug" ในตัวเกมใหม่ → window.S จะไม่โผล่ บอทจะมองเกมไม่เห็น (Lv?/HP -/-) แจ้งคนพัฒนาให้ปรับ V_DECL_RE');
        }
        cache.set(url, patched);
        text = patched;
      }
      await req.respond({
        status: 200,
        contentType: 'application/javascript; charset=utf-8',
        body: text,
        headers: { 'access-control-allow-origin': '*', 'cache-control': 'no-store' },
      });
      if (!patchedLogged && gateName) { log('🔧 patch main.js → ' + gateName + '=true (เปิด window.S / __net / __settings)'); patchedLogged = true; }
    } catch (e) {
      log('⚠️ patch main.js fail: ' + (e.message || e) + ' — ให้โหลดตัวจริงแทน');
      try { await req.continue(); } catch (_) {}
    }
  });
}

// ---------- (node) ถอดแพ็กเก็ต ----------
// Caelmora ใช้ MuSocket binary สำหรับ state + CmLink JSON สำหรับ actions
// เพราะเราอ่านค่าผ่าน window.S (V-patch) → ไม่จำเป็นต้อง parse ws frames
// คืน null เสมอ (แกนกลางยอมรับ — state หลักมาจาก page.readStats)
function decodeWorldFrame(_b64) { return null; }

// ============================================================
//  ฟังก์ชันที่รัน "ในหน้าเกม" — ต้องเขียนแบบ `name: function(){}`
//  อ้างได้แค่ window.* (S, __net, __settings, __bot, document, …)
// ============================================================
const page = {
  // ---------- อ่านค่าสำหรับ dashboard + auto-potion ----------
  readStats: function () {
    var S = (typeof window !== 'undefined') && window.S; if (!S) return null;
    var hero = S.hero, info = S.info, stats = S.stats || {}, sel = S.selChar, me = S.me;
    if (!hero && !sel && !info) return null;
    var name = (hero && hero.name) || (sel && sel.name) || null;
    var lv = (me && me.level) || stats.level || (hero && hero.lvl) || (sel && sel.level) || null;
    var hp = (info && info.life != null) ? Math.round(info.life) : (me && me.hp != null ? Math.round(me.hp) : null);
    var maxHp = (info && info.maxLife != null) ? Math.round(info.maxLife) : ((me && me.mhp) || stats.maxLife || null);
    var sp = (info && info.mana != null) ? Math.round(info.mana) : (me && me.mp != null ? Math.round(me.mp) : null);
    var maxSp = (info && info.maxMana != null) ? Math.round(info.maxMana) : ((me && me.mmp) || stats.maxMana || null);
    var expPct = null;
    try {
      if (me && me.exp != null && me.next > 0) { var base = me.prev || 0; expPct = (me.exp - base) / (me.next - base); }
      else if (stats.exp != null && stats.nextExp > 0) expPct = stats.exp / stats.nextExp;
      if (expPct != null) expPct = Math.max(0, Math.min(1, expPct));
    } catch (e) {}
    var gold = null;
    try { gold = (me && me.zen != null) ? me.zen : (S.panels && S.panels.zen != null ? S.panels.zen : null); } catch (e) {}
    // ชื่อบท: คลาสขั้นสูง (asc) ก่อน → fallback คลาสพื้นฐาน
    var job = null;
    try {
      if (me && me.asc && me.asc.id && S.asc && S.asc[me.asc.id]) {
        var an = S.asc[me.asc.id].name; job = (an && (an[1] || an[0])) || me.asc.id;
      }
      if (!job) {
        var cls = (me && me.cls != null) ? me.cls : (sel && sel.cls);
        if (cls != null) {
          var names = { 0: 'Arcanist', 1: 'Lancer', 2: 'Ranger', 3: 'Spellblade', 4: 'Warlord', 5: 'Soulbinder', 6: 'Ironfist' };
          var thNames = { 0: 'จอมเวทอาคม', 1: 'นักรบหอก', 2: 'พรานธนู', 3: 'นักดาบเวท', 4: 'จอมทัพ', 5: 'ผู้ผูกวิญญาณ', 6: 'นักสู้หมัดเหล็ก' };
          var idx = (cls >> 5);
          if (names[idx] == null && names[cls] != null) idx = cls;
          job = thNames[idx] || names[idx] || null;
        }
      }
    } catch (e) {}
    // แมพปัจจุบัน: S.info.map (ตัวเลข) + ชื่อจาก mapTh (ไทย, โหลดแบบ lazy) หรือ mapEn
    var mapId = (info && info.map != null) ? String(info.map) : null;
    var zone = null;
    try { if (mapId != null) zone = (S.mapTh && S.mapTh[mapId]) || (S.mapEn && S.mapEn[mapId]) || null; } catch (e) {}
    var dead = !!S.dead || !!(hero && hero.dead > 0);
    // re-anchor home ของบอทเกมทุก ~1 วิ (เฉพาะตอนมีทริปเกาะ) — ให้ AUTO เล็งมอนรอบตัวทันที
    try { if (S.bot && S.voyUi && S.voyUi.run && hero) S.bot.home = [Math.round(hero.rx), Math.round(hero.ry)]; } catch (e) {}
    // นับ flask (ยา HP/MP) ในกระเป๋า — S.panels.inv (Map<slot,item>) + S.items (DB)
    var potions = 0, spPotions = 0;
    try {
      var inv = S.panels && S.panels.inv;
      if (inv && typeof inv.values === 'function') {
        var itIt = inv.values(); var r;
        while (!(r = itIt.next()).done) {
          var it0 = r.value; if (!it0 || it0.id == null) continue;
          var def = (S.items && S.items[it0.id]) || null; if (!def) continue;
          var cat = (def.cat || '').toLowerCase();
          var label = (def.th || '') + ' ' + (def.name || '') + ' ' + (def.k || '');
          var isFlask = cat === 'flask' || /flask|ยา|potion/i.test(label);
          if (isFlask) {
            var isMp = /mp|mana|มานา|มาน/i.test(label);
            if (isMp) spPotions += (it0.n || 1); else potions += (it0.n || 1);
          }
        }
      }
    } catch (e) {}
    return { name: name, job: job, lv: lv, hp: hp, maxHp: maxHp, sp: sp, maxSp: maxSp, gold: gold, potions: potions, spPotions: spPotions, mapId: mapId, zone: zone, dead: dead, expPct: expPct };
  },

  // ---------- ผู้เฝ้า AUTO (in-game bot) ----------
  probeAuto: function () {
    var S = window.S; if (!S || !S.hero) return null;
    var bot = S.bot, auto = !!S.auto;
    var hero = S.hero;
    var online = !!(S.gs || S.link);
    var hopping = !!(window.__vhgRoam && window.__vhgRoam.hopping); // roam กำลังเดินข้ามโซน = ตั้งใจปิดบอท
    var rushWalk = !!(window.__vhgRoamOpts && window.__vhgRoamOpts.mode === 'boss' && window.__vhgRoam && window.__vhgRoam.key && !window.__vhgRoam.bossEngaged && S.voyUi && S.voyUi.run);
    return {
      on: hopping || rushWalk || !!(bot && (bot.on || bot.running || bot.active)) || auto,
      hasPlayer: !!hero,
      dead: !!S.dead || hero.dead > 0,
      online: online,
      mapId: (S.info && S.info.map != null) ? String(S.info.map) : null,
      traveling: !!(hero.path && hero.path.length),
    };
  },
  enableAuto: function (townsArg) {
    var S = window.S; if (!S) return;
    // 🚫 กฎเหล็ก (ผู้ใช้สั่ง): "ห้ามเปิด AUTO ในเมืองเป็นอันขาด" — เช็คที่จุดนี้จุดเดียวเพราะทุกเส้นทางผ่านมาที่นี่
    //   และถ้าเจอว่าเปิดค้างอยู่ (เช่นวาร์ปกลับมาจากฟิลด์) ให้ปิดให้เลย ไม่ใช่แค่ "ไม่เปิด"
    var tset = {}; (townsArg && townsArg.length ? townsArg : ['0', '2']).forEach(function (t) { tset[String(t)] = 1; });
    var curMap = (S.info && S.info.map != null) ? String(S.info.map) : '';
    if (tset[curMap]) {
      var wasOn = !!(S.bot && (S.bot.on || S.bot.running)) || !!S.auto;
      try { if (typeof window.__bot === 'function') window.__bot(false); } catch (e) {}
      try { var bt = S.bot; if (bt) { if (typeof bt.stop === 'function' && (bt.on || bt.running)) bt.stop(); else if (typeof bt.toggle === 'function' && (bt.on || bt.running)) bt.toggle(); } } catch (e) {}
      try { if (S.auto) S.auto = false; } catch (e) {}
      try { S.targetKey = -1; } catch (e) {}
      return { ok: false, inTown: true, wasOn: wasOn, msg: 'อยู่ในเมือง — ห้ามเปิด AUTO' + (wasOn ? ' (พบว่ามีเปิดค้างอยู่ → ปิดให้แล้ว)' : '') };
    }
    if (window.__vhgRoam && window.__vhgRoam.hopping) return; // roam กำลังเดินข้ามโซน — ปล่อยปิดไว้
    if (window.__vhgRoamOpts && window.__vhgRoamOpts.mode === 'boss' && window.__vhgRoam && !window.__vhgRoam.bossEngaged && S.voyUi && S.voyUi.run) return; // พุ่งบอส: ปิดจนกว่าจะเจอบอส
    // 1) ถ้า S.bot มี start() → ใช้เลย
    try { if (S.bot && typeof S.bot.start === 'function' && !S.bot.on) { S.bot.start(); return; } } catch (e) {}
    // 2) ถ้า S.bot มี toggle()
    try { if (S.bot && typeof S.bot.toggle === 'function' && !S.bot.on) { S.bot.toggle(); return; } } catch (e) {}
    // 3) เปิด flag auto ของเกม (ถ้ามี)
    try { if (typeof S.auto === 'boolean' && !S.auto) S.auto = true; } catch (e) {}
    // 4) เปิดผ่าน window.__bot (cg handle) ถ้า callable
    try { if (typeof window.__bot === 'function') { window.__bot(true); return; } } catch (e) {}
    try { if (window.__bot && typeof window.__bot.start === 'function' && !(window.__bot.on)) window.__bot.start(); } catch (e) {}
    // 5) fallback — กดปุ่ม Bot บน toolbar (DOM text มีคำว่า bot/auto)
    try {
      var btns = [].slice.call(document.querySelectorAll('button, .btn, [role="button"]'));
      var b = btns.filter(function (el) { return /bot|auto/i.test((el.textContent || '') + ' ' + (el.title || '') + ' ' + (el.id || '')); })[0];
      if (b && !b.classList.contains('active')) b.click();
    } catch (e) {}
  },

  // ---------- อ่าน status กระเป๋า/เมือง (กลับเมืองเมื่อเต็ม) ----------
  readState: function (towns) {
    var S = window.S; if (!S || !S.hero) return null;
    var p = S.hero;
    var used = 0, cap = 60;
    try {
      var inv = S.panels && S.panels.inv;
      if (inv && typeof inv.size === 'number') used = inv.size;
      else if (inv && typeof inv.values === 'function') { var it = inv.values(); var r; used = 0; while (!(r = it.next()).done) { if (r.value) used++; } }
      var bc = S.bagCfg;
      if (bc && bc.cols && bc.rows) cap = bc.cols * bc.rows * (bc.pages || 1);
    } catch (e) {}
    var mapIdStr = (S.info && S.info.map != null) ? String(S.info.map) : null;
    var inTown = towns && mapIdStr && (towns.indexOf(mapIdStr) >= 0 || towns.indexOf(S.info.map) >= 0);
    var nearShop = !!(S.shop && S.shop.isOpen) || !!(S.storeOpen);
    var mapName = null;
    try { mapName = (S.mapTh && S.mapTh[mapIdStr]) || (S.mapEn && S.mapEn[mapIdStr]) || mapIdStr; } catch (e) { mapName = mapIdStr; }
    return {
      mapId: mapIdStr,
      used: used, cap: cap, pct: cap ? (used / cap * 100) : 0,
      dead: !!S.dead || p.dead > 0,
      traveling: !!(p.path && p.path.length),
      inTown: !!inTown,
      nearShop: !!nearShop,
      mapName: S.mapTh || S.mapEn || mapIdStr,
    };
  },

  // ---------- stub: ระบบขาย/ซื้อยา (phase 2) ----------
  analyzeSell: function (_cfg) {
    var S = window.S;
    if (!S || !S.hero) return { error: 'ยังไม่ได้เข้าเกม' };
    if (!(S.storeOpen || (S.shop && S.shop.isOpen))) return { nearShop: false, mats: [], gear: [], bagUsed: 0, bagCap: 0 };
    return { nearShop: true, mats: [], gear: [], bagUsed: 0, bagCap: 40, _note: 'ระบบขายของ Caelmora ยังไม่ทำ (phase 2)' };
  },
  sellExecute: async function () { return { ok: false, msg: 'ระบบขายของ Caelmora ยังไม่เปิดใช้ (phase 2)' }; },
  buyPotions: function () { return { ok: false, msg: 'ระบบซื้อยายังไม่เปิดใช้ (phase 2)' }; },

  // ---------- 🏪 ร้านขายของ: ต้องเดินไปหา + "คุย" ให้หน้าร้านเปิดก่อน ----------
  //   วัดจริง 17:48 (ผู้ใช้ขายเอง): NPC = id 30000 ชื่อ "Tessa the Alchemist" (ภาษาอังกฤษอย่างเดียว!)
  //     · เดิม regex หา "เทสซ่า|นักเล่นแร่" → ไม่เคยตรง = เหตุผลที่บอทบอก "ไม่พบร้านค้าในแมพนี้" ตลอด
  //     · เกม stream entity เฉพาะระยะใกล้ → ตอนฮีโร่อยู่โต๊ะนำร่อง (139,126) เธอยืน (117,121) ห่าง 22 ช่อง = ไม่อยู่ใน S.ents
  //       → ต้องจำพิกัดที่เคยเห็นแล้ว "เดินไปหาก่อน" แล้วค่อย scan ซ้ำ
  //     · talk {id:30000,m:1,s:1} → เซิร์ฟตอบ {t:'shop',...} และ S.shopWin.isOpen=true → เท่านั้นที่ {t:'sell',s:ช่อง} ถึงได้ผล
  approachShop: async function (opts) {
    var S = window.S, net = window.__net;
    if (!S || !S.hero) return { ok: false, msg: 'ยังไม่ได้เข้าเกม' };
    var re = (opts && opts.re) ? new RegExp(opts.re, 'i') : /tessa|alchemist|เทสซ่า|นักเล่นแร่/i;
    var h = S.hero, map = String((S.info && S.info.map) || '');
    var sl = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
    var rnd = function (a, b) { return a + Math.random() * (b - a); };
    var raw = function (o) { try { net.talk(o.id, o.m, o.s); } catch (e) { try { net.raw(o); } catch (e2) { if (S.link) S.link.send(o); } } };
    // หมายเหตุ: ไม่มีวิธีอ่านแพ็กเก็ต "เข้า" ฝั่ง client แบบปลอดภัย — เกมผูก handler ตรงที่ ws.onmessage
    //   (S.link.onMessage ของเราไม่ถูกเรียกเลย → เคยลอง hook แล้วไม่ทำงาน)
    //   จึงถือว่า "มายืนหน้าร้าน + ยิง talk แล้ว" = พร้อมขาย และให้ sellOverquota พิสูจน์จริงทีละกอง
    //   (วัดจริง 18:29: talk แล้ว sell ช่อง 29 สำเร็จ +6 Zen ทั้งที่ UI ไม่แสดงหน้าต่างร้าน)
    var t = null, tk = null;
    try { S.ents.forEach(function (e, k) { if (!t && e && e.kind === 'npc' && re.test(e.name || '')) { t = e; tk = k; } }); } catch (e) {}
    if (!t) { try { var e0 = S.ents.get(30000); if (e0 && re.test(e0.name || '')) { t = e0; tk = 30000; } } catch (e) {} }
    if (t) { (window.__vhgShopPos = window.__vhgShopPos || {})[map] = [Math.round(t.rx), Math.round(t.ry)];
      try { localStorage.setItem('vhg.shopPos', JSON.stringify(window.__vhgShopPos)); } catch (e) {} }
    var pos = t ? [t.rx, t.ry] : null, src = t ? 'เห็นตัวเธอในจอ' : '';
    if (!pos) { try { window.__vhgShopPos = window.__vhgShopPos || JSON.parse(localStorage.getItem('vhg.shopPos') || '{}'); } catch (e) { window.__vhgShopPos = {}; } pos = window.__vhgShopPos[map] || null; if (pos) src = 'จำจากที่เคยเห็น (localStorage)'; }
    if (!pos) { var SEED = { '2': [117, 121] }; pos = SEED[map] || null; if (pos) src = 'พิกัดที่คนพัฒนาวัดไว้'; }
    if (!pos) return { ok: false, found: false, msg: 'ไม่รู้ว่าร้าน (Tessa) อยู่ตรงไหนในแมพ "' + ((S.mapEn && S.mapEn[map]) || map) + '" — ให้เดินไปเห็นเธอครั้งนึง แล้วบอทจะจำไว้' };
    var d = Math.hypot(h.rx - pos[0], h.ry - pos[1]);
    if (d > 3) {
      try { if (S.auto) S.auto = false; } catch (e) {}
      if (typeof window.__walk !== 'function') return { ok: false, msg: 'ไม่พบฟังก์ชันเดิน (__walk)' };
      try { window.__walk(Math.round(pos[0]), Math.round(pos[1])); } catch (e) {}
      return { ok: false, walking: true, name: t ? t.name : 'Tessa', msg: 'กำลังเดินไปหาร้าน (' + pos[0] + ',' + pos[1] + ' · ' + src + ' · ห่าง ' + Math.round(d) + ' ช่อง)' };
    }
    // ถึงแล้ว: หยุดนิ่งก่อน (เซิร์ฟไม่รับ talk ขณะเดิน/AUTO เปิด)
    for (var w0 = 0; w0 < 10; w0++) { if (!h.path || !h.path.length) break; await sl(rnd(300, 450)); }
    try { if (S.auto) S.auto = false; } catch (e) {}
    // ยิง talk → รอเซิร์ฟตอบ (ws log ยืนยัน 18:25: talk 30000 → in {t:'shop',npc:30000,...} ทุกครั้ง)
    //   ไม่ต้องเช็ค UI flag เพราะ sell ใช้ได้ทันทีหลัง talk (พิสูจน์ 18:29: sell สำเร็จ +6 Zen)
    var key = (tk == null ? 30000 : tk);
    raw({ t: 'talk', id: key, m: 1, s: 1 });
    await sl(rnd(800, 1400)); // ให้เซิร์ฟส่ง shop packet มา register session ก่อน
    return { ok: true, nearShop: true, npc: key, name: (t && t.name) || 'Tessa the Alchemist', msg: 'คุย ' + ((t && t.name) || 'Tessa') + ' แล้ว — พร้อมขาย' };
  },

  // ---------- 💰 ขาย "ของที่เกินโควตา" ให้เหลือเท่า cap.max ต่อชื่อ ----------
  //   ของจริงวัดจากที่ผู้ใช้ขายเอง (17:48): แพ็กเก็ต = {t:'sell', s:ช่อง} ขายทั้งกองในครั้งเดียว (ไม่มีฟิลด์จำนวน)
  //   · ขนาดกองอยู่ที่ item.dur (ไม่ใช่ .n) · Zen อยู่ที่ S.me.zen (S.panels.zen ไม่มี → เดิมรายงาน +0 เสมอ)
  //   · ต้องคุยร้านก่อน (approachShop → talk 30000 → เซิร์ฟตอบ {t:'shop'}) — เช็คจาก window.__vhgShopAt ที่ hook ของเราบันทึก
  //     DOM ใช้ไม่ได้ (หน้าต่างยัง class hidden / คลาส shopping ติดอยู่ตลอด) · วัดจริง: sell ตอนร้านปิด = เซิร์ฟเงียบ
  //   → เพราะขายทีละทั้งกอง ต้องสแกนใหม่ทุกครั้งและหยุดทันทีที่รวมแล้วไม่เกินโควตา (ไม่งั้นขายเกินจนของที่ต้องเก็บหาย)
  sellOverquota: async function (capCfg) {
    var S = window.S, net = window.__net;
    if (!S || !S.hero || !net || typeof net.sell !== 'function') return { ok: false, msg: 'ไม่พบระบบขาย (__net.sell)' };
    var items = (capCfg && capCfg.items) || [], max = (capCfg && capCfg.max) | 0 || 20;
    var bagFirst = (S.bagCfg && S.bagCfg.first) || 0;
    var sl = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
    var rnd = function (a, b) { return a + Math.random() * (b - a); };
    var nmOf = function (id) { try { var d = S.items && S.items[id]; return (d && d.name && (d.name[1] || d.name[0])) || ('#' + id); } catch (e) { return '#' + id; } }
    var stacksOf = function (q) {
      var out = [];
      try { S.panels.inv.forEach(function (v, slot) {
        if (!v || v.id == null || slot < bagFirst) return;
        var nm = nmOf(v.id);
        if (nm.indexOf(q) < 0) return;
        out.push({ slot: slot, id: v.id, n: v.dur || v.n || 1, lk: !!v.lk, name: nm });
      }); } catch (e) {}
      return out;
    };
    if (!items.length) return { ok: true, sold: [], detail: ['ไม่ได้ตั้งชื่อจำกัดจำนวนไว้'], msg: 'ไม่มีรายชื่อของที่ตั้งโควตา' };
    var zen0 = (S.me && S.me.zen) || 0, sold = [], skip = [], detail = [];
    for (var i = 0; i < items.length; i++) {
      var q = String(items[i] || '').trim(); if (!q) continue;
      var guard = 0;
      while (guard++ < 40) {
        var arr = stacksOf(q), have = 0;
        arr.forEach(function (x) { have += x.n; });
        if (have <= max) { detail.push(q + ' ' + have + '/' + max); break; }
        // ขายกองที่ "เล็กที่สุดที่ขายได้" ก่อน = เผาของน้อยสุดต่อการยิง 1 ครั้ง
        var av = arr.filter(function (x) { return !x.lk; }).sort(function (a, b) { return a.n - b.n; })[0] || null;
        if (!av) { detail.push(q + ' ' + have + '/' + max + ' → เกินแต่ทุกกองล็อกไว้'); skip.push(q + ' (ล็อกทุกกอง)'); break; }
        try { net.sell(av.slot); } catch (e) { skip.push(q + ' (ส่งไม่สำเร็จ)'); break; }
        var gone = false;
        for (var w = 0; w < 7; w++) {
          await sl(rnd(160, 280));
          var now = null; try { now = S.panels.inv.get(av.slot); } catch (e) {}
          if (!now || now.id !== av.id || (now.dur || now.n || 1) < av.n) { gone = true; break; }
        }
        if (!gone) { skip.push(q + ' ×' + av.n + ' (เซิร์ฟไม่ขายให้ — ของชนิดนี้ขายไม่ได้)'); detail.push(q + ' ขายไม่ได้ หยุดที่ ' + have + '/' + max); break; }
        sold.push(q + ' ×' + av.n);
      }
      await sl(rnd(120, 300));
    }
    var zen1 = (S.me && S.me.zen) || 0;
    try { net.closeTalk && net.closeTalk(); } catch (e) {}
    return { ok: sold.length > 0, sold: sold, skipped: skip, detail: detail, gained: zen1 - zen0,
      msg: 'ขาย ' + sold.length + ' กอง' + (sold.length ? (' ได้ +' + (zen1 - zen0).toLocaleString('th-TH') + ' Zen') : ' (ไม่มีกองที่ขายได้)')
        + (skip.length ? (' · ข้าม ' + skip.length + ' ชนิด') : '') };
  },

  // ---------- 💰 คำนวณ "ของที่เกินโควตา" เพื่อขายทิ้ง (อ่านอย่างเดียว ยังไม่ยิงแพ็กเก็ตขาย) ----------
  //   ใช้รายการ "จำกัดจำนวน" เดิมของฟิลเตอร์เก็บของ: ในกระเป๋าชื่อนี้เกิน cap.max = ส่วนเกิน
  sellExcessPlan: function (capCfg) {
    var S = window.S; if (!S || !S.hero) return { ok: false, msg: 'ยังไม่ได้เข้าเกม' };
    var items = (capCfg && capCfg.items) || [];
    var max = (capCfg && capCfg.max) | 0 || 20;
    if (!items.length) return { ok: true, list: [], detail: ['ไม่ได้ตั้งชื่อจำกัดจำนวนไว้'], max: max };
    var bagFirst = (S.bagCfg && S.bagCfg.first) || 0, byName = {};
    try {
      S.panels.inv.forEach(function (v, slot) {
        if (!v || v.id == null || slot < bagFirst) return;
        var d = S.items && S.items[v.id]; if (!d) return;
        var nm = (d.name && (d.name[1] || d.name[0])) || '';
        for (var i = 0; i < items.length; i++) {
          var q = String(items[i] || '').trim();
          if (q && nm.indexOf(q) >= 0) { (byName[q] = byName[q] || []).push({ slot: slot, id: v.id, n: v.n || 1, name: nm }); break; }
        }
      });
    } catch (e) { return { ok: false, msg: e.message }; }
    var list = [], detail = [];
    Object.keys(byName).forEach(function (q) {
      var arr = byName[q], have = 0;
      arr.forEach(function (x) { have += x.n; });
      if (have <= max) { detail.push(q + ' ' + have + '/' + max); return; }
      detail.push(q + ' ' + have + '/' + max + ' → เกิน ' + (have - max));
      arr.sort(function (a, b2) { return b2.n - a.n; }); // เก็บกองใหญ่ไว้ก่อน ขายกองเล็ก
      var keep = max;
      arr.forEach(function (x) { if (keep >= x.n) { keep -= x.n; return; } list.push({ slot: x.slot, id: x.id, name: x.name, n: x.n }); });
    });
    return { ok: true, list: list, detail: detail, total: list.length, max: max };
  },

  // ---------- 📦 คลัง: เดินไปคาฟี + ฝากของ ----------
  // แพ็กเก็ตจริง (อ่านจาก window.__net): stput {s:ช่องกระเป๋า, tb:แท็บคลัง} / stputall {tb} / sttake {i,to}
  // ไม่ใช้ stputall เพราะมันจะกวาดออร์บที่ต้องเก็บไว้ใช้ด้วย
  stashDeposit: async function (opts) {
    var S = window.S, net = window.__net;
    if (!S || !S.hero || !net) return { ok: false, msg: 'ยังไม่ได้เข้าเกม' };
    var sl = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
    var rnd = function (a, b) { return a + Math.random() * (b - a); };
    var raw = function (o) { try { net.raw(o); } catch (e) { if (S.link) S.link.send(o); } };
    var keep = (opts && opts.keep) || {};
    var tab = (opts && opts.tab) | 0;
    var h = S.hero;
    var t = null, tk = null;
    try { S.ents.forEach(function (e, k) { if (!t && e && e.kind === 'npc' && /คาฟี|ผู้ดูแลคลัง|kafi|keeper/i.test(e.name || '')) { t = e; tk = k; } }); } catch (e) {}
    if (!t) { try { t = S.ents.get(30010); if (t) tk = 30010; } catch (e) {} }
    if (!t) {
      var FP = { 2: { x: 133, y: 124 }, 0: { x: 133, y: 124 } }[(S.info && S.info.map) || 0];
      if (FP) {
        if (h.path && h.path.length) return { ok: false, walking: true, msg: 'กำลังเดินไปหาคาฟี ผู้ดูแลคลัง...' };
        try { if (typeof window.__walk === 'function') { window.__walk(FP.x, FP.y + 1); return { ok: false, walking: true, msg: 'กำลังเดินไปหาคาฟี' }; } } catch (e) {}
      }
      return { ok: false, msg: 'ไม่พบคาฟีในแมพนี้ (map ' + (S.info && S.info.map) + ') — ต้องอยู่ที่ Solhaven/Caelmora' };
    }
    var dist = Math.sqrt(Math.pow(h.rx - t.rx, 2) + Math.pow(h.ry - t.ry, 2));
    if (dist > 5) {
      if (h.path && h.path.length) return { ok: false, walking: true, msg: 'กำลังเดินไปหาคาฟี (ห่าง ' + Math.round(dist) + ' ช่อง)' };
      try { if (typeof window.__walk === 'function') { window.__walk(Math.round(t.rx), Math.round(t.ry) + 1); return { ok: false, walking: true, msg: 'กำลังเดินไปหาคาฟี (ห่าง ' + Math.round(dist) + ')' }; } } catch (e) {}
      return { ok: false, msg: 'เดินไปหาคาฟีไม่สำเร็จ' };
    }
    // เซิร์ฟไม่รับ talk ขณะเดิน/AUTO อยู่ → ต้องหยุดนิ่งก่อน (บทเรียนเดียวกับโต๊ะนำร่อง)
    try { if (S.auto) S.auto = false; } catch (e) {}
    if (h.path && h.path.length) return { ok: false, walking: true, msg: 'กำลังหยุดเดินให้สนิทก่อนเปิดคลัง...' };
    if (!S.storeOpen) {
      try { net.closeTalk(); } catch (e) {}
      await sl(rnd(250, 450));
      raw({ t: 'talk', id: tk, m: 1, s: 1 });
      for (var w = 0; w < 12; w++) { await sl(rnd(300, 500)); if (S.storeOpen) break; }
      if (!S.storeOpen) return { ok: false, msg: 'เปิดหน้าคลังไม่สำเร็จ — จะลองใหม่รอบถัดไป' };
      await sl(rnd(500, 900));
    }
    var slots = [], bagFirst = (S.bagCfg && S.bagCfg.first) || 0;
    // ช่อง 0..bagFirst-1 = "ของสวมใส่" (อุปกรณ์/ขวด/เครื่องราง) ฝากไม่ได้ → นับเฉพาะกระเป๋าจริง
    try { S.panels.inv.forEach(function (v, k) { if (v && v.id != null && k >= bagFirst) slots.push({ slot: k, id: v.id, n: v.dur || 1, rar: v.rar | 0 }); }); } catch (e) { return { ok: false, msg: 'อ่านกระเป๋าไม่สำเร็จ: ' + e.message }; }
    var before = slots.length;
    if (!window.__vhgPlanDeposit && opts && opts.lfSrc) {
      try { window.__vhgPlanDeposit = new Function(opts.lfSrc + '\nreturn planDeposit;')(); } catch (e) { window.__vhgPlanDeposit = null; }
    }
    if (!window.__vhgPlanDeposit) return { ok: false, msg: 'ไม่พบตัววางแผนฝากของ (lootfilter.js หายไป) — แจ้งคนพัฒนา' };
    var plan = window.__vhgPlanDeposit(slots, keep);
    // เกมฝากของด้วยแพ็กเก็ต "แยกตามชนิด" ไม่ใช่ stput อย่างเดียว:
    //   stput {s,tb} = ช่องทั่วไป (เลือกแท็บได้) | stcput {s} = เงินตรา/ออร์บ/ม้วน
    //   stjput {s} = จิวเวล (ring/amulet/belt) | stuput {s} = ยูนีค (rar3) | stgput {s} = เจม
    var putKindOf = function (id, rar) {
      var d = S.items && S.items[id]; var cat = d && d.cat;
      if (rar >= 3) return 'stuput';
      if (cat === 'currency') return 'stcput';
      if (cat === 'ring' || cat === 'amulet' || cat === 'belt' || cat === 'jewel') return 'stjput';
      if (cat === 'gem' || cat === 'skillgem') return 'stgput';
      return 'stput';
    };
    var bySlot = {}; slots.forEach(function (x) { bySlot[x.slot] = x; });
    var maxTabs = 4;
    try { var sz = S.shop && S.shop.stash; if (sz && sz.tabs) maxTabs = sz.tabs | 0; } catch (e) {}
    if (maxTabs < 1) maxTabs = 1;
    var curTab = tab | 0, putOk = 0, noRoom = 0, perTab = {}, failed = [];
    var nmOf3 = function (id) { var d = S.items && S.items[id]; return (d && d.name && (d.name[1] || d.name[0])) || ('#' + id); };
    for (var i = 0; i < plan.put.length; i++) {
      var bagSlot = plan.put[i], landed = false;
      var si = bySlot[bagSlot] || {};
      var kind = putKindOf(si.id, si.rar || 0);
      var tries = kind === 'stput' ? maxTabs : 1;   // มีแค่ stput ที่เลือกแท็บได้
      for (var ti = 0; ti < tries && !landed; ti++) {
        var tbTry = (curTab + ti) % maxTabs;
        if (kind === 'stput') raw({ t: 'stput', s: bagSlot, tb: tbTry });
        else if (kind === 'stcput') raw({ t: 'stcput', s: bagSlot });
        else if (kind === 'stjput') raw({ t: 'stjput', s: bagSlot });
        else if (kind === 'stuput') raw({ t: 'stuput', s: bagSlot });
        else raw({ t: 'stgput', s: bagSlot });
        for (var k = 0; k < 6; k++) { await sl(rnd(130, 230)); if (!S.panels.inv.get(bagSlot)) { landed = true; break; } }
        if (landed && kind === 'stput') { curTab = tbTry; perTab[tbTry] = (perTab[tbTry] || 0) + 1; }
      }
      if (landed) putOk++;
      else { noRoom++; if (failed.length < 12) failed.push(nmOf3(si.id) + ' ×' + (si.n || 1)); }
      await sl(rnd(60, 190)); // หน่วงสุ่มระหว่างชิ้น
    }
    try { net.closeTalk(); } catch (e) {}
    await sl(rnd(900, 1600));
    var after = 0, afterById = {};
    try { S.panels.inv.forEach(function (v, k) { if (v && v.id != null && k >= bagFirst) { after++; afterById[v.id] = (afterById[v.id] || 0) + (v.dur || 1); } }); } catch (e) {}
    // นับว่า "อะไรออก ไปเท่าไหร่" จากการเทียบจำนวนต่อ id (ไม่ใช่แค่จำนวนช่อง)
    var beforeById = {};
    slots.forEach(function (x) { beforeById[x.id] = (beforeById[x.id] || 0) + (x.n || 1); });
    var nmOf2 = function (id) { var d = S.items && S.items[id]; return (d && d.name && (d.name[1] || d.name[0])) || ('ไอเทม #' + id); };
    var putLines = [];
    Object.keys(beforeById).forEach(function (id) {
      var gone = (beforeById[id] || 0) - (afterById[id] || 0);
      if (gone > 0) putLines.push(nmOf2(+id) + ' ×' + gone);
    });
    window.__vhgBagSnap = null; window.__vhgEvts = [];
    var keptTxt = Object.keys(plan.kept).map(function (kk) { return nmOf2(+kk) + ' ×' + plan.kept[kk]; }).join(', ');
    var tabTxt = Object.keys(perTab).map(function (kk) { return 'แท็บ ' + (+kk + 1) + ' ' + perTab[kk] + ' ชิ้น'; }).join(', ');
    return {
      ok: noRoom === 0, done: true, before: before, after: after, sent: putOk, kept: plan.kept, noRoom: noRoom, list: putLines,
      msg: 'ฝากเข้าคลัง ' + putOk + ' ชิ้น (' + before + ' → ' + after + ' ช่อง)' + (tabTxt ? ' · ' + tabTxt : '')
        + (putLines.length ? '\n   📤 ' + putLines.join(' | ') : '')
        + (keptTxt ? '\n   📌 เก็บไว้: ' + keptTxt : '')
        + (noRoom ? '\n   ⚠️ ฝากไม่ได้อีก ' + noRoom + ' ชิ้น: ' + failed.join(', ') : ''),
    };
  },

  // ---------- เดินทาง ----------
  goTown: function () {
    var S = window.S, net = window.__net;
    if (!S || !S.hero) return { ok: false, msg: 'ยังไม่ได้เข้าเกม' };
    if (S.dead) return { ok: false, msg: 'ตัวตายอยู่' };
    var cur = (S.info && S.info.map != null) ? S.info.map : null;
    if (cur === 0) return { ok: true, msg: 'อยู่แล้วที่ Caelmora (เมือง)' };
    if (!net) return { ok: false, msg: 'ไม่พบระบบเดินทาง' };
    // ใช้ "ประตูวาร์ปกลับเมือง" ก่อน ({t:'portal'} ถึงทันที) — net.travel(0) ต้องเดินเท้าข้ามหลายแมพเป็นนาที
    //   เงื่อนไขเกม: ต้องยืนนิ่งตอนแคสต์ (ถ้าโดนตีระหว่างแคสต์ ประตูจะไม่ติด → ธง S.tpCasting)
    if (typeof net.portal === 'function') {
      if (S.tpCasting) return { ok: true, casting: true, msg: 'กำลังเปิดประตูกลับเมือง — ยืนนิ่งก่อน' };
      if (!(S.hero.path && S.hero.path.length)) {
        try { net.portal(); return { ok: true, portal: true, msg: '🌀 เปิดประตูกลับเมือง Caelmora (ถึงทันที)' }; } catch (e) {}
      } else return { ok: true, moving: true, msg: 'ยังเดินอยู่ — รอหยุดก่อนเปิดประตู' };
    }
    if (typeof net.travel !== 'function') return { ok: false, msg: 'ไม่พบระบบเดินทาง' };
    try { net.travel(0); return { ok: true, msg: 'เดินทางกลับเมือง Caelmora (map 0)' }; }
    catch (e) { return { ok: false, msg: e.message || 'travel fail' }; }
  },
  warpTo: function (mapId) {
    var S = window.S, net = window.__net;
    if (!S || !S.hero) return { ok: false, msg: 'ยังไม่ได้เข้าเกม' };
    if (S.dead) return { ok: false, msg: 'ตัวตายอยู่' };
    if (!net) return { ok: false, msg: 'ไม่พบระบบเดินทาง' };
    var target = (typeof mapId === 'number') ? mapId : parseInt(mapId, 10);
    if (isNaN(target)) return { ok: false, msg: 'mapId ไม่ใช่ตัวเลข: ' + mapId };
    var cur = (S.info && S.info.map != null) ? S.info.map : null;
    if (cur === target) return { ok: true, msg: 'อยู่แล้ว' };
    var nm = null; try { nm = (S.mapTh && S.mapTh[target]) || (S.mapEn && S.mapEn[target]) || ('map ' + target); } catch (e) { nm = 'map ' + target; }
    try {
      // waypoint teleport ต้อง "ยืนใกล้จุดเวย์พอยต์" จริง ๆ (เซิร์ฟตอบ sys: ต้องยืนใกล้เวย์พอยต์)
      //   เกมเก็บตำแหน่งจุดของแต่ละแมพไว้ที่ B.story.go.wp[map] และใช้รัศมี 4 ช่อง (ค่า ut.wpNear ของเกม)
      var wps = (S.me && S.me.wps) || [];
      var hasWp = wps.indexOf(target) >= 0 || wps.indexOf(String(target)) >= 0;
      var pad = null; try { pad = (window.B && window.B.story && window.B.story.go && window.B.story.go.wp && window.B.story.go.wp[cur]) || (S.story && S.story.go && S.story.go.wp && S.story.go.wp[cur]) || null; } catch (e) {}
      if (hasWp && typeof net.wpGo === 'function') {
        if (pad && Math.hypot((S.hero.rx || 0) - pad[0], (S.hero.ry || 0) - pad[1]) > 3.5) {
          try { if (typeof window.__walk === 'function') window.__walk(pad[0], pad[1]); } catch (e) {}
          return { ok: true, pending: true, pad: [pad[0], pad[1]], msg: 'เดินไปจุดเวย์พอยต์ (' + pad[0] + ',' + pad[1] + ') ก่อนจะไป ' + nm };
        }
        net.wpGo(target); return { ok: true, msg: 'วาร์ป (waypoint) ไป ' + nm };
      }
      net.travel(target); return { ok: true, msg: 'เดินทาง ไป ' + nm };
    } catch (e) { return { ok: false, msg: e.message || 'warp fail' }; }
  },

  // ข้อมูลแมพจากเกมจริง: ระดับพื้นที่ (mapArea), เลเวลบังคับ (mapPen), เวย์พอยต์ที่ปลดล็อก (me.wps)
  mapInfo: function () {
    var S = window.S; if (!S) return [];
    var wps = (S.me && S.me.wps) || [], out = [];
    try {
      Object.keys(S.mapArea || {}).forEach(function (k) {
        var id = +k;
        out.push({ id: id, name: (S.mapTh && S.mapTh[id]) || (S.mapEn && S.mapEn[id]) || ('map ' + id), area: S.mapArea[k] | 0, pen: (S.mapPen && S.mapPen[id]) | 0, wp: wps.indexOf(id) >= 0 });
      });
    } catch (e) {}
    out.sort(function (a, b2) { return a.area - b2.area; });
    return out;
  },

  // ---------- 🐉 บอสโลก (อ่านจาก S.wbUi จริง — เกมเก็บ {state:'warn'|'up', map, ch, at, until, gm} ไว้ครบ) ----------
  //   ตอนบอสตาย/จบงาน เกมจะรีเซ็ต st = null → ใช้เป็นสัญญาณ "ปราบสำเร็จ" ได้เลย ไม่ต้องเดาจากข้อความ
  worldBoss: function () {
    var S = window.S, W = S && S.wbUi;
    if (!W) return { none: true, hasUi: false };
    var nm = ''; try { nm = (W.bossName && W.bossName()) || ''; } catch (e) {}
    var st = W.st;
    if (!st) return { none: true, hasUi: true, name: nm };
    var now = Date.now();
    var needLv = null, wpOpen = false, myLv = null;
    try { needLv = (S.mapPen && S.mapPen[st.map] != null) ? (S.mapPen[st.map] | 0) : null; } catch (e) {}
    try { var wps = (S.me && S.me.wps) || []; wpOpen = wps.indexOf(st.map) >= 0 || wps.indexOf(String(st.map)) >= 0; } catch (e) {}
    try { myLv = ((S.me && S.me.level) || (S.stats && S.stats.level) || 0) | 0 || null; } catch (e) {}
    return {
      none: false, hasUi: true, state: st.state, name: nm, map: st.map, ch: st.ch, gm: !!st.gm,
      needLv: needLv, wpOpen: wpOpen, myLv: myLv,
      at: st.at, until: st.until,
      leftSec: Math.round((st.at - now) / 1000),      // เหลือกี่วินาทีถึงจะเกิด (state 'warn')
      liveSec: Math.round((st.until - now) / 1000),   // เกิดอยู่แล้ว = เหลือเวลาตีอีกเท่าไหร่
    };
  },
  // สถานะในรัง: เลือดบอส (% จาก ent.hp) + จำนวนผู้เล่นรอบตัว — เกมบังคับ "ต้องมี 10 คนตีพร้อมกันถึงจะเข้า"
  wbStatus: function (wantName) {
    var S = window.S; if (!S || !S.hero) return null;
    var h = S.hero, out = { map: (S.info && S.info.map != null) ? S.info.map : null, players: 0, boss: null, dead: !!S.dead };
    try { out.hpPct = (h.hp != null && h.maxHp) ? Math.round((h.hp / h.maxHp) * 100) : null; } catch (e) {}
    var want = String(wantName || '');
    var best = null;
    try {
      S.ents.forEach(function (e) {
        if (!e || e.rx == null) return;
        var d = Math.hypot(e.rx - h.rx, e.ry - h.ry);
        if (e.kind === 'player') { if (d <= 80) out.players++; return; }
        if (e.kind !== 'monster' || e.dead > 0) return;
        var nm = e.name || '';
        var hit = (want && nm && (nm === want || nm.indexOf(want.slice(0, 6)) >= 0)) || e.boss;
        if (hit && (!best || d < best.d)) best = { name: nm, hp: (e.hp == null ? null : e.hp), d: Math.round(d) };
      });
    } catch (e) {}
    out.boss = best;
    return out;
  },
  // ยังอยู่บนเกาะ Voyage ไหม (ใช้รอให้เกมพาขึ้นฝั่งจริงก่อน ค่อยวาร์ป — ยิงทับตอนออกเกาะ เซิร์ฟทิ้งแพ็กเก็ต)
  wbOnIsle: function () {
    var S = window.S;
    return { run: !!(S && S.voyUi && S.voyUi.run), map: (S && S.info && S.info.map) != null ? S.info.map : null };
  },
  // อยู่กลางทริป Voyage → ออกเกาะทันที (แพ็กเก็ตเดียวกับที่ตัวเดินอัตโนมัติใช้ตอนครบเวลาเก็บของ)
  wbLeaveIsle: function () {
    var S = window.S, net = window.__net;
    try { if (!(S && S.voyUi && S.voyUi.run)) return { ok: true, msg: 'ไม่ได้อยู่บนเกาะ' }; } catch (e) {}
    try { net.raw({ t: 'voy', op: 'leave' }); return { ok: true, msg: 'ออกเกาะทันที (ไปบอสโลก)' }; }
    catch (e) { return { ok: false, msg: e.message || 'voy leave fail' }; }
  },
  // เดินไปใกล้ "เวย์พอยต์" (NPC 30023 ที่ 128,128 ใน Solhaven) — ผู้ใช้สอน 30/10: ต้องคุยตัวนี้ก่อนถึงวาร์ปไปรังมังกรได้
  wbWalkToWp: function () {
    var S = window.S; if (!S || !S.hero) return { ok: false, msg: 'ยังไม่เข้าเกม' };
    var h = S.hero, WX = 128, WY = 128;
    if (String(S.info.map) !== '2' && String(S.info.map) !== '0') return { ok: true, msg: 'ไม่ได้อยู่เมือง (อาจวาร์ปไปแล้ว)' };
    var d = Math.hypot(h.rx - WX, h.ry - WY);
    if (d <= 3) return { ok: true, msg: 'ถึงเวย์พอยต์แล้ว (ห่าง ' + Math.round(d) + ')' };
    if (h.path && h.path.length) return { ok: false, walking: true, msg: 'กำลังเดินไปเวย์พอยต์ (ห่าง ' + Math.round(d) + ')' };
    try { if (typeof window.__walk === 'function') window.__walk(WX, WY); } catch (e) {}
    return { ok: false, walking: true, msg: 'สั่งเดินไปเวย์พอยต์ (ห่าง ' + Math.round(d) + ')' };
  },
  // คุยเวย์พอยต์ → wpGo(mapId) — ข้าม S.me.wps เพราะ NPC เปิดเมนูให้ได้ทุก destination ที่ปลดล็อก
  wbWarpTo: function (mapId) {
    var S = window.S, net = window.__net;
    if (!S || !S.hero || !net) return { ok: false, msg: 'ยังไม่เข้าเกม' };
    var target = (typeof mapId === 'number') ? mapId : parseInt(mapId, 10);
    var cur = S.info && S.info.map;
    if (String(cur) === String(target)) return { ok: true, msg: 'อยู่แล้ว (แมพ ' + target + ')' };
    // หา entity เวย์พอยต์ใกล้ตัว (30023 หรือชื่อ "เวย์พอยต์"/"เสาหมายทาง")
    var wk = null;
    try { S.ents.forEach(function (e, k) { if (!wk && e && e.kind === 'npc' && /เวย์พอยต์|เสาหมายทาง|waypoint|waypost/i.test(e.name || '')) wk = k; }); } catch (e) {}
    if (wk == null) wk = 30023;
    try { net.talk(wk, 1, 1); } catch (e) {}
    var sl = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
    return sl(800).then(function () {
      try { net.wpGo(target); return { ok: true, msg: 'วาร์ป (waypoint) ไป ' + ((S.mapTh && S.mapTh[target]) || (S.mapEn && S.mapEn[target]) || 'map ' + target) }; }
      catch (e) {
        try { net.travel(target); return { ok: true, msg: 'wpGo ไม่สำเร็จ → ใช้ travel (เดินเท้า) ไป map ' + target }; }
        catch (e2) { return { ok: false, msg: e.message || 'warp fail' }; }
      }
    });
  },
  // ถึงรังบอสแล้ว: เดินไปที่พิกัดกลาง (จุดบอสเกิด)
  wbWalkToCenter: function (pos) {
    var S = window.S; if (!S || !S.hero) return { ok: false };
    var cx = (pos && pos.x) || 127, cy = (pos && pos.y) || 122;
    var h = S.hero, d = Math.hypot(h.rx - cx, h.ry - cy);
    if (d <= 5) return { ok: true, msg: 'อยู่กลางรังแล้ว (ห่าง ' + Math.round(d) + ')' };
    try { if (typeof window.__walk === 'function') window.__walk(cx, cy); } catch (e) {}
    return { ok: true, msg: 'เดินไปกลางรัง (ห่าง ' + Math.round(d) + ')' };
  },

  // ใช้ขวดยาด้วย "แพ็กเก็ตจริง" ที่เกมใช้ ({t:'flask',k}) — แม่นกว่ากดคีย์ (คีย์ 1 อาจผูกกับสกิล ไม่ใช่ขวด)
  //   k=0 = ขวดเลือด (สวมช่อง 10) · k=1 = ขวดมานา (ช่อง 11) · เกมจะตอบ 'flaskno' ถ้าชาร์จไม่พอ
  useFlask: function (k) {
    var S = window.S, net = window.__net;
    if (!S || !S.hero) return { ok: false, msg: 'ยังไม่ได้เข้าเกม' };
    if (!net || typeof net.flask !== 'function') return { ok: false, msg: 'ไม่พบระบบขวด (__net.flask)' };
    var slot = (k === 1) ? 11 : 10;
    var it = null; try { it = S.panels.inv.get(slot); } catch (e) {}
    var left = it ? (it.dur || 0) : null;
    if (left === 0) return { ok: false, noCharge: true, msg: 'ชาร์จขวดยาหมด (ช่อง ' + slot + ')' };
    try { net.flask(k === 1 ? 1 : 0); return { ok: true, left: left }; }
    catch (e) { return { ok: false, msg: e.message || 'flask fail' }; }
  },
  // หลักฐานตอนตาย: AUTO เปิดไหม / ชาร์จยาเหลือแค่ไหน / ศัตรูใกล้สุดห่างกี่ช่อง / อยู่บนเกาะหรือเปล่า
  deathContext: function () {
    var S = window.S; if (!S || !S.hero) return null;
    var out = { autoOn: !!(S.bot && S.bot.on) || !!S.auto, hpFlask: null, hpFlaskMax: null, mpFlask: null, enemyDist: null, onIsle: !!(S.voyUi && S.voyUi.run), map: (S.info && S.info.map) };
    try {
      var a = S.panels.inv.get(10), m = S.panels.inv.get(11);
      if (a) { out.hpFlask = a.dur; var da = S.items && S.items[a.id]; out.hpFlaskMax = da && da.flask ? da.flask.charges : null; }
      if (m) out.mpFlask = m.dur;
    } catch (e) {}
    try {
      var h = S.hero, best = null;
      S.ents.forEach(function (e) { if (!e || e.kind !== 'monster' || e.dead > 0 || e.rx == null) return; var d = Math.hypot(e.rx - h.rx, e.ry - h.ry); if (best == null || d < best) best = d; });
      out.enemyDist = best == null ? null : Math.round(best);
    } catch (e) {}
    return out;
  },

  // ---------- 📜 โหมดวิ่งเควส — ใช้ระบบของเกมเอง (S.journal.go + state S.aq) เราแค่สั่ง/เฝ้า ----------
  questStatus: function () {
    var S = window.S, J = S && S.journal;
    if (!J || !J.Q) return { ok: false, msg: 'ไม่พบบันทึกเควส (ยังไม่เข้าเกม?)' };
    var out = { ok: true, total: 0, list: [], running: null, next: '', tracked: '', whyNot: '', lv: (S.me && S.me.level) || (S.stats && S.stats.level) || null }; // S.hero.lvl ไม่มีจริง (เคยได้ null ตลอด → แดชบอร์ดขึ้น "Lv ?")
    try { out.tracked = J.tracked() || ''; } catch (e) {}
    var ids = Object.keys(J.Q); out.total = ids.length;
    ids.forEach(function (id) {
      var q = J.Q[id]; if (!q) return;
      var stt = ''; try { stt = J.st(id); } catch (e) {}
      if (stt !== 'a') return; // เอาเฉพาะเควสที่ทำได้ตอนนี้ ('a'; 'd'=จบแล้ว)
      var open = []; try { open = J.openSteps(q) || []; } catch (e) {}
      var prog = null; try { prog = (J.S && J.S.q && J.S.q[id] && J.S.q[id][1]) || null; } catch (e) {}
      var first = open.length ? q.steps[open[0]] : null;
      var why = ''; try { why = J.noRun(q) || ''; } catch (e) {}
      var zmap = null, zarea = null, pl = null;
      try {
        pl = J.placeOf(q);
        if (pl && pl.places && pl.places[0]) { zmap = pl.places[0][0] | 0; zarea = (S.mapArea && S.mapArea[zmap] != null) ? (S.mapArea[zmap] | 0) : null; }
      } catch (e) {}
      // จุดบอดจริงของเกม: noRun() เช็คแค่ขั้น party / evk แต่ข้ามขั้น {k:'do', ev:'deep'|'wreck'} (เควสกิจกรรมโลก
      // เช่น 2.6 ผนึกโพรงกัดกิน, 2.8 ขุดซากเรือเหาะ) → คืนค่าว่าง = บอทนึกว่าวิ่งได้
      // แต่ go() ใช้คนละประตู: if(!placeOf(q)){ toast(); return } = ปฏิเสธเงียบ ไม่ตั้ง S.aq
      // → ต้องตัดสินด้วย placeOf() ให้ตรงกับที่เกมทำจริง เควสประเภทนี้จะหลุดจาก pool
      //   แล้วฝั่ง accounts.js จะพาไป "ฟาร์มมอนตามเลเวล" แทน (ไม่งั้นบอทวนลองตัวเดิมยืนเฉยเป็นชั่วโมง)
      if (!why && !pl) why = 'เกมไม่มีจุดเป้าหมายให้วิ่งอัตโนมัติ (ต้องรออีเวนต์/ทำจากหน้าต่างเกมเอง)';
      out.list.push({
        id: id, name: q.name || id, line: q.line || '', step: open.length ? (open[0] + 1) + '/' + (q.steps || []).length : '',
        text: first ? String(first.t || '').slice(0, 90) : '',
        need: first && (first.n | 0) ? (first.n | 0) : 1,
        have: (prog && open.length) ? (prog[open[0]] | 0) : 0,
        canRun: !why, why: why, zmap: zmap, area: zarea,
        // ชนิดขั้นปัจจุบัน: 'far'=ต้องออกเรือ (เกมพาเดินไปโต๊ะนำร่องแล้วจบ เราส่งต่อให้วงวน Voyage), 'boss'=ตีบอส, 'kill'/'do'/'talk' ฯลฯ
        k: first ? String(first.k || '') : '', tier: first && first.tier ? (first.tier | 0) : null,
      });
    });
    if (out.list.length) {
      var core = out.list.filter(function (x) { return x.line === 'core'; });
      out.next = out.tracked || (core[0] && core[0].id) || (out.list[0] && out.list[0].id) || '';
      var pick = out.list.filter(function (x) { return x.id === out.next; })[0];
      out.whyNot = pick && !pick.canRun ? pick.why : '';
    }
    try { if (S.aq) out.running = { q: S.aq.q, i: S.aq.i, phase: S.aq.phase, map: (S.info && S.info.map) }; } catch (e) {}
    try { out.px = Math.round(S.hero.rx); out.py = Math.round(S.hero.ry); out.map = (S.info && S.info.map); } catch (e) {}
    try { out.target = (S.aq && S.aq.places && S.aq.places[0]) || null; } catch (e) {}
    return out;
  },
  questGo: function (id) {
    var S = window.S, J = S && S.journal;
    if (!J || typeof J.go !== 'function') return { ok: false, msg: 'ไม่พบระบบเควสในเกม' };
    try { J.go(id); } catch (e) { return { ok: false, msg: e.message }; }
    return { ok: !!S.aq, q: S.aq && S.aq.q, phase: S.aq && S.aq.phase, msg: S.aq ? ('เริ่มวิ่งเควส ' + id) : ('ไม่เริ่ม: ' + id + ' — เกมว่าวิ่งอัตโนมัติไม่ได้ (ดูเหตุผลในรายการเควส)') };
  },
  questStop: function () {
    var S = window.S, J = S && S.journal;
    if (!S || !S.aq) return { ok: true, msg: 'ไม่ได้วิ่งเควสอยู่' };
    var id = S.aq.q;
    try { J.go(id); } catch (e) { return { ok: false, msg: e.message }; } // go() เป็น toggle
    return { ok: !S.aq, msg: S.aq ? 'หยุดไม่สำเร็จ' : 'หยุดวิ่งเควสแล้ว' };
  },

  // ---------- 🕯 เสาหมายทาง = จุดเกิดใหม่ ----------
  //   ยืนยันจากโค้ดเกม case 'revive': ถ้าเซิร์ฟส่ง cp มาด้วย ข้อความคือ
  //   "ฟื้นคืนชีพที่เสาหมายทาง (ไม่เสียค่าประสบการณ์)" ไม่งั้น "ฟื้นคืนชีพที่จุดเริ่มของแผนที่"
  //   → แตะเสาให้ติดไว้ก่อนไปตีบอส ตายแล้วไม่ต้องเดินไกล (เกมจุดเองเมื่อเราเดินเข้าไปใกล้)
  pillarNear: function (maxDist) {
    var S = window.S; if (!S || !S.hero) return { ok: false, list: [] };
    var lim = maxDist || 70, out = [];
    try {
      S.ents.forEach(function (e, k) {
        if (!e || e.kind !== 'npc') return;
        if (!/^เสาหมายทาง|waypoint|waypost/i.test(String(e.name || '').trim())) return;
        var d = Math.round(Math.hypot(e.rx - S.hero.rx, e.ry - S.hero.ry));
        if (d <= lim) out.push({ k: k, name: e.name, x: Math.round(e.rx), y: Math.round(e.ry), d: d });
      });
    } catch (e) { return { ok: false, list: [], msg: e.message }; }
    out.sort(function (a, b2) { return a.d - b2.d; });
    return { ok: true, list: out, map: (S.info && S.info.map) };
  },

  // ---------- 🌾 ฟาร์มตามเลเวล — ใช้ตอน "เควสนำเลเวล" แล้วตายบ่อย ----------
  //   เปิด interval ในหน้าเกม: เลือกเฉพาะมอนที่ level <= เลเวลเรา + slack แล้วบังคับ AUTO เล็งตัวนั้น
  //   (เกมมี field level บนเอนทิตี้มอนจริง — ยืนยันจากเกมสด) และเลิกเล็งตัวที่เลเวลเกิน
  lvHuntStart: function (opts) {
    var S = window.S; if (!S || !S.hero) return { ok: false, msg: 'ยังไม่เข้าเกม' };
    window.__vhgLvOpts = opts || {};
    // อยู่ในเมือง = ไม่มีมอนให้ตี → ปิดตัวเองทันที (เจอจริง: บอทวนหามอนใน Solhaven ทั้งที่เมืองไม่มีมอน)
    var townOf = function () {
      try {
        var cur = String((window.S.info && window.S.info.map) != null ? window.S.info.map : '');
        var towns = (window.__vhgLvOpts && window.__vhgLvOpts.towns) || ['0', '2'];
        return towns.map(String).indexOf(cur) >= 0 || cur === '0' || cur === '2';
      } catch (e) { return false; }
    };
    if (townOf()) {
      if (window.__vhgLvTimer) { clearInterval(window.__vhgLvTimer); window.__vhgLvTimer = null; }
      return { ok: true, inTown: true, msg: 'อยู่ในเมือง — โหมดฟาร์มตามเลเวลจบรอบ (ให้ไปฝากของ/ขาย/วิ่งเควสต่อ)' };
    }
    if (window.__vhgLvTimer) clearInterval(window.__vhgLvTimer);
    window.__vhgLvLog = '';
    window.__vhgLvTimer = setInterval(function () {
      try {
        var SS = window.S, h = SS && SS.hero; if (!h) return;
        if (townOf()) { // กลับเข้าเมืองสำเร็จ (ประตู/วาร์ป) → จบรอบทันที อย่าวนหามอนในเมือง
          clearInterval(window.__vhgLvTimer); window.__vhgLvTimer = null;
          window.__vhgLvLog = '🏠 ถึงเมืองแล้ว — โหมดฟาร์มตามเลเวลจบรอบ';
          return;
        }
        // เลเวลจริง: S.hero.lvl ไม่มี (และ S.hero.level = 0 เสมอ) → ใช้สูตรเดียวกับ readStats
        var myLv = ((SS.me && SS.me.level) || (SS.stats && SS.stats.level) || h.lvl || h.level || (SS.selChar && SS.selChar.level) || 0) | 0;
        var o = window.__vhgLvOpts || {}, slack = (o.slack == null ? 0 : +o.slack), cap = (myLv || 1) + slack;
        var log = function (m) { if (m && m !== window.__vhgLvLog) { window.__vhgLvLog = m; window.__vhgLvAt = Date.now(); } };
        var setAuto = function (on) { try { if (typeof window.__bot === 'function' && (!!SS.bot !== on)) window.__bot(on); if (on && SS.bot) SS.bot.home = [Math.round(h.rx), Math.round(h.ry)]; } catch (e) {} };
        var walkTo = function (x, y) { try { if (typeof window.__walk === 'function') { window.__walk(Math.round(x), Math.round(y)); return true; } } catch (e) {} return false; };
        var walkable = function (x, y) { try { return !!(SS.grid && SS.grid.walkable(Math.round(x), Math.round(y))); } catch (e) { return true; } };

        var best = null, bd = 999, near = null, nd = 999, cur = null, curLv = null;
        try {
          SS.ents.forEach(function (e, k) {
            if (!e || e.kind !== 'monster' || e.dead > 0 || e.rx == null) return;
            var d = Math.hypot(e.rx - h.rx, e.ry - h.ry);
            if (k === SS.targetKey) { cur = e; curLv = e.level | 0; }
            if (d < nd) { nd = d; near = e; }
            if ((e.level | 0) > cap || d > 40) return;
            if (d < bd) { bd = d; best = { k: k, e: e, d: d, lv: e.level | 0, name: e.name || '' }; }
          });
        } catch (e) {}

        if (best) {
          // มีมอนเลเวลเหมาะ → เปิด AUTO ให้เกมตี/กดยาเอง แล้วเล็งตัวนี้
          setAuto(true);
          if (cur && curLv != null && curLv > cap) { try { SS.targetKey = best.k; } catch (e) {} }
          else if (best.d > 2 && (SS.targetKey < 0 || (cur && cur.dead > 0))) { try { SS.targetKey = best.k; } catch (e) {} }
          if (best.d > 14) walkTo(best.e.rx, best.e.ry);
          log('🌾 เรา Lv' + myLv + ' → ตี ' + (best.name || 'มอน') + ' Lv' + best.lv + ' ห่าง ' + Math.round(best.d) + ' (เพดาน ≤ ' + cap + ')');
          return;
        }

        // ไม่มีมอนเลเวลเหมาะในรัศมี 40 = ต้องหยุดตี ไม่ใช่ยืนให้มันตีเล่น
        setAuto(false);
        try { if (SS.targetKey >= 0) SS.targetKey = -1; } catch (e) {}
        if (near && nd <= 12) {
          // หนีทิศตรงข้ามมอนที่ใกล้สุด (หาช่องที่เดินได้ก่อน ไม่ทะลุหิน)
          var ang = Math.atan2(h.ry - near.ry, h.rx - near.rx), esc = null;
          for (var s = 0; s < 8 && !esc; s++) {
            var a2 = ang + (s - 3) * 0.35, r2 = 14;
            var px = h.rx + Math.cos(a2) * r2, py = h.ry + Math.sin(a2) * r2;
            if (walkable(px, py)) esc = [px, py];
          }
          if (!esc) esc = [h.rx + Math.cos(ang) * 8, h.ry + Math.sin(ang) * 8];
          walkTo(esc[0], esc[1]);
          log('🏃 ไม่มีมอน Lv ≤ ' + cap + ' · ' + ((near && near.name) || 'มอน') + ' Lv' + ((near && near.level) | 0) + ' ห่าง ' + Math.round(nd) + ' → ปิด AUTO แล้วถอย');
          return;
        }
        // ไม่มีมอนเหมาะในแมพนี้ → เปิด "ประตูวาร์ปกลับเมือง" ก่อน (ปลอดภัยกว่าเดิน 90 ช่องผ่านมอน Lv40)
        //   เกมใช้แพ็กเก็ต {t:'portal'} และต้องยืนนิ่งระหว่างแคสต์ (เกมตั้งธง tpCasting)
        var net = window.__net;
        if (net && typeof net.portal === 'function') {
          if (SS.tpCasting) { log('🌀 กำลังเปิดประตูกลับเมือง — ยืนนิ่งก่อน (โดนตีระหว่างแคสต์ ประตูจะไม่ติด)'); return; }
          if (!window.__vhgTpAt || Date.now() - window.__vhgTpAt > 8000) {
            window.__vhgTpAt = Date.now();
            try { net.portal(); log('🌀 เปิดประตูวาร์ปกลับเมือง (เรา Lv' + myLv + ' · ไม่มีมอน Lv ≤ ' + cap + ' ในแมพนี้)'); return; } catch (e) {}
          }
          log('🌀 รอประตูวาร์ปกลับเมือง');
          return;
        }
        var pad = null; try { pad = (SS.story && SS.story.go && SS.story.go.wp && SS.story.go.wp[SS.info && SS.info.map]) || null; } catch (e) {}
        var padD = pad ? Math.round(Math.hypot(pad[0] - h.rx, pad[1] - h.ry)) : 9e9;
        // แตะ "เสาหมายทาง" ก่อนถ้ามันใกล้กว่า — จะได้มีจุดเกิดใกล้ ๆ เวลาตาย
        var pil = null;
        try {
          SS.ents.forEach(function (e) {
            if (!e || e.kind !== 'npc' || !/^เสาหมายทาง|waypoint|waypost/i.test(String(e.name || '').trim())) return;
            var dp = Math.hypot(e.rx - h.rx, e.ry - h.ry);
            if (dp <= 60 && (!pil || dp < pil.d)) pil = { x: Math.round(e.rx), y: Math.round(e.ry), d: Math.round(dp), name: e.name };
          });
        } catch (e) {}
        if (pil && pil.d < padD) { walkTo(pil.x, pil.y); log('🕯 เดินไปแตะ ' + pil.name + ' (ห่าง ' + pil.d + ') ให้เป็นจุดเกิดก่อนตาย'); return; }
        if (pad) { walkTo(pad[0], pad[1]); log('🚶 ไม่มีมอน Lv ≤ ' + cap + ' ในแมพนี้ (เรา Lv' + myLv + ') → ปิด AUTO เดินไปจุดเวย์พอยต์ (' + pad[0] + ',' + pad[1] + ') ข้ามแมพ'); return; }
        log('🌾 เรา Lv' + myLv + ' ไม่พบมอน Lv ≤ ' + cap + ' และหาจุดเวย์พอยต์ไม่เจอ — หยุดตีรอคำสั่งย้ายแมพ');
      } catch (e) {}
    }, 1600);
    return { ok: true, msg: 'เปิดโหมดฟาร์มตามเลเวล (เป้า ≤ เลเวลเรา' + ((opts && opts.slack) || 0) + ')' };
  },
  lvHuntStop: function () {
    if (window.__vhgLvTimer) { clearInterval(window.__vhgLvTimer); window.__vhgLvTimer = null; }
    window.__vhgLvLog = ''; return { ok: true, msg: 'ปิดโหมดฟาร์มตามเลเวล' };
  },
  lvHuntLog: function () { var m = window.__vhgLvLog || ''; window.__vhgLvLog = ''; return m; },

  // ช่วยเมื่อ "ตัววิ่งเควสของเกม" ติดนิ่งในเฟส walk — สาเหตุที่เจอจริง: เป้าหมายอยู่คนละแมพ
  //   (เควส 2.7 = map 5 Mirewood แต่ตัวยืนใน map 2 แล้วเกมไม่พาข้ามแมพให้: to=null, fail=0, ไม่ขยับ)
  questNudge: function () {
    var S = window.S, a = S && S.aq;
    if (!a) return { ok: false, msg: 'ไม่ได้วิ่งเควสอยู่' };
    var p = (a.places && a.places[0]) || null;
    if (!p || p.length < 3) return { ok: false, msg: 'ไม่พบจุดหมายในเควส (places ว่าง)' };
    var tMap = p[0] | 0, tx = p[1], ty = p[2], cur = (S.info && S.info.map);
    if (tMap !== cur) {
      var net = window.__net, nm = (S.mapTh && S.mapTh[tMap]) || (S.mapEn && S.mapEn[tMap]) || ('map ' + tMap);
      var wps = (S.me && S.me.wps) || [];
      try {
        if (wps.indexOf(tMap) >= 0 && net && typeof net.wpGo === 'function') { net.wpGo(tMap); return { ok: true, warp: true, msg: 'วาร์ปข้ามแมพไป ' + nm + ' ให้เควส (เกมเดินข้ามเองไม่ได้)' }; }
        if (net && typeof net.travel === 'function') { net.travel(tMap); return { ok: true, warp: true, msg: 'เดินทางข้ามแมพไป ' + nm + ' ให้เควส' }; }
        return { ok: false, msg: 'ข้ามแมพไม่ได้อีกแล้ว (ไม่พบระบบเดินทาง)' };
      } catch (e) { return { ok: false, msg: 'warp fail: ' + (e.message || e) }; }
    }
    try { if (typeof window.__walk === 'function') { window.__walk(tx, ty); return { ok: true, msg: 'เดินไปจุดเควสเอง (' + tx + ',' + ty + ')' }; } } catch (e) {}
    return { ok: false, msg: 'ไม่มีระบบเดิน (__walk) ในหน้านี้' };
  },

  // กด "ต่อไป" ในกล่องบทพูดเควสให้เอง — ถ้าไม่มีใครกด ตัวละครจะยืนค้างหน้ากล่อง (เจอจริง: แกร์ริก 1/3)
  //   ค้นเฉพาะในกล่องที่เปิดอยู่ (#qsdlg / #npcmenu) และกดเฉพาะปุ่มไปต่อ ห้ามยกเลิก/ปฏิเสธ/ลบ/ขาย
  talkAdvance: function () {
    var vis = function (e) { return e && (e.offsetWidth || e.offsetHeight); };
    var boxes = ['qsdlg', 'npcmenu'].map(function (id) { return document.getElementById(id); }).filter(vis);
    if (!boxes.length) return { ok: false, msg: 'ไม่มีกล่องบทพูดเปิดอยู่' };
    var want = /^(ต่อไป|ไปต่อ|ตกลง|รับเควส|ส่งเควส|เสร็จสิ้น|เสร็จแล้ว|ใช่|ยอมรับ|คุยต่อ)/;
    var bad = /^(ยกเลิก|ปฏิเสธ|ปิด|ลบ|ขาย|ทิ้ง|ไม่)/;
    var clicked = null, seen = [];
    // เกมใช้ addEventListener บน <button> (onclick = null) และปุ่มจริงอยู่ใน <div class="qd-act"> อีกชั้น
    //   → ต้องเลือก tag ปุ่มก่อน ไม่ใช่ div แม่ ไม่งั้น click แล้วเงียบ (เจอจริง: กด "ต่อไป" 6 รอบบทพูดไม่ขยับ)
    var fire = function (el) {
      ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(function (tp) {
        try { el.dispatchEvent(new MouseEvent(tp, { bubbles: true, cancelable: true, view: window })); } catch (e) {}
      });
      try { el.click(); } catch (e) {}
    };
    var norm = function (e) { return String(e.textContent || '').trim().replace(/\s+/g, ' '); };
    var tries = ['button', '[role="button"]', '.btn', 'a', 'li', 'div', 'span'];
    for (var i = 0; i < boxes.length && !clicked; i++) {
      for (var s = 0; s < tries.length && !clicked; s++) {
        var bs = [].slice.call(boxes[i].querySelectorAll(tries[s]));
        for (var j = 0; j < bs.length; j++) {
          var e = bs[j]; if (!vis(e)) continue;
          var t = norm(e);
          if (!t || t.length > 24) continue;
          if (seen.indexOf(t) < 0) seen.push(t);
          if (want.test(t) && !bad.test(t)) { fire(e); clicked = t + ' <' + e.tagName.toLowerCase() + '.' + String(e.className).split(' ')[0] + '>'; break; }
        }
      }
    }
    // บทพูดหน้าสุดท้ายมักเหลือแต่ "ปิด" — ไม่มีปุ่มไปต่อ/รับ/เควสแล้ว ให้ปิดกล่องได้เลย (ไม่งั้นค้างบังทาง)
    if (!clicked) {
      var acts = [].slice.call(boxes[0].querySelectorAll('button,[role="button"],.btn,a')).filter(function (e) { return vis(e) && norm(e) && norm(e).length <= 24; });
      var onlyClose = acts.filter(function (e) { return /^(ปิด|X|✕)/i.test(norm(e)); });
      var otherAct = acts.filter(function (e) { return !/^(ปิด|X|✕)/i.test(norm(e)); });
      if (onlyClose.length && !otherAct.length) { fire(onlyClose[0]); clicked = norm(onlyClose[0]) + ' <ปิดกล่อง>'; }
    }
    return { ok: !!clicked, box: boxes[0].id, clicked: clicked, seen: seen.slice(0, 8), text: String(boxes[0].textContent || '').trim().replace(/\s+/g, ' ').slice(0, 70) };
  },

  // ---------- 🕓 ตารางเวลาเกิดบอสแยกตามชาแนล (หน้าต่าง #bosswin = ปุ่ม L) ----------
  //   ใช้ตอน "ไปถึงแล้วไม่เจอบอส" → ดูว่าชาแนลไหนบอสเกิด แล้วย้ายไป (แพ็กเก็ต chgo มีจริงใน log)
  bossSchedule: function () {
    var S = window.S, w = document.getElementById('bosswin');
    if (!S) return { ok: false, msg: 'ไม่มี window.S (ยังไม่เข้าเกม)' };
    if (!w || !(w.offsetWidth || w.offsetHeight)) return { ok: false, needOpen: true, msg: 'หน้าต่างเวลาเกิดบอสยังไม่เปิด (กด L)' };
    var rows = [];
    try {
      [].slice.call(w.querySelectorAll('.bw-row')).forEach(function (r) {
        var who = r.querySelector('.bw-who');
        var bEl = who ? who.querySelector('b') : null;
        var sEl = who ? who.querySelector('small') : null;
        var sTxt = sEl ? String(sEl.textContent || '') : '';
        var lvM = sTxt.match(/Lv\s*(\d+)/i);
        var chs = [];
        [].slice.call(r.querySelectorAll('.bw-ch')).forEach(function (c, i) {
          // โครงจริง: <span class="bw-ch up" data-ch="1"><b>CH 1</b><i>มีชีวิต</i></span>
          //   ต้องอ่านจาก <i> เท่านั้น — ถ้าใช้ textContent ทั้งเซลล์ "CH 1"+"1:24" จะติดกันแล้วคิดเวลาผิด
          var vEl = c.querySelector('i') || c.querySelector('span');
          var txt = String((vEl ? vEl.textContent : c.textContent) || '').replace(/\s+/g, ' ').trim();
          var mm = txt.match(/^(\d+)\s*:\s*(\d+)$/);
          var cls = String(c.className || '');
          chs.push({
            ch: (c.dataset && c.dataset.ch) ? +c.dataset.ch : (i + 1),
            up: /(^|\s)up(\s|$)/.test(cls) || /มีชีวิต/.test(txt),
            txt: txt.slice(0, 14),
            inSec: mm ? ((+mm[1]) * 60 + (+mm[2])) : null,
            cls: cls.replace('bw-ch', '').trim(),
          });
        });
        rows.push({
          map: (r.dataset && r.dataset.map != null && r.dataset.map !== '') ? +r.dataset.map : null,
          name: bEl ? String(bEl.textContent || '').trim() : '',
          boss: (sEl && sEl.querySelector('[translate="no"]')) ? String(sEl.querySelector('[translate="no"]').textContent || '').trim() : '',
          mlv: lvM ? +lvM[1] : null, chs: chs,
        });
      });
    } catch (e) { return { ok: false, msg: e.message }; }
    return { ok: true, rows: rows, curCh: (S.me && (S.me.ch != null ? S.me.ch : S.me.channel)) != null ? (S.me.ch != null ? S.me.ch : S.me.channel) : null };
  },
  // ย้ายชาแนล (แพ็กเก็ตจริงที่ยืนยันจาก log: {"t":"chgo","ch":6})
  chGo: function (ch) {
    var net = window.__net;
    if (!net || typeof net.raw !== 'function') return { ok: false, msg: 'ไม่พบ __net.raw' };
    var n = ch | 0; if (!(n >= 1 && n <= 12)) return { ok: false, msg: 'เลขชาแนลไม่ถูกต้อง: ' + ch };
    try { net.raw({ t: 'chgo', ch: n }); return { ok: true, ch: n, msg: 'ย้ายไปชาแนล ' + n }; } catch (e) { return { ok: false, msg: e.message }; }
  },

  // ---------- 🛡️ ตรวจความปลอดภัยก่อนเปิด UI (พรีเมียม/คลัง/ร้าน) ----------
  //   เกมจะยกเลิก interaction ถ้าถูกมอนตี/สะกิด → ต้องยืนว่างไม่มีมอนใกล้ (≤12 ช่อง)
  //   ในเมือง (map 0/2) = ปลอดภัยเสมอ (มีแค่หุ่นซ้อมที่ kind=monster แต่ชื่อ "หุ่น" → กรองทิ้ง)
  safeForUI: function () {
    var S = window.S; if (!S || !S.hero) return { ok: false, msg: 'ยังไม่เข้าเกม' };
    var map = String(S.info && S.info.map || '');
    if (map === '0' || map === '2') return { ok: true, town: true, msg: 'ในเมือง ปลอดภัย' };
    var h = S.hero;
    if (h.path && h.path.length) return { ok: false, msg: 'กำลังเดินอยู่ — รอให้หยุดก่อน' };
    var near = null, nd = 999;
    try { S.ents.forEach(function (e) {
      if (!e || e.kind !== 'monster' || e.dead > 0 || e.rx == null) return;
      if (/หุ่น|dummy|training/i.test(e.name || '')) return;
      var d = Math.hypot(e.rx - h.rx, e.ry - h.ry);
      if (d < nd) { nd = d; near = e; }
    }); } catch (e) {}
    if (near && nd <= 12) return { ok: false, msg: 'มีมอนใกล้: ' + (near.name || '?') + ' Lv' + (near.level || '?') + ' ห่าง ' + Math.round(nd) + ' ช่อง — ยังไม่เปิด UI' };
    return { ok: true, msg: 'ปลอดภัย (มอนใกล้สุด ' + (near ? Math.round(nd) : 'ไม่มี') + ' ช่อง)' };
  },

  // ---------- 📦 ทางลัดพรีเมียม: กดปุ่ม "ฝากทั้งหมด / ฝากเข้าแท็บพิเศษ" ของเกมเอง ----------
  //   ผู้ใช้ชี้ปุ่ม "Into special tabs" = .st-spcall ("ฝากเข้าแท็บพิเศษ") ในแผงคลัง #shop
  //   ซึ่งเปิดจาก #premwin → ปุ่ม "เปิดคลัง" (พรีเมียมฝากได้ทุกที่ ไม่ต้องเดินหาคาฟี)
  //   default ไม่กดปุ่มแท็บพิเศษ เพราะมันจะกวาดออร์บที่ต้องเหลือในกระเป๋า (keepOrbCount) ไปด้วย
  stashBulk: async function (opts) {
    var S = window.S; if (!S || !S.hero) return { ok: false, msg: 'ยังไม่ได้เข้าเกม' };
    var o = opts || {}, spcall = !!o.specialTabs;
    var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
    var vis = function (e) { return !!(e && (e.offsetWidth || e.offsetHeight)); };
    var click = function (e) { try { e.click(); return true; } catch (err) { return false; } };
    var bagUsed = function () { try { var c = 0, bf = (S.bagCfg && S.bagCfg.first) || 0; S.panels.inv.forEach(function (v, k) { if (v && v.id != null && k >= bf) c++; }); return c; } catch (e) { return -1; } };
    var before = bagUsed();
    var shop = document.getElementById('shop');
    if (!vis(shop)) {
      var pw = document.getElementById('premwin');
      if (!vis(pw)) {
        var pbtn = [].slice.call(document.querySelectorAll('button,[role="button"]')).filter(function (e) { return vis(e) && /พรีเมียม/.test(e.getAttribute('title') || ''); })[0];
        if (!pbtn) return { ok: false, msg: 'ไม่พบปุ่มพรีเมียมบน HUD (บัญชีนี้อาจยังไม่เป็นพรีเมียม)' };
        click(pbtn); await sleep(800); pw = document.getElementById('premwin');
      }
      var openBtn = pw ? [].slice.call(pw.querySelectorAll('button')).filter(function (e) { return vis(e) && /เปิดคลัง/.test(String(e.textContent || '')); })[0] : null;
      if (!openBtn) return { ok: false, msg: 'ไม่พบปุ่ม "เปิดคลัง" ในหน้าต่างพรีเมียม' };
      click(openBtn); await sleep(1200); shop = document.getElementById('shop');
    }
    if (!vis(shop)) return { ok: false, msg: 'เปิดแผงคลังไม่สำเร็จ' };
    var tabs = [].slice.call(shop.querySelectorAll('.st-tab')).filter(function (e) { return vis(e) && !/st-buy/.test(String(e.className)); });
    var did = [];
    for (var i = 0; i < tabs.length; i++) {
      click(tabs[i]); await sleep(450);
      var all = [].slice.call(shop.querySelectorAll('.st-all')).filter(vis)[0];
      if (all && click(all)) { did.push(String(tabs[i].textContent || '').trim().slice(0, 8)); await sleep(750); }
    }
    var spc = false;
    if (spcall) { var sp = [].slice.call(shop.querySelectorAll('.st-spcall')).filter(vis)[0]; if (sp) { click(sp); spc = true; await sleep(900); } }
    var xb = [].slice.call(shop.querySelectorAll('.x')).filter(vis)[0]; if (xb) click(xb);
    var after = bagUsed();
    return { ok: true, tabs: did.length, tabNames: did, special: spc, before: before, after: after,
      msg: 'ฝากทั้งหมด ' + did.length + ' แท็บ' + (spc ? ' + แท็บพิเศษ' : '') + ' (' + before + ' → ' + after + ' ช่อง)' };
  },

  // ---------- 📦 ฝากเฉพาะรายการเข้าแท็บพิเศษ VIP (ล็อกของอื่น → กด → ปลดล็อก) ----------
  //   opts = { items: ['หนังแข็ง','แร่เหล็ก',...] } — ฝากเฉพาะของที่ชื่อตรง, ของอื่นล็อกไว้ไม่ถูกกวาด
  stashVipList: async function (opts) {
    var S = window.S, net = window.__net;
    if (!S || !S.hero || !net) return { ok: false, msg: 'ยังไม่ได้เข้าเกม' };
    var items = (opts && opts.items) || [];
    if (!items.length) return { ok: true, msg: 'ไม่มีรายการที่ต้องฝาก (ช่องว่าง)', deposited: 0 };
    var bagFirst = (S.bagCfg && S.bagCfg.first) || 0;
    var sl = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
    var vis = function (e) { return !!(e && (e.offsetWidth || e.offsetHeight)); };
    var click = function (e) { try { e.click(); return true; } catch (err) { return false; } };
    var nmOf = function (id) { try { var d = S.items && S.items[id]; return (d && d.name && (d.name[1] || d.name[0])) || ''; } catch (e) { return ''; } };
    var matches = function (name) { for (var i = 0; i < items.length; i++) { if (name.indexOf(items[i]) >= 0) return true; } return false; };
    // 1) ล็อกของที่ไม่อยู่ในรายการ, ปลดล็อกที่อยู่ในรายการ (กัน "ฝากทั้งหมด" กวาดของที่ไม่ต้องการ)
    var locked = [], unlocked = [];
    try { S.panels.inv.forEach(function (v, k) {
      if (!v || v.id == null || k < bagFirst) return;
      var nm = nmOf(v.id);
      if (matches(nm)) { if (v.lk) { try { net.raw({ t: 'lk', s: k }); } catch (e) {} unlocked.push(nm); } }
      else { if (!v.lk) { try { net.raw({ t: 'lk', s: k }); } catch (e) {} locked.push(k); } }
    }); } catch (e) {}
    await sl(600);
    // 2) เปิดแผงคลังพรีเมียม → กด "ฝากเข้าแท็บพิเศษ"
    var shop = document.getElementById('shop');
    if (!vis(shop)) {
      var pw = document.getElementById('premwin');
      if (!vis(pw)) {
        var pbtn = [].slice.call(document.querySelectorAll('button,[role="button"]')).filter(function (e) { return vis(e) && /พรีเมียม/.test(e.getAttribute('title') || ''); })[0];
        if (!pbtn) { for (var u = 0; u < locked.length; u++) { try { net.raw({ t: 'lk', s: locked[u] }); } catch (e) {} } return { ok: false, msg: 'ไม่พบปุ่มพรีเมียม' }; }
        click(pbtn); await sl(800); pw = document.getElementById('premwin');
      }
      var openBtn = pw ? [].slice.call(pw.querySelectorAll('button')).filter(function (e) { return vis(e) && /เปิดคลัง/.test(String(e.textContent || '')); })[0] : null;
      if (!openBtn) { for (var u2 = 0; u2 < locked.length; u2++) { try { net.raw({ t: 'lk', s: locked[u2] }); } catch (e) {} } return { ok: false, msg: 'ไม่พบปุ่ม "เปิดคลัง"' }; }
      click(openBtn); await sl(1200); shop = document.getElementById('shop');
    }
    if (!vis(shop)) { for (var u3 = 0; u3 < locked.length; u3++) { try { net.raw({ t: 'lk', s: locked[u3] }); } catch (e) {} } return { ok: false, msg: 'เปิดแผงคลังไม่สำเร็จ' }; }
    var sp = [].slice.call(shop.querySelectorAll('.st-spcall')).filter(vis)[0];
    var before = 0, after = 0;
    try { S.panels.inv.forEach(function (v, k) { if (v && v.id != null && k >= bagFirst) before++; }); } catch (e) {}
    if (sp) { click(sp); await sl(1500); }
    else { var all = [].slice.call(shop.querySelectorAll('.st-all')).filter(vis); for (var ai = 0; ai < all.length; ai++) { click(all[ai]); await sl(600); } }
    try { S.panels.inv.forEach(function (v, k) { if (v && v.id != null && k >= bagFirst) after++; }); } catch (e) {}
    var xb = [].slice.call(shop.querySelectorAll('.x')).filter(vis)[0]; if (xb) click(xb);
    // 3) ปลดล็อกของทั้งหมด (คืนสภาพ)
    await sl(500);
    for (var u4 = 0; u4 < locked.length; u4++) { try { net.raw({ t: 'lk', s: locked[u4] }); } catch (e) {} }
    var dep = before - after;
    return { ok: true, deposited: dep, before: before, after: after, lockedCount: locked.length,
      msg: 'ฝากเข้าแท็บพิเศษ VIP: ' + dep + ' ชิ้น (ล็อกกันไว้ ' + locked.length + ' ช่อง → ฝาก → ปลดล็อก) (' + before + ' → ' + after + ')' };
  },

  // ---------- reconnect / login / character select ----------
  // DOM จริงของ Caelmora: login=#scr-login (#btn-login,#btn-guest,#google-btn,#acc,#pw)
  //                     char select=#char-select-screen (.char-slot > .char-slot-name, #btn-enter)
  probeReconnect: function () {
    var vis = function (el) { return el && !!(el.offsetWidth || el.offsetHeight); };
    var scr = document.getElementById('scr-login');
    var loginBtn = document.getElementById('btn-login');
    var guestBtn = document.getElementById('btn-guest');
    var googleBtn = document.getElementById('google-btn');
    var charScr = document.getElementById('char-select-screen');
    var enterBtn = document.getElementById('btn-enter');
    var loginVisible = vis(scr) && (vis(loginBtn) || vis(guestBtn) || vis(googleBtn));
    var charVisible = (vis(charScr) && vis(enterBtn)) || !!document.querySelector('.char-slot:not(.is-empty)');
    return { ss: !!loginVisible, cs: !!charVisible };
  },
  clickServer: function (opt) {
    var vis = function (el) { return el && !!(el.offsetWidth || el.offsetHeight); };
    opt = (typeof opt === 'object' && opt) ? opt : { guest: !!opt };
    var u = document.getElementById('acc');
    var p = document.getElementById('pw');
    if (!u || !p) return;
    // 1) ช่องว่าง + config มีบัญชี/รหัส → บอทกรอกเอง (ผู้ใช้ไม่ต้องพิมพ์อีก)
    if (!String(u.value).trim() && !String(p.value).trim() && opt.user && opt.pass) {
      u.value = opt.user; p.value = opt.pass;
      try { u.dispatchEvent(new Event('input', { bubbles: true })); p.dispatchEvent(new Event('input', { bubbles: true })); } catch (e) {}
      window.__vhgFilled = Date.now();
    }
    // 2) focus guard: ยกเว้นบอทกรอกเอง (<15 วิ) หรือค่าพิมพ์อยู่นิ่ง ≥5 วิ (พิมพ์จบแล้ว)
    var ae = document.activeElement;
    if (ae && (ae.id === 'acc' || ae.id === 'pw' || ae.id === 'pw2')) {
      var selfFill = window.__vhgFilled && Date.now() - window.__vhgFilled < 15000;
      if (!selfFill) {
        var key = String(u.value) + '|' + String(p.value);
        var seen = window.__vhgTyping;
        if (!seen || seen.k !== key) { window.__vhgTyping = { k: key, t: Date.now() }; return; }
        if (Date.now() - seen.t < 5000) return;
      }
    }
    // 3) เกมกำลังขึ้นข้อความจำกัดเวลา/รหัสผิดบ่อย → อย่ากดซ้ำ
    var st = document.getElementById('login-status');
    if (st && /นาที|ลองใหม่|ผิดหลายครั้ง|รอ/.test(st.textContent || '')) return;
    if (opt.guest) {
      var g = document.getElementById('btn-guest');
      if (vis(g) && !g.disabled) { try { g.click(); return; } catch (e) {} }
    }
    if (String(u.value).trim() && String(p.value).trim()) {
      var b = document.getElementById('btn-login');
      if (vis(b) && !b.disabled) { try { b.click(); return; } catch (e) {} }
    }
    // 4) ไม่มี credential ใน config → ลองปุ่ม Google (cooldown 45s)
    var gb = document.getElementById('google-btn');
    if (vis(gb) && !gb.disabled && !opt.user) {
      var now = Date.now();
      if (!window.__vhgLastGoogle || now - window.__vhgLastGoogle > 45000) {
        window.__vhgLastGoogle = now;
        try { gb.click(); return; } catch (e) {}
      }
    }
  },
  enterCharacter: function (wantName) {
    var slots = [].slice.call(document.querySelectorAll('.char-slot')).filter(function (el) { return !el.classList.contains('is-empty'); });
    if (!slots.length) return;
    var pick = null;
    if (wantName) {
      pick = slots.filter(function (el) {
        var n = el.querySelector('.char-slot-name');
        return n && n.textContent.trim() === wantName;
      })[0] || slots.filter(function (el) {
        var n = el.querySelector('.char-slot-name');
        return n && n.textContent.indexOf(wantName) >= 0;
      })[0];
    } else {
      pick = slots.filter(function (el) { return el.classList.contains('is-selected'); })[0] || slots[0];
    }
    if (!pick) return;
    try { pick.click(); } catch (e) {}
    // กด "Enter game" หลังเลือกช่อง (dblsel ของเกมใช้ is-selected; ปุ่ม #btn-enter)
    var b = document.getElementById('btn-enter');
    if (b && !b.disabled) { try { b.click(); } catch (e) {} }
  },

  // ---------- สถานะเดินทาง ----------
  probeTravel: function () {
    var S = window.S; if (!S) return null;
    var moving = !!(S.hero && S.hero.path && S.hero.path.length);
    var nm = null;
    try { var mid = S.info && S.info.map; nm = mid != null && ((S.mapTh && S.mapTh[mid]) || (S.mapEn && S.mapEn[mid])) || null; } catch (e) {}
    return { on: moving, note: moving ? ('กำลังเดิน → ' + (nm || S.info && S.info.map || '')) : '' };
  },

  // ---------- ลิสต์แมพสำหรับ dropdown (อ่านสดจากเกม: mapEn+mapArea+mapTh) ----------
  listMaps: function (towns) {
    var S = window.S; if (!S || !S.mapEn) return [];
    var skip = {}; var i; for (i = 0; i < (towns || []).length; i++) skip[String(towns[i])] = 1;
    var out = [];
    for (var k in S.mapEn) {
      if (skip[String(k)]) continue;
      var en = S.mapEn[k] || ('map ' + k);
      var th = (S.mapTh && S.mapTh[k]) || null;
      var lv = (S.mapArea && S.mapArea[k] != null) ? S.mapArea[k] : 0;
      var low = en.toLowerCase();
      out.push({
        id: String(k), name: th || en, en: en,
        lv: lv, lvText: 'Lv ' + lv,
        dungeon: /lair|cave|deep|dungeon|crypt|tomb|nest|rift|tower/i.test(low),
        boss: /boss|ราชา|จ้าว/i.test(low + ' ' + (th || '')),
      });
    }
    out.sort(function (a, b) { return a.lv - b.lv; });
    return out;
  },
  warpPanel: function () {
    var S = window.S; if (!S || !S.info || !S.mapEn) return null;
    var towns = { '0': 1, '2': 1 };
    var visited = [];
    try { visited = ((S.me && S.me.wps) || []).map(String); } catch (e) {}
    var maps = [];
    for (var k in S.mapEn) {
      if (towns[String(k)]) continue;
      var en = S.mapEn[k] || ('map ' + k);
      var th = (S.mapTh && S.mapTh[k]) || null;
      var lv = (S.mapArea && S.mapArea[k] != null) ? S.mapArea[k] : 0;
      var low = en.toLowerCase();
      maps.push({ id: String(k), name: th || en, en: en, lv: lv, lvText: 'Lv ' + lv,
        dungeon: /lair|cave|deep|dungeon|crypt|tomb|nest|rift|tower/i.test(low),
        boss: /boss|ราชา|จ้าว/i.test(low + ' ' + (th || '')) });
    }
    maps.sort(function (a, b) { return a.lv - b.lv; });
    var coins = null; try { coins = (S.me && S.me.zen != null) ? S.me.zen : (S.panels && S.panels.zen); } catch (e) {}
    return { mapId: S.info.map != null ? String(S.info.map) : null, coins: coins, visited: visited, maps: maps, towns: ['0', '2'] };
  },

  // ================= 🚢 VOYAGE — โต๊ะนำร่อง (protocol จาก packet capture จริง) =================
  // สมุด: item id 14848+ (tier = id-14847) | ออร์บ: 11778 ปลุกพลัง, 11779 เสริมพลัง, 11781 เลื่อนขั้น
  // คำสั่ง: {t:'voy',op:'buy',tier} / {op:'trade',tier} / {op:'sail',s:ช่องสมุด,node:เกาะ} / {op:'leave'}
  //         {t:'cur',s:ช่องออร์b,to:ช่องสมุด} = ใช้ออร์บ · talk id 30021 = เซเรน ต้นหนเรือเหาะ (ต้องยืนใกล้)
  // ---------- เดินไปใกล้โต๊ะนำร่องเอง (findPath + move) ----------
  // entity จริง (probe ยืนยัน): kind:'npc', name:'โต๊ะนำร่อง' (ไทย), key ~30020/30021 ต่างกันตามเมือง
  voyNearTable: function () {
    var S = window.S; if (!S || !S.hero) return { ok: false, msg: 'ยังไม่ได้เข้าเกม' };
    var h = S.hero;
    var t = null, tKey = null;
    try {
      S.ents.forEach(function (e, k) {
        if (t) return;
        if (e && e.kind === 'npc' && (e.art === 1025 || /โต๊ะนำร่อง|seren|เซเรน|navigator/i.test(e.name || ''))) { t = e; tKey = k; }
      });
    } catch (e) {}
    if (!t) { try { t = S.ents.get(30021); if (t) tKey = 30021; } catch (e) {} }
    if (!t) {
      // entity ยังไม่ stream เข้า (อยู่ไกล) — ถ้ารู้จักพิกัดโต๊ะของแมพนี้ เดินเข้าไปก่อน
      var FP = { 2: { x: 138, y: 130 }, 0: { x: 138, y: 130 } }[(S.info && S.info.map) || 0];
      if (FP) {
        if (h.path && h.path.length) return { ok: true, dist: 999, moved: true, still: false, msg: 'กำลังเดินไปจุดโต๊ะนำร่อง...' };
        try {
          if (typeof window.__walk === 'function') { window.__walk(FP.x - 2, FP.y + 1); return { ok: true, dist: 999, moved: true, still: false, msg: 'กำลังเดินไปจุดโต๊ะนำร่อง' }; }
        } catch (e) {}
      }
      return { ok: false, msg: 'ไม่พบโต๊ะนำร่องในแมพนี้ (map ' + (S.info && S.info.map) + ') — ต้องอยู่เมือง Solhaven/Caelmora' };
    }
    window.__vhgTable = { key: tKey, x: t.rx, y: t.ry };
    var dist = Math.sqrt((h.rx - t.rx) * (h.rx - t.rx) + (h.ry - t.ry) * (h.ry - t.ry));
    var still = !(h.path && h.path.length);
    if (dist <= 8) return { ok: true, dist: Math.round(dist), moved: false, still: still, key: tKey };
    if (!still) return { ok: true, dist: Math.round(dist), moved: true, still: false, key: tKey, msg: 'กำลังเดิน...' };
    try {
      if (typeof window.__walk === 'function') { window.__walk(Math.round(t.rx) - 2, Math.round(t.ry) + 1); return { ok: true, dist: Math.round(dist), moved: true, still: false, key: tKey, msg: 'กำลังเดินไปโต๊ะนำร่อง (' + Math.round(dist) + ' ช่อง)' }; }
      var path = S.grid.findPath(h.rx, h.ry, t.rx - 2, t.ry + 1);
      if (!path || !path.length) return { ok: false, msg: 'หาทางเดินไปโต๊ะไม่เจอ (dist ' + Math.round(dist) + ')' };
      window.__net.move(path);
      return { ok: true, dist: Math.round(dist), moved: true, still: false, key: tKey, msg: 'กำลังเดินไปโต๊ะนำร่อง (' + Math.round(dist) + ' ช่อง)' };
    } catch (e) { return { ok: false, msg: 'walk fail: ' + e.message }; }
  },

  // ค้นหาไอเทมจากชื่อ (ใช้ตรวจว่าชื่อที่ผู้ใช้พิมพ์ใน "ไอเทมเพิ่มเติม" มีอยู่จริงไหม)
  // หาแบบ substring ก่อน ถ้าไม่เจอค่อยลองแบบ "ตัวอักษรเรียงตามลำดับ" (พิมพ์ตกบางพยางค์ยังเจอ)
  findItems: function (query) {
    var S = window.S; if (!S || !S.items) return { matches: [], error: 'ยังไม่ได้เข้าเกม' };
    var q = String(query || '').trim();
    if (!q) return { matches: [] };
    function norm(s) { return String(s || '').replace(/\s+/g, ''); }
    function subseq(needle, hay) {
      var i = 0;
      for (var j = 0; j < hay.length && i < needle.length; j++) if (hay[j] === needle[i]) i++;
      return i === needle.length;
    }
    var exact = [], loose = [];
    var nq = norm(q);
    Object.keys(S.items).forEach(function (k) {
      var d = S.items[k]; if (!d || !d.name) return;
      var th = d.name[1] || '', en = d.name[0] || '';
      var rec = { id: d.id != null ? d.id : +k, th: th, en: en, cat: d.cat };
      if (th.indexOf(q) >= 0 || en.toLowerCase().indexOf(q.toLowerCase()) >= 0) { if (exact.length < 12) exact.push(rec); }
      else if (nq.length >= 3 && (subseq(nq, norm(th)) || subseq(nq, norm(en)))) { if (loose.length < 8) loose.push(rec); }
    });
    return { matches: exact, suggest: exact.length ? [] : loose, query: q, found: exact.length };
  },


  // อ่านรายการฟิลเตอร์ที่ผู้เล่นเซฟไว้ในเกม (localStorage cv.wiki.filters)
  listGameFilters: function () {
    try {
      var raw = localStorage.getItem('cv.wiki.filters');
      if (!raw) return { filters: [] };
      var o = JSON.parse(raw);
      var list = (o.filters || []).map(function (f) { return { id: f.id, name: f.name || '(ไม่มีชื่อ)', rules: f.rules || [] }; });
      return { filters: list };
    } catch (e) { return { filters: [], error: e.message }; }
  },

  voyagePanel: function () {
    var S = window.S; if (!S || !S.far) return null;
    var f = S.far, ui = S.voyUi, run = ui && ui.run, m = ui && ui.m;
    var isles = [];
    for (var k in (f.isles || {})) {
      var i0 = f.isles[k];
      isles.push({ node: i0.src || +k, map: i0.map, name: (i0.name && (i0.name[1] || i0.name[0])) || k, en: i0.name && i0.name[0], land: i0.land, boss: i0.bossTh || i0.bossName || '', el: i0.el || 0 });
    }
    isles.sort(function (a, b) { return a.node - b.node; });
    var charts = [], orbSlots = { awaken: [], kindling: [], ascension: [] };
    var OB = { 11778: 'awaken', 11779: 'kindling', 11781: 'ascension' };
    var bFirst = (S.bagCfg && S.bagCfg.first) || 0;
    try {
      if (S.panels && S.panels.inv && S.panels.inv.forEach) S.panels.inv.forEach(function (v, slot) {
        if (!v || v.id == null || slot < bFirst) return;   // ข้ามช่องของสวมใส่
        if (v.id >= 14848 && v.id <= 14900) charts.push({ slot: slot, tier: v.id - 14847, n: v.dur || v.n || 1, r: (v.rar | 0) });
        else if (OB[v.id]) orbSlots[OB[v.id]].push({ slot: slot, n: v.dur || 1 });
      });
    } catch (e) {}
    var zen = null; try { zen = S.me && S.me.zen; } catch (e) {}
    var bagUsed = 0, bagCap = 0;
    try {
      S.panels.inv.forEach(function (v, k) { if (v && v.id != null && k >= bFirst) bagUsed++; });   // ไม่นับช่องของสวมใส่
      var bc = S.bagCfg; if (bc && bc.cols && bc.rows) bagCap = bc.cols * bc.rows * (bc.pages || 1);
    } catch (e) {}
    var orbCount = function (arr) { var t = 0; for (var i = 0; i < arr.length; i++) t += arr[i].n || 1; return t; };
    return {
      map: S.info && S.info.map, onIsle: !!run,
      bag: { used: bagUsed, cap: bagCap, pct: bagCap ? Math.round(bagUsed / bagCap * 100) : 0 },
      run: run ? { node: run.node, tier: run.tier, left: run.left, rev: run.rev, revs: run.revs, boss: run.boss, lv: run.lv } : null,
      tableOpen: !!m, zen: zen, isles: isles, charts: charts,
      // ⚠️ ลิสต์ "ที่เซิร์ฟเห็น" (S.voyUi.m.charts) — ของที่ซื้อมาแล้วแต่ S.panels.inv ฝั่ง client ยังไม่ซิงค์
      //    จะโผล่ที่นี่ก่อน (เจอจริง 15:26: ซื้อสมุดแล้ว but inv ว่าง → บอทเข้าใจผิดว่าเซิร์ฟไม่ตอบ แล้วหยุดวงวนทั้งที่ลงเรือได้)
      //    แต่ลิสต์นี้ "ค้าง" ได้: วัดสด 17:0x เซิร์ฟยังบอกว่าช่อง 133 = สมุดอันดับ 1 ทั้งที่ช่องนั้นกลายเป็นไอเทม 20493 แล้ว
      //    → confirmed=false เฉพาะ "ช่องมีของแต่ไม่ใช่สมุด" (phantom จริง เช่น 20493)
      //    ถ้าช่องว่าง/undefined = ยังไม่ซิงค์ → confirmed=true (สมุดจริง แค่ client ยังไม่ sync)
      srvCharts: (m && m.charts) ? m.charts.map(function (c) {
        var it = null; try { it = S.panels.inv.get(c.s); } catch (e) {}
        var isPhantom = !!(it && it.id != null && (it.id < 14848 || it.id > 14900));
        return { s: c.s, tier: (it && it.id >= 14848 && it.id <= 14900) ? (it.id - 14847) : (c.tier | 0), r: (c.r | 0), n: c.n | 0, confirmed: !isPhantom };
      }) : [],
      inParty: !!(S.party && S.party.P), // วัดจริง: อยู่คนเดียว = S.party.P เป็น null
      orbs: { awaken: orbCount(orbSlots.awaken), kindling: orbCount(orbSlots.kindling), ascension: orbCount(orbSlots.ascension) },
      prices: f.prices || [], buy: f.buy || 1, trade: f.trade || 3, cap: f.cap,
      buyCdMs: f.limitMs || 0, // ค่าจากเกม S.far.limitMs = 3,600,000 (ยังไม่ได้พิสูจน์ว่าเป็นคูลดาวน์ "ซื้อ" จริงหรือแค่ window ของระบบอื่น — ใช้เป็นช่วงห่างขั้นต่ำระหว่างคำสั่งซื้อ)
    };
  },

  // ---------- ️ ROAM ต่อเนื่องในหน้าเกม: interval 1.5 วิ (node แค่ kick-start + เก็บ log) ----------
  // opts = { filter, mode:'hunt'|'boss', bagPct, minZen, lootSec }
  voyRoamStart: function (opts) {
    var S = window.S; if (!S) return { ok: false, msg: '' };
    window.__vhgRoamOpts = opts || {};
    // ---- เครื่องมือกฎกรองของ (ไฟล์ lootfilter.js ส่งมาทาง opts.lfSrc) — โหลดก่อน early return เพื่อให้เห็นค่าที่แก้ระหว่างทริป ----
    if (opts && opts.lfSrc && window.__vhgLFsrc !== opts.lfSrc) {
      try {
        window.__vhgLF = new Function(opts.lfSrc + '\nreturn { groupOf: groupOf, decodeCmf: decodeCmf, decide: decide, unknownKeys: unknownKeys };')();
        window.__vhgLFsrc = opts.lfSrc;
      } catch (e) { window.__vhgLF = null; }
    }
    if (window.__vhgRoamTimer) {
      var lg0 = window.__vhgRoamLog || ''; window.__vhgRoamLog = '';
      return { ok: true, msg: lg0, already: true };
    }
    // ----กติกา loot (ใช้ lootfilter.js เป็นตัวเดียวกันทั้ง node และในหน้าเกม) ----
    window.__vhgLootGroupOf = function (def) {
      if (window.__vhgLF && window.__vhgLF.groupOf) return window.__vhgLF.groupOf(def);
      var ae = def && def.cat;
      if (!ae) return 'other';
      if (ae === 'weapon' || ae === 'offhand' || ae === 'flask' || ae === 'charm' || ae === 'uncut' || ae === 'rune') return ae;
      if (ae === 'helmet' || ae === 'body' || ae === 'gloves' || ae === 'boots') return 'armour';
      if (ae === 'ring' || ae === 'amulet' || ae === 'belt') return 'jewel';
      if (ae === 'jewel') return 'tjewel';
      if (ae === 'card') return 'card';
      if (ae === 'sigil' || ae === 'chart' || ae === 'slate' || ae === 'dgkey' || ae === 'dgsigil') return 'key';
      if (ae === 'augury' || def.imprint || def.glass || def.key === 'SGS' || def.key === 'SG' || def.key === 'IMP') return 'wonder';
      if (ae === 'currency') { var kk = def.key || ''; if (/^SHARD/.test(kk)) return 'shard'; if (/^(HONE|RIVET|RESIN|CHISEL\d|AWL|FILING_AWL|INSIGHT)$/.test(kk)) return 'mat'; return 'orb'; }
      return 'other';
    };
    // --- จับ "ชื่อไอเทมเพิ่มเติมที่ผู้ใช้พิมพ์" (ช่อง ชื่อไอเทมเพิ่มเติมที่เก็บ) ---
    //   แยกเป็นฟังก์ชันต่างหาก เพราะโหมดพุ่งบอสต้องใช้ตัดสินใจ "แวะเก็บเฉพาะของชื่อนี้"
    //   โดยไม่สนใจกฎกรองชนิดอื่น (สมุดนำร่อง / บัตรเชิญลานอสูร ต้องได้แม้กำลังวิ่งไปบอส)
    window.__vhgWantsExtra = function (e) {
      var flt = (window.__vhgRoamOpts || {}).filter || {};
      var SS = window.S, item = (e && e.item) || {};
      var ex = flt.extra;
      if (!ex) return false;
      if (typeof ex === 'string') ex = ex.split(',');
      if (!ex.length) return false;
      var def0 = (item.id != null && SS.items && SS.items[item.id]) || null;
      var nm0 = (e && e.name) || (def0 && (def0.th || (def0.name && (def0.name[1] || def0.name[0])))) || '';
      var nmSq = String(nm0).replace(/\s+/g, '');
      var isSq = function (needle, hay) { var i = 0; for (var j = 0; j < hay.length && i < needle.length; j++) { if (hay[j] === needle[i]) i++; } return i === needle.length; };
      for (var xi = 0; xi < ex.length; xi++) {
        var xq = String(ex[xi] || '').trim();
        if (!xq) continue;
        if (nm0.indexOf(xq) >= 0) return true;
        // พิมพ์ตกบางพยางค์ (เช่น "บัตรเชิญอสูร" แทน "บัตรเชิญลานอสูร") → ยังเก็บให้
        if (xq.length >= 4 && isSq(xq.replace(/\s+/g, ''), nmSq)) return true;
      }
      return false;
    };
    window.__vhgWants = function (e) {
      var flt = (window.__vhgRoamOpts || {}).filter || { mode: 'game' };
      var SS = window.S, item = e.item || {};
      var defOf = function (id) { return (id != null && SS.items && SS.items[id]) || null; };
      var nameOf = function (ent) {
        var d = defOf(ent.item && ent.item.id);
        return ent.name || (d && (d.th || (d.name && (d.name[1] || d.name[0])))) || '';
      };
      // --- cap: ของชื่อตรงรายการ จำกัดจำนวน ถือครบแล้วไม่เก็บเพิ่ม (เช็คก่อนทุกอย่าง) ---
      var cap = flt.cap;
      if (cap && cap.items && cap.items.length) {
        var nmC = nameOf(e);
        for (var ck = 0; ck < cap.items.length; ck++) {
          var cq = String(cap.items[ck] || '').trim();
          if (cq && nmC.indexOf(cq) >= 0) {
            var C = window.__vhgCapCache;
            if (!C || Date.now() - C.t > 2000) {
              C = window.__vhgCapCache = { t: Date.now(), m: {} };
              try {
                SS.panels.inv.forEach(function (v) {
                  if (!v || v.id == null) return;
                  var dn = nameOf({ name: '', item: v });
                  for (var q = 0; q < cap.items.length; q++) {
                    var qq = String(cap.items[q] || '').trim();
                    if (qq && dn.indexOf(qq) >= 0) C.m[qq] = (C.m[qq] || 0) + (v.dur || v.n || 1);
                  }
                });
              } catch (err) {}
            }
            if ((C.m[cq] || 0) >= (cap.max || 20)) return false;
            break;
          }
        }
      }
      // ชื่อไอเทมเพิ่มเติมที่ผู้ใช้พิมพ์ (คั่นด้วย , ) — เจอเป็นเก็บ ไม่ว่าโหมดไหน
      if (window.__vhgWantsExtra(e)) return true;
      if (flt.mode === 'all') return true;
      if (flt.mode === 'off') return false;
      // ---- โหมด "กฎ" = ใช้กฎกรองแบบเดียวกับในเกม (blacklist: ค่าเริ่มต้นเก็บ, กฎ hide/pick:false = ห้ามเก็บ) ----
      if (flt.mode === 'rules') {
        var LF = window.__vhgLF;
        if (!LF || !flt.rules || !flt.rules.length) return true; // ยังไม่มีกฎ = เก็บหมด ไม่ทำเงียบ
        var defR = (SS.items && item.id != null && SS.items[item.id]) || null;
        var ctx = { id: item.id, grp: LF.groupOf(defR), cat: defR && defR.cat, rar: Math.max(0, Math.min(3, item.rar | 0)), sock: item.sock | 0, il: item.il || 0, name: nameOf(e) };
        try { return !!LF.decide(flt.rules, ctx).keep; } catch (err) { return true; }
      }
      if (flt.mode === 'game') { try { return !!window.__botWants(e); } catch (err) { return true; } }
      var def = (SS.items && item.id != null && SS.items[item.id]) || null;
      var grp = window.__vhgLootGroupOf(def);
      var GEAR4 = ['weapon', 'offhand', 'armour', 'jewel'];
      var pk = flt.pk || {}, at = flt.at || [false, false, false];
      if (GEAR4.indexOf(grp) >= 0) {
        if (Array.isArray(at) && (at[0] || at[1] || at[2])) {
          var req = (def && def.req) || [];
          for (var i = 0; i < 3; i++) { if (req[i] > 0 && !at[i]) return false; }
        }
        var rar = Math.max(0, Math.min(3, item.rar || 0));
        return !!pk['r' + rar] || (!!pk.sock && (item.sock || 0) > 0);
      }
      if (grp === 'orb') return !!pk.orb && !(pk.orbOff && pk.orbOff.indexOf(item.id) >= 0);
      if (grp === 'tjewel') return pk.tjewel !== false;
      if (grp === 'other') return true;
      return !!pk[grp];
    };
    // ---------- 🧹 tick โหมด "ฟาร์ม map ปกติ" (ไม่มี trip ของเกม) ----------
    //   ผู้ใช้เลือก map เองจากแดชบอร์ด แล้วเลือกโหมด:
    //     'hunt' = กวาดทั้งแมพ (ตารางจุดทุกช่องที่เดินได้) + เก็บของ + ตีมอนใกล้ตัว "ไม่จำกัดเลเวล" (ตามคำสั่งผู้ใช้)
    //     'boss' = ไล่หา/ล็อกบอสของแมพ (ent.boss) → ตายแล้วเก็บของ lootSec วิ → กวาดรอบรอเกิดใหม่ (node อ่านเวลาเกิดจากตาราง L)
    //   ใช้ตัวตั้งค่าร่วมกับโหมดเกาะ (กฎกรองของ __vhgWants + __vhgRoamLog) จึงไม่ต้องคัดลอกตรรกะกรองของซ้ำ
    window.__vhgFieldTick = function () {
      try {
        var S = window.S; if (!S || !S.hero) return;
        var h = S.hero, opts = window.__vhgRoamOpts || {}, wants = window.__vhgWants;
        var mapId = (S.info && S.info.map);
        var log = function (m) { if (m && m !== window.__vhgRoamLog) { window.__vhgRoamLog = m; window.__vhgRoamLogAt = Date.now(); } };
        // อยู่ในเมือง = ไม่มีมอนให้ตี → จบรอบ (ให้ node พาไปฝากของ/ขาย แล้วค่อยกลับมา)
        var towns = ((opts.towns && opts.towns.length) ? opts.towns : ['0', '2']).map(String);
        if (towns.indexOf(String(mapId)) >= 0) { window.__vhgFieldDone = 'town'; log('🏙 ถึงเมืองแล้ว — จบโหมดฟาร์มmap'); return; }
        if (S.dead || h.dead > 0) return;
        // ---- 📥 ของเข้ากระเป๋า: เทียบ snapshot (ชื่อ+จำนวน) เหมือนโหมดเกาะ ผู้ใช้ขอระดับชื่อไอเทม ไม่ใช่ตัวเลขรวม ----
        try {
          var bagFirst = (S.bagCfg && S.bagCfg.first) || 0, snap = {};
          S.panels.inv.forEach(function (v, k) { if (v && v.id != null && k >= bagFirst) snap[v.id] = (snap[v.id] || 0) + (v.dur || 1); });
          var prevSnap = window.__vhgBagSnap; window.__vhgBagSnap = snap;
          if (!Array.isArray(window.__vhgEvts)) window.__vhgEvts = [];
          if (prevSnap) {
            var nmOf = function (id) { var d = S.items && S.items[id]; return (d && d.name && (d.name[1] || d.name[0])) || ('ไอเทม #' + id); };
            var noLog = function (id) { var d = S.items && S.items[id]; var c = (d && d.cat ? String(d.cat) : '').toLowerCase(); return c === 'flask' || c === 'charm'; };
            var ids = {}; Object.keys(prevSnap).forEach(function (k) { ids[k] = 1; }); Object.keys(snap).forEach(function (k) { ids[k] = 1; });
            Object.keys(ids).forEach(function (k) {
              var dd = (snap[k] || 0) - (prevSnap[k] || 0);
              if (dd > 0 && !noLog(+k)) window.__vhgEvts.push('📥 เข้ากระเป๋า: ' + nmOf(+k) + ' ×' + dd);
            });
            if (window.__vhgEvts.length > 60) window.__vhgEvts.splice(0, window.__vhgEvts.length - 60);
          }
        } catch (e) {}
        // ---- กระเป๋าเต็ม → จบรอบส่งสัญญาณให้ node พาไปฝาก ----
        var used = 0, capn = 120;
        try {
          var bf0 = (S.bagCfg && S.bagCfg.first) || 0;
          S.panels.inv.forEach(function (v, k) { if (v && v.id != null && k >= bf0) used++; });
          var bc = S.bagCfg; if (bc && bc.cols && bc.rows) capn = bc.cols * bc.rows * (bc.pages || 1);
        } catch (e) {}
        var pct = capn ? used / capn * 100 : 0;
        if (opts.bagPct && pct >= opts.bagPct) { window.__vhgFieldDone = 'bag'; log('📦 กระเป๋าเต็ม ' + Math.round(pct) + '% (' + used + '/' + capn + ' ช่อง) → จบรอบไปฝากของ'); return; }
        // ---- สร้างเส้นทางกวาดทั้งแมพ (ตารางจุดที่เดินได้) ----
        var F = window.__vhgField;
        if (!F || F.map !== mapId) {
          F = window.__vhgField = { map: mapId, pts: [], i: 0, bossEngaged: false, bossKilled: false, cycles: 0, bossPos: null, lootBy: 0, lootStart: 0, lootSkip: {}, stuckK: null, stuckT: 0, alivePrev: null, progAt: Date.now(), blkN: 0, orbAng: 0, lastBHp: null, lastBDt: 0, dexCount: {}, seen: {} };
          var gw = 0, gh = 0; try { gw = S.grid.w || S.grid.width || 0; gh = S.grid.h || S.grid.height || 0; } catch (e) {}
          if (!(gw > 40 && gh > 40)) { gw = 256; gh = 256; } // แมพใหญ่กว่านั้นก็ยังกวาดต่อ (pts วนซ้ำ) ไม่พัง
          for (var y = 20; y <= gh - 20; y += 45) for (var x = 20; x <= gw - 20; x += 45) { try { if (S.grid.walkable(x, y)) F.pts.push([x, y]); } catch (e) {} }
          if (!F.pts.length) { for (var y2 = 25; y2 <= 235; y2 += 45) for (var x2 = 25; x2 <= 235; x2 += 45) F.pts.push([x2, y2]); }
          F.pts.sort(function (a, b2) { return (Math.abs(a[0] - h.rx) + Math.abs(a[1] - h.ry)) - (Math.abs(b2[0] - h.rx) + Math.abs(b2[1] - h.ry)); });
          log('🧹 เริ่มฟาร์ม map ' + mapId + ' — ' + F.pts.length + ' จุดกวาด · โหมด ' + (opts.mode === 'boss' ? 'เน้นฆ่าบอส' : 'ฟาร์มทั้งแมพ (ไม่จำกัดเลเวล)'));
        }
        var dist2 = function (x, y) { return Math.hypot(h.rx - x, h.ry - y); };
        var moveTo = function (tx, ty) { try { if (typeof window.__walk === 'function') { window.__walk(Math.round(tx), Math.round(ty)); return true; } } catch (e) {} return false; };
        var setAuto = function (on) { try { if (typeof window.__bot === 'function') window.__bot(!!on); if (on && S.bot) S.bot.home = [Math.round(h.rx), Math.round(h.ry)]; } catch (e) {} };
        var pickItem = function (e, k) { try { window.__net.raw({ t: 'pick', id: k }); } catch (err) {} };
        // ---- 📕 โควตาสมุดมอนสเตอร์: รายชื่อที่ตั้งเป้าไว้ (รองรับทั้ง ["ชื่อ"] และ [{name,target}]) ----
        var dnames = (opts.dexNames || []).map(function (x) { return String(x && x.name ? x.name : x); }).filter(Boolean);
        var dmon = null, dmk = null, dmd = 999;
        var matchDex = function (nm) {
          for (var i = 0; i < dnames.length; i++) { if (nm.indexOf(dnames[i]) >= 0 || dnames[i].indexOf(nm) >= 0) return dnames[i]; }
          return null;
        };
        // ---- สแกนเอนทิตี้จริงในแมพ (บอส / มอนใกล้สุด / มอนตรงโควตา / ของที่กฎกรองอยากได้) ----
        var boss = null, bk = null, bd = 999, mon = null, mk = null, md = 999, loot = null, lk = null, ld = 999;
        try {
          S.ents.forEach(function (e, k) {
            if (!e || e.rx == null) return;
            if (e.kind === 'monster') {
              if (e.dead > 0) return;
              var d = dist2(e.rx, e.ry);
              if (dnames.length && !e.boss) {
                var dn = matchDex(String(e.name || ''));
                if (dn && d < dmd) { dmd = d; dmon = e; dmk = k; }
              }
              if (e.boss) { if (d < bd) { bd = d; boss = e; bk = k; } }
              else if (d < md) { md = d; mon = e; mk = k; }
              return;
            }
            if (e.kind === 'item') {
              if (F.lootSkip && F.lootSkip[k] > Date.now()) return;
              try { if (!wants || wants(e)) { var d2 = dist2(e.rx, e.ry); if (d2 < ld) { ld = d2; loot = e; lk = k; } } } catch (err) {}
            }
          });
        } catch (e) {}
        // นับยอดฆ่าสะสม: เทียบ "จำนวนเอนทิตี้ต่อชื่อ" กับ tick ก่อน (ตัวเลขลดลง = มีตัวตาย)
        //   เป็นตัวเลขคร่าว ๆ ฝั่ง node จะซิงค์กับสมุดมอนสเตอร์จริงเป็นระยะ
        try {
          var nowSeen = {};
          S.ents.forEach(function (e) {
            if (!e || e.kind !== 'monster' || e.dead > 0 || e.rx == null) return;
            var key = String(e.name || '?');
            nowSeen[key] = (nowSeen[key] || 0) + 1;
          });
          var prevSeen = F.seen || {};
          Object.keys(prevSeen).forEach(function (nm) {
            var gone = prevSeen[nm] - (nowSeen[nm] || 0);
            if (gone > 0) { var hit = matchDex(nm); if (hit) F.dexCount[hit] = (F.dexCount[hit] || 0) + gone; }
          });
          F.seen = nowSeen;
        } catch (e) {}
        var moving = !!(h.path && h.path.length);
        // ================= 🐉 โหมดเน้นฆ่าบอส =================
        if (opts.mode === 'boss') {
          if (boss) {
            F.bossEngaged = true; F.bossKilled = false; F.bossPos = [Math.round(boss.rx), Math.round(boss.ry)];
            setAuto(true);
            try { S.targetKey = bk; if (S.bot) S.bot.home = F.bossPos; } catch (e) {}
            var nowMs = Date.now();
            // 8 วิ เลือดบอสไม่ลด = โดนเสาบัง (LOS) → เดินอ้อมไปอีกฝั่ง (บทเรียนเดิมจากเกาะ)
            if (F.lastBHp != null && boss.hp != null && boss.hp >= F.lastBHp && nowMs - (F.lastBDt || 0) > 8000) {
              F.orbAng = (F.orbAng || 0) + 1.7;
              moveTo(boss.rx + Math.cos(F.orbAng) * 4, boss.ry + Math.sin(F.orbAng) * 4);
              F.lastBDt = nowMs; log('🔄 โดนเสาบัง? เดินอ้อมบอส ' + (boss.name || ''));
            } else if (bd > 8) moveTo(boss.rx, boss.ry);
            if (boss.hp !== F.lastBHp) { F.lastBHp = boss.hp; F.lastBDt = nowMs; }
            log('⚔️ ล็อกบอส ' + (boss.name || '') + ' Lv' + (boss.level | 0) + ' (ห่าง ' + Math.round(bd) + ')');
            return;
          }
          // เคยล็อกอยู่ แล้วบอสหายจากแมพ = ตายแล้ว
          if (F.bossEngaged) {
            F.bossEngaged = false; F.bossKilled = true; F.cycles++;
            F.lootStart = Date.now();
            F.lootBy = F.lootStart + Math.max(1, Math.min(600, +opts.lootSec || 15)) * 1000 + Math.floor(Math.random() * 1500);
            log('🏁 ฆ่าบอสครบ ' + F.cycles + ' ตัวแล้ว — เก็บของ ' + Math.round((F.lootBy - F.lootStart) / 1000) + ' วิ แล้วจะกวาดรอบรอตัวเกิดใหม่');
          }
          if (F.lootBy && Date.now() < F.lootBy) {
            setAuto(true);
            try { S.targetKey = -1; } catch (e) {}
            if (loot) {
              if (ld <= 1.4) pickItem(loot, lk);
              if (F.stuckK === lk && Date.now() - (F.stuckT || 0) > 10000) { F.lootSkip[lk] = Date.now() + 30000; log('⏭ ข้ามของเก็บไม่ได้'); }
              else if (F.stuckK !== lk) { F.stuckK = lk; F.stuckT = Date.now(); }
              if (!moving) moveTo(loot.rx, loot.ry);
              log('💰 เก็บของหลังบอส ห่าง ' + Math.round(ld * 10) / 10 + ' · เหลือ ' + Math.ceil((F.lootBy - Date.now()) / 1000) + ' วิ');
              return;
            }
            var cx0 = (F.bossPos && F.bossPos[0] != null) ? F.bossPos[0] : h.rx, cy0 = (F.bossPos && F.bossPos[1] != null) ? F.bossPos[1] : h.ry;
            if (!F.sweepT || Date.now() - F.sweepT > 5000) {
              var sang = Math.random() * Math.PI * 2, srr = 8 + Math.random() * 24;
              var stx = cx0 + Math.cos(sang) * srr, sty = cy0 + Math.sin(sang) * srr;
              try { if (S.grid && !S.grid.walkable(Math.round(stx), Math.round(sty))) { stx = cx0; sty = cy0; } } catch (e) {}
              F.sweepT = Date.now(); F.sweepX = stx; F.sweepY = sty;
            }
            if (!moving && F.sweepX != null) moveTo(F.sweepX, F.sweepY);
            log('🧹 กวาดหาของรอบจุดที่บอสตาย · เหลือ ' + Math.ceil((F.lootBy - Date.now()) / 1000) + ' วิ');
            return;
          }
          F.lootBy = 0;
          // ไม่เจอบอส (ยังไม่เกิด / อยู่ไกลเกินระยะ stream) → ตกไปโหมดกวาดทั้งแมพด้านล่าง
        }
        // ================= 🧹 กวาดทั้งแมพ (โหมด hunt + ตอนบอสยังไม่โผล่) =================
        setAuto(true);
        // ---- รับประกัน "ครอบคลุมทั้งแมพ": ทุก 60 วิ ตั้งเป้าจุดกวาดถัดไป แล้วเดินไปให้ถึง ----
        //   (เดิมใช้ "ถ้ายืนที่เดิม 90 วิ" แต่การไล่เก็บของทำให้ตำแหน่งเปลี่ยนตลอด = ตัวนับรีเซ็ตไม่จบ
        //    วัดจริง: i ค้าง 0 มา 3 นาทีทั้งที่ตัวละครเดินตามของไป 55 ช่อง)
        if (F.pts.length && (!F.nextSweepAt || Date.now() > F.nextSweepAt)) {
          F.nextSweepAt = Date.now() + 60000;
          F.goal = F.pts[F.i % F.pts.length]; F.i++;
        }
        var gd = F.goal ? dist2(F.goal[0], F.goal[1]) : 999;
        var far = gd > 18; // ยังต้องเดินอีกไกล = แวะเฉพาะของ/มอนที่ชิดตัว อย่าออกนอกเส้นทาง
        if (loot && ld <= (far ? 14 : 40)) {
          if (ld <= 1.4) pickItem(loot, lk);
          if (F.stuckK === lk && Date.now() - (F.stuckT || 0) > 10000) { F.lootSkip[lk] = Date.now() + 30000; log('⏭ ข้ามของเก็บไม่ได้'); }
          else if (F.stuckK !== lk) { F.stuckK = lk; F.stuckT = Date.now(); }
          if (!moving || ld > 2) moveTo(loot.rx, loot.ry);
          log('💰 เดินไปเก็บของ ห่าง ' + Math.round(ld * 10) / 10 + (far ? (' · แล้วไปจุดกวาดต่อ (เหลือ ' + Math.round(gd) + ')') : ''));
          return;
        }
        // ตัวจับ "ยืนตีหลังเสา": 7 วิไม่มีมอนตายในวง 22 ช่อง ทั้งที่ยืนชิด = ดาเมจไม่เข้า → ขยับหาตำแหน่งใหม่
        try {
          var nNow = Date.now(), alive = 0, hurt = false;
          S.ents.forEach(function (e2) {
            if (!e2 || e2.kind !== 'monster' || e2.dead > 0 || e2.rx == null) return;
            if (dist2(e2.rx, e2.ry) > 22) return;
            alive++; if (((e2.hp == null ? 100 : e2.hp)) < 100) hurt = true;
          });
          if (alive < (F.alivePrev == null ? 999 : F.alivePrev) || hurt) F.progAt = nNow;
          F.alivePrev = alive;
          if (!F.progAt) F.progAt = nNow;
          var stuckFor = Math.round((nNow - F.progAt) / 1000);
          if (mon && md <= 16 && alive >= 1 && stuckFor >= 7) {
            F.blkN = (F.blkN || 0) + 1;
            var step = F.blkN >= 3 ? 16 : 7;
            F.orbAng = (F.orbAng || 0) + 1.9;
            var bxx = Math.round(h.rx + Math.cos(F.orbAng) * step), byy = Math.round(h.ry + Math.sin(F.orbAng) * step);
            try { if (S.grid && !S.grid.walkable(bxx, byy)) { bxx = Math.round(h.rx); byy = Math.round(h.ry); } } catch (e) {}
            if (!moving && (bxx !== Math.round(h.rx) || byy !== Math.round(h.ry))) moveTo(bxx, byy);
            log('🔄 ' + stuckFor + ' วิไม่มีมอนตาย (ใกล้สุด ' + Math.round(md) + ' · ในวง ' + alive + ' ตัว) → โดนเสาบัง? ขยับหาตำแหน่งใหม่ (ครั้ง ' + F.blkN + ')');
            F.progAt = nNow;
          } else if (F.blkN && stuckFor <= 2) F.blkN = 0;
        } catch (e) {}
        var ft = dmon || mon, fd = dmon ? dmd : md;
        if (ft && fd <= (far ? 12 : 26)) {
          // มีมอนตรงโควตาในระยะ = เล็งตัวนั้น (AUTO ปกติจะเล็งตัวใกล้สุดซึ่งอาจไม่ใช่ตัวที่เราต้องการ)
          if (dmon) { try { S.targetKey = dmk; if (S.bot) S.bot.home = [Math.round(ft.rx), Math.round(ft.ry)]; } catch (e) {} }
          if (fd > 6 && !moving) moveTo(ft.rx, ft.ry);
          log((dmon ? '📕 โควตา: ตี ' : '🌾 ตี ') + (ft.name || 'มอน') + ' Lv' + (ft.level | 0) + ' (ห่าง ' + Math.round(fd) + ')' + (opts.mode === 'boss' ? ' · รอ/หาบอส' : ''));
          return;
        }
        // ไม่มีของ/มอนชิดตัว = เดินไปจุดกวาดต่อ (หัวใจของ "ฟาร์มทั้งแมพ")
        if (F.goal && !moving) {
          moveTo(F.goal[0], F.goal[1]);
          log('🧹 เดินไปจุดกวาด (' + F.goal[0] + ',' + F.goal[1] + ') เหลือ ' + Math.round(gd) + ' ช่อง · ' + (F.i % (F.pts.length || 1)) + '/' + (F.pts.length || 0) + (opts.mode === 'boss' ? ' · ยังไม่เจอบอสในแมพ' : ''));
        }
      } catch (e) {}
    };
    // ---- tick หลัก: รันทุก 1.5 วิ ในหน้าเกม ----
    window.__vhgRoamTick = function () {
      try {
        if (window.__vhgRoamOpts && window.__vhgRoamOpts.field) return window.__vhgFieldTick(); // โหมดฟาร์มmap ปกติ = อีก tick เลย ไม่แตะโค้ดเกาะ
        var S = window.S; if (!S || !S.hero) return;
        var run = S.voyUi && S.voyUi.run;
        if (!run) { clearInterval(window.__vhgRoamTimer); window.__vhgRoamTimer = null; return; } // จบทริป/หลุด → ปิด interval เอง
        if (S.dead || S.hero.dead > 0) return;
        var h = S.hero, opts = window.__vhgRoamOpts || {};
        var wants = window.__vhgWants;
        var bx = (run.at && run.at[0]) || 0, by = (run.at && run.at[1]) || 0;
        var dist2 = function (x, y) { return Math.sqrt((h.rx - x) * (h.rx - x) + (h.ry - y) * (h.ry - y)); };
        var log = function (m) { if (m && m !== window.__vhgRoamLog) { window.__vhgRoamLog = m; window.__vhgRoamLogAt = Date.now(); } };
        // ---- 📥 นับของเข้ากระเป๋า: เทียบ snapshot ครั้งก่อน (อิงสถานะจริง ไม่เดาจากคำสั่งที่ยิง) ----
        try {
          var bagFirst = (S.bagCfg && S.bagCfg.first) || 0;
          var snap = {};
          S.panels.inv.forEach(function (v, k) { if (v && v.id != null && k >= bagFirst) snap[v.id] = (snap[v.id] || 0) + (v.dur || 1); });
          var prevSnap = window.__vhgBagSnap;
          window.__vhgBagSnap = snap;
          if (!Array.isArray(window.__vhgEvts)) window.__vhgEvts = [];
          if (prevSnap) {
            var nmOf = function (id) { var d = S.items && S.items[id]; return (d && d.name && (d.name[1] || d.name[0])) || ('ไอเทม #' + id); };
            // ขวดยา/เครื่องราง (cat flask|charm): ค่าที่นับคือ dur = "ชาร์จที่เหลือ" ไม่ใช่จำนวนชิ้น
            //   (ยืนยันจากเกมสด: ไหโลหิตพฤกษา dur 85 = max 75 + ม็อด f_charges +10, ไหน้ำค้างจันทรา dur ลด 65→55 ตอนอัดมานา)
            //   → ไม่พิมพ์ขึ้น log เลย กันคนอ่านเข้าใจผิดว่า "ได้ไห 38 ใบ"
            var noLog = function (id) { var d = S.items && S.items[id]; var c = (d && d.cat ? String(d.cat) : '').toLowerCase(); return c === 'flask' || c === 'charm'; };
            var ids = {}; Object.keys(prevSnap).forEach(function (k) { ids[k] = 1; }); Object.keys(snap).forEach(function (k) { ids[k] = 1; });
            Object.keys(ids).forEach(function (k) {
              var dd = (snap[k] || 0) - (prevSnap[k] || 0);
              if (dd > 0 && !noLog(+k)) window.__vhgEvts.push('📥 เข้ากระเป๋า: ' + nmOf(+k) + ' ×' + dd);
            });
            if (window.__vhgEvts.length > 60) window.__vhgEvts.splice(0, window.__vhgEvts.length - 60);
          }
        } catch (e) {}
        // เดินเองไม่ออกนอกเส้นทาง: ยิงซ้ำเมื่อฮีโร่หยุด
        var moveTo = function (tx, ty) {
          try {
            if (typeof window.__walk !== 'function') return false;
            var dx = tx - h.rx, dy = ty - h.ry, dd = Math.sqrt(dx * dx + dy * dy);
            if (dd > 50) {
              var hx = Math.round(h.rx), hy = Math.round(h.ry);
              var rayStep = function (ang) {
                var cx = Math.cos(ang), cy = Math.sin(ang), lo = 2, hi = 8, best = 0;
                while (lo <= hi) {
                  var mid = (lo + hi) >> 1;
                  var px = Math.round(hx + cx * mid * 8), py = Math.round(hy + cy * mid * 8);
                  var ok = false;
                  try { var pp = S.grid.findPath(hx, hy, px, py); ok = !!(pp && pp.length > 1); } catch (e) {}
                  if (ok) { best = mid; lo = mid + 1; } else hi = mid - 1;
                }
                return { x: Math.round(hx + cx * best * 8), y: Math.round(hy + cy * best * 8), reach: best * 8 };
              };
              var base = Math.atan2(dy, dx);
              var pick = rayStep(base);
              if (pick.reach < 40) {
                var bestScore = dd - pick.reach;
                var offs = [0.5, -0.5, 1.0, -1.0, 1.5, -1.5];
                for (var oi = 0; oi < offs.length; oi++) {
                  var cand = rayStep(base + offs[oi]);
                  var cd = Math.sqrt((cand.x - tx) * (cand.x - tx) + (cand.y - ty) * (cand.y - ty));
                  if (cand.reach > 8 && cd < bestScore) { bestScore = cd; pick = cand; }
                }
              }
              if (pick.reach >= 2) { tx = pick.x; ty = pick.y; }
            }
            window.__walk(Math.round(tx), Math.round(ty));
            return true;
          } catch (e) {} return false;
        };
        var leaveNow = function (why) { try { window.__net.raw({ t: 'voy', op: 'leave' }); } catch (e) {} log('🏾 ออกจากเกาะ: ' + why); };
        // --- เช็คเงื่อนไขออกเกาะ (ถี่ 1.5 วิ แทน 25 วิ) ---
        var used = 0, cap = 120;
        try {
          var bf0 = (S.bagCfg && S.bagCfg.first) || 0;
          S.panels.inv.forEach(function (v, k) { if (v && v.id != null && k >= bf0) used++; });   // ไม่นับช่องของสวมใส่ (ไม่งั้นกระเป๋าว่างก็อ่านเป็น 12% แล้วรีบกลับ)
          var bc = S.bagCfg; if (bc && bc.cols && bc.rows) cap = bc.cols * bc.rows * (bc.pages || 1);
        } catch (e) {}
        var pct = cap ? used / cap * 100 : 0;
        if (opts.bagPct && pct >= opts.bagPct) { leaveNow('กระเป๋า ' + Math.round(pct) + '%'); return; }
        if (opts.minZen && S.me && S.me.zen != null && S.me.zen < opts.minZen) { leaveNow('เงิน ' + S.me.zen); return; }
        // --- state ต่อทริป ---
        var R = window.__vhgRoam;
        var tripKey = (run.node || 0) + '-' + ((S.info && S.info.map) || 0);
        if (!R || R.key !== tripKey) {
          R = window.__vhgRoam = { key: tripKey, pts: [], i: 0, bossPhase: false, bossKilled: false, bossEngaged: false, bossPos: null, quiet: 0 };
          for (var y = 25; y <= 235; y += 45) for (var x = 25; x <= 235; x += 45) { try { if (S.grid.walkable(x, y)) R.pts.push([x, y]); } catch (e) {} }
          R.pts.sort(function (a, b2) { return (Math.abs(a[0] - h.rx) + Math.abs(a[1] - h.ry)) - (Math.abs(b2[0] - h.rx) + Math.abs(b2[1] - h.ry)); });
        }
        var bossRush = opts.mode === 'boss';
        // บอสยังมีชีวิต = ล้างเส้นตายเก็บของเก่า (ไม่งั้นถ้าเคยตายแล้วในทริปนี้ leftSec จะติดลบ → ออกเกาะทันที)
        if (run.boss !== 0 && (R.lootBy || R.lootStart)) {
          R.lootBy = null; R.lootStart = null; R.lootSkip = null; R.stuckK = null; R.bossKilled = false;
        }
        // เดิมเริ่มตอนเหลือ 720 วิ = บอทใช้เวลา 17 นาทีแรกกวาด-map/ตีมอนก่อน แล้วไปไม่ทันถึงรัง (เจอจริง 17:01: เหลือ 32 ช่องก็ถูกตัดจบ)
        if (!R.bossPhase && run.left != null && run.left < 1500) R.bossPhase = true;
        if (bossRush) R.bossPhase = true;
        // --- สแกนมอน/บอส ---
        var mon = null, md = 999, boss = null, bd = 999, bk = null, near = null, nd = 999, nk = null;
        try {
          S.ents.forEach(function (e, k) {
            if (!e || e.kind !== 'monster' || e.dead > 0 || e.rx == null) return;
            var d = dist2(e.rx, e.ry);
            if (!mon || d < md) { md = d; mon = e; }
            var dn = Math.sqrt((e.rx - bx) * (e.rx - bx) + (e.ry - by) * (e.ry - by));
            if (dn < 45) { if (!near || dn < nd) { nd = dn; near = e; nk = k; } }
            // ⚠️ เกมติดธง boss ให้มอน elite ที่เดินเพ่นพ่านทั่วเกาะด้วย (เจอจริง: "งาเฒ่า" Lv81 ห่างรัง 100+ ช่อง → บอทเลี้ยวไปตีแล้วตาย 2 รอบ)
            //   บอสของเกาะจริง ๆ ยืนที่รัง (run.at) → เอาเฉพาะตัวที่ห่างรังไม่เกิน 25 ช่อง
            if (e.boss && dn < 25 && (!boss || dn < bd)) { boss = e; bk = k; bd = dn; }
          });
        } catch (e) {}
        var moving = !!(h.path && h.path.length);
        // ============ โหมดพุ่งบอส: เดินล้วน ไม่แวะ ============
        if (R.bossPhase) {
          if (run.boss === 0) {
            R.bossKilled = true; R.bossEngaged = false;
            // เส้นตายเก็บของ = ค่าที่ผู้ใช้ตั้ง (วิ) + หน่วงสุ่ม 0-1.5 วิ ให้ไม่เป๊ะเหมือนหุ่นยนต์
            if (!R.lootBy) {
              var lootSec = Math.max(1, Math.min(600, +opts.lootSec || 15));
              R.lootStart = Date.now();
              R.lootBy = R.lootStart + lootSec * 1000 + Math.floor(Math.random() * 1500);
              R.sweepT = 0; R.sweepX = null; R.sweepY = null;
            }
            // เปิด AUTO ของเกมช่วยหยิบของรอบตัว (เร็ว) + เราเดินเก็บของไกลเอง (ชัวร์)
            try { if (!S.bot && typeof window.__bot === 'function') window.__bot(true); if (S.bot) S.bot.home = [Math.round(h.rx), Math.round(h.ry)]; S.targetKey = -1; } catch (e) {}
            var leftSec = Math.ceil((R.lootBy - Date.now()) / 1000);
            if (leftSec > 0) {
              var l2 = null, l2d = 999, l2k = null;
              try { S.ents.forEach(function (e, k) { if (e && e.kind === 'item' && e.rx != null && wants(e) && !(R.lootSkip && R.lootSkip[k] > Date.now())) { var d = dist2(e.rx, e.ry); if (d < l2d) { l2d = d; l2 = e; l2k = k; } } }); } catch (e) {}
              if (l2) {
                if (l2d <= 1.4) { try { window.__net.raw({ t: 'pick', id: l2k }); } catch (e) {} }
                if (R.stuckK === l2k && Date.now() - (R.stuckT || 0) > 10000) { R.lootSkip = R.lootSkip || {}; R.lootSkip[l2k] = Date.now() + 30000; log('⏭ ข้ามของเก็บไม่ได้'); }
                else if (R.stuckK !== l2k) { R.stuckK = l2k; R.stuckT = Date.now(); }
                if (!moving) moveTo(l2.rx, l2.ry);
                log('💰 เก็บของบอส ห่าง ' + Math.round(l2d * 10) / 10 + ' · เหลือ ' + leftSec + ' วิ');
                return;
              }
              // ไม่มีของให้เห็นในรัศมี → เดินกวาดรอบจุดที่บอสตาย (ฮีโร่ต้องไม่นิ่งเกิน 2-3 วิ)
              var cx0 = (R.bossPos && R.bossPos[0] != null) ? R.bossPos[0] : bx;
              var cy0 = (R.bossPos && R.bossPos[1] != null) ? R.bossPos[1] : by;
              if (!R.sweepT || Date.now() - R.sweepT > 5000) {
                var sang = Math.random() * Math.PI * 2, srr = 8 + Math.random() * 24;
                var stx = cx0 + Math.cos(sang) * srr, sty = cy0 + Math.sin(sang) * srr;
                try { if (S.grid && !S.grid.walkable(Math.round(stx), Math.round(sty))) { stx = cx0; sty = cy0; } } catch (e) {}
                R.sweepT = Date.now(); R.sweepX = stx; R.sweepY = sty;
              }
              if (!moving && R.sweepX != null) moveTo(R.sweepX, R.sweepY);
              log('🧹 กวาดหาของบอส · เหลือ ' + leftSec + ' วิ');
              return;
            }
            leaveNow('บอสตาย + ครบเวลาเก็บของ ' + Math.round((R.lootBy - R.lootStart) / 1000) + ' วิ');
            return;
          }
          // เจอตัวบอสจริง → engage (เปิด AUTO ล็อกเป้าถาวร)
          if (boss) {
            R.bossEngaged = true; R.bossPos = [Math.round(boss.rx), Math.round(boss.ry)];
            try { if (!S.bot && typeof window.__bot === 'function') window.__bot(true); if (S.bot) S.bot.home = [Math.round(boss.rx), Math.round(boss.ry)]; S.targetKey = bk; } catch (e) {}
            var nowMs = Date.now();
            // ตี 8 วิ เลือดบอสไม่ลด = โดนเสาบัง (LOS) → เดินอ้อมไปอีกฝั่ง
            if (R.lastBHp != null && boss.hp != null && boss.hp >= R.lastBHp && nowMs - (R.lastBDt || 0) > 8000) {
              R.orbAng = (R.orbAng || 0) + 1.7;
              moveTo(boss.rx + Math.cos(R.orbAng) * 4, boss.ry + Math.sin(R.orbAng) * 4);
              R.lastBDt = nowMs;
              log('🔄 โดนเสาบัง? เดินอ้อมบอส');
            } else if (bd > 8) moveTo(boss.rx, boss.ry);
            if (boss.hp !== R.lastBHp) { R.lastBHp = boss.hp; R.lastBDt = nowMs; }
            log('⚔️ ล็อกบอส ' + (boss.name || '') + ' (ห่าง ' + Math.round(bd) + ')');
            return;
          }
          // มอนที่ "ชิดตัวจริง ๆ" (≤3 ช่อง) เท่านั้นถึงยอมให้ AUTO เคลียร์ — เดิม ≤6 ทำให้แวะตีทั้งทางจนไม่ถึงรัง (เจอจริง 17:00-17:01)
          if (mon && md <= 3) {
            try { if (!S.bot && typeof window.__bot === 'function') window.__bot(true); if (S.bot) S.bot.home = [Math.round(h.rx), Math.round(h.ry)]; } catch (e) {}
            return;
          }
          // ไม่เจอบอส: เดินตรงไป (ตามตำแหน่งล่าสุดหรือรัง) — แต่ "เปิด AUTO ค้างไว้"
          //   เดิมปิด AUTO ตอนเดินเข้าหาบอส = ไม่กดยา/ไม่ใช้สกิล/ไม่ dodge → โดนยิงฟรีจนตายซ้ำ (07:49 ตาย 4 รอบ)
          //   AUTO ของเกมตีเฉพาะเป้าในระยะใกล้ตัว และเราสั่ง moveTo ไปบอสตลอดทาง = ไม่แวะไกลอยู่ดี
          if (!R.bossEngaged) {
            try {
              if (!S.bot && typeof window.__bot === 'function') window.__bot(true);
              if (S.bot) S.bot.home = [Math.round(h.rx), Math.round(h.ry)];
              S.targetKey = -1;
            } catch (e) {}
          }
          // แต่ "ของที่พิมพ์ชื่อไว้ช่องเพิ่มเติม" (สมุดนำร่อง/บัตรเชิญลานอสูร/...) ต้องแวะเก็บ
          //   ระหว่างทางด้วย — เดิมโค้ดสแกนของเฉพาะตอนบอสตายแล้ว ทำให้เดินผ่านของที่ต้องการทิ้งทั้งอย่างนั้น
          //   ข้ามเมื่อกำลังสู้บอสอยู่ (R.bossEngaged) ไม่งั้นโดนลากหลุดเป้า
          if (!R.bossEngaged) {
            var xL = null, xD = 999, xK = null;
            try {
              S.ents.forEach(function (e2, k2) {
                if (!e2 || e2.kind !== 'item' || e2.rx == null) return;
                if (R.lootSkip && R.lootSkip[k2] > Date.now()) return;
                if (!window.__vhgWantsExtra(e2)) return;
                var d3 = dist2(e2.rx, e2.ry);
                if (d3 < xD) { xD = d3; xL = e2; xK = k2; }
              });
            } catch (e) {}
            if (xL && xD <= 10) {
              var xDef = (S.items && xL.item && S.items[xL.item.id]) || null;
              var xNm = xL.name || (xDef && xDef.name && (xDef.name[1] || xDef.name[0])) || ('#' + (xL.item && xL.item.id));
              if (xD <= 1.4) { try { window.__net.raw({ t: 'pick', id: xK }); } catch (e) {} }
              if (R.stuckK === xK && Date.now() - (R.stuckT || 0) > 10000) { R.lootSkip = R.lootSkip || {}; R.lootSkip[xK] = Date.now() + 30000; log('⏭ ข้ามของเก็บไม่ได้: ' + xNm); }
              else if (R.stuckK !== xK) { R.stuckK = xK; R.stuckT = Date.now(); }
              if (!moving) moveTo(xL.rx, xL.ry);
              log('🎯 แวะเก็บตามชื่อ: ' + xNm + ' (ห่าง ' + Math.round(xD) + ') · บอสเหลือ ' + Math.round(dist2((R.bossPos && R.bossPos[0]) || bx, (R.bossPos && R.bossPos[1]) || by)));
              return;
            }
          }
          var goal = R.bossPos || [bx, by];
          var dg = dist2(goal[0], goal[1]);
          // หลังตาย respawn = เกมพาเดินทิศสุ่ม/AUTO พาไปตีมอน → ต้องบังคับเดินกลับรังบอสใหม่
          //   ปล่อย moving เฉพาะตอนใกล้รัง (< 30 ช่อง) เพื่อไม่ขัด pathfinding ตามปกติ
          if (dg > 30) { moveTo(goal[0], goal[1]); if (R.bossEngaged && dg > 50) { R.bossEngaged = false; R.bossPos = null; } }
          else if (!moving && dg > 6) moveTo(goal[0], goal[1]);
          log('🐉 ' + (R.bossPos ? 'ไล่ตามบอส' : 'มุ่งหน้ารังบอส') + ' เหลือ ' + Math.round(dg));
          return;
        }
        // ============ โหมดล่า: เก็บของก่อน → ตี/เดินหามอน → กวาดโซน ============
        try { if (!S.bot && typeof window.__bot === 'function') window.__bot(true); if (S.bot) S.bot.home = [Math.round(h.rx), Math.round(h.ry)]; } catch (e) {}
        var loot = null, ld = 999, lootKey = null;
        try {
          S.ents.forEach(function (e, k) {
            if (!e || e.kind !== 'item' || e.rx == null) return;
            if (R.lootSkip && R.lootSkip[k] > Date.now()) return;
            if (!wants(e)) return;
            var d = dist2(e.rx, e.ry);
            if (d < ld) { ld = d; loot = e; lootKey = k; }
          });
        } catch (e) {}
        if (loot && ld <= 50) {
          if (ld <= 1.4) { try { window.__net.raw({ t: 'pick', id: lootKey }); } catch (e) {} }
          if (R.stuckK === lootKey && Date.now() - (R.stuckT || 0) > 10000) { R.lootSkip = R.lootSkip || {}; R.lootSkip[lootKey] = Date.now() + 30000; log('⏭ ข้ามของเก็บไม่ได้'); }
          else if (R.stuckK !== lootKey) { R.stuckK = lootKey; R.stuckT = Date.now(); }
          if (!moving || ld > 2) moveTo(loot.rx, loot.ry);
          log('💰 เดินไปเก็บของ ห่าง ' + Math.round(ld * 10) / 10);
          return;
        }
        // ---- 🛡 ตัวจับผิด "ยืนตีหลังเสา" (ดาเมจ 10 แทน 100) ----
        //   วัดจากเกมสด: S.targetKey ที่ AUTO เลือกเปลี่ยนทุก 0.5-2 วิ (มอนตายทันที) → จ้องเป้าเดียวไม่ได้
        //   ใช้ "ความคืบหน้าโดยรวม" แทน: ในวง 22 ช่อง ไม่มีมอนตาย (จำนวนไม่ลด) และไม่มีตัวไหนเลือดลด เลย
        //   ติดกัน ≥7 วิ ทั้งที่ยืนชิดมอน = ดาเมจไม่เข้า → ขยับหาตำแหน่งใหม่ (ซ้ำหลายรอบถอยไกลขึ้น)
        try {
          var nNow = Date.now(), alive = 0, hurt = false;
          S.ents.forEach(function (e2, k2) {
            if (!e2 || e2.kind !== 'monster' || e2.dead > 0 || e2.rx == null) return;
            if (dist2(e2.rx, e2.ry) > 22) return;
            alive++; if (((e2.hp == null ? 100 : e2.hp)) < 100) hurt = true;
          });
          if (alive < (R.alivePrev == null ? 999 : R.alivePrev) || hurt) R.progAt = nNow;
          R.alivePrev = alive;
          if (!R.progAt) R.progAt = nNow;
          var stuckFor = Math.round((nNow - R.progAt) / 1000);
          if (mon && md <= 16 && alive >= 1 && stuckFor >= 7) {
            R.blkN = (R.blkN || 0) + 1;
            var step = R.blkN >= 3 ? 16 : 7;
            R.orbAng = (R.orbAng || 0) + 1.9;
            var bxx = Math.round(h.rx + Math.cos(R.orbAng) * step), byy = Math.round(h.ry + Math.sin(R.orbAng) * step);
            try { if (S.grid && !S.grid.walkable(bxx, byy)) { bxx = Math.round(h.rx); byy = Math.round(h.ry); } } catch (e) {}
            if (!moving && (bxx !== Math.round(h.rx) || byy !== Math.round(h.ry))) moveTo(bxx, byy);
            log('🔄 ' + stuckFor + ' วิไม่มีมอนตาย (ใกล้สุด ' + Math.round(md) + ' · ในวง ' + alive + ' ตัว) → โดนเสาบัง? ขยับหาตำแหน่งใหม่ (ครั้ง ' + R.blkN + ')');
            R.progAt = nNow;
          } else if (R.blkN && stuckFor <= 2) R.blkN = 0;
        } catch (e) {}
        if (mon && md <= 14) { R.quiet = 0; return; } // ให้ AUTO ตีเอง
        if (mon && md < 80) { R.quiet = 0; if (!moving) moveTo(mon.rx, mon.ry); log('🎯 ' + (mon.name || 'มอน') + ' ห่าง ' + Math.round(md)); return; }
        R.quiet = (R.quiet || 0) + 1;
        if (R.quiet >= 2) {
          var pt = R.pts[R.i % (R.pts.length || 1)]; R.i++; R.quiet = 0;
          if (pt && !moving) moveTo(pt[0], pt[1]);
          log('🧹 กวาดโซน ' + (R.i % R.pts.length) + '/' + R.pts.length);
        }
      } catch (e) { try { window.__vhgRoamLog = '⚠️ roam error: ' + e.message; } catch (e2) {} }
    };
    window.__vhgRoam = null; // ทริปใหม่ = ล้างสถานะของทริปเก่า (โดยเฉพาะเส้นตายเก็บของหลังบอสตาย)
    window.__vhgBagSnap = null; window.__vhgEvts = []; // เริ่มนับกระเป๋าใหม่กันรายงานของผิดทริป
    window.__vhgRoamTimer = setInterval(window.__vhgRoamTick, 1500);
    window.__vhgRoamTick();
    return { ok: true, msg: '', already: false };
  },
  // อ่าน log ล่าสุดของ roam (node เรียกทุก tick เพื่อย้าย log ไปแสดงในแดชบอร์ด)
  // คืนข้อความที่ควรไปแสดงใน log: สถานะล่าสุด + รายการของเข้ากระเป๋าที่ค้างอยู่
  voyRoamLog: function () { var out = []; var m = window.__vhgRoamLog || ''; window.__vhgRoamLog = ''; if (m) out.push(m); if (Array.isArray(window.__vhgEvts) && window.__vhgEvts.length) { out = out.concat(window.__vhgEvts); window.__vhgEvts = []; } return out; },
  voyRoamStop: function () { if (window.__vhgRoamTimer) { clearInterval(window.__vhgRoamTimer); window.__vhgRoamTimer = null; } return { ok: true }; },
  // ปิด AUTO ของเกมให้สนิท — แค่เคลียร์ S.targetKey ไม่พอ (มันหันไปเล็งมอนตัวใหม่ทันที)
  //   ใช้ตอน "ต้องเดินตรงไปขึ้นวาร์ป" เพราะ AUTO จะดึงตัวละครออกนอกทางไปตีมอนข้างทาง
  autoOff: function (why) {
    var S = window.S; if (!S) return { ok: false, msg: 'ยังไม่เข้าเกม' };
    try { if (typeof window.__bot === 'function') window.__bot(false); } catch (e) {}
    try {
      var bt = S.bot;
      if (bt) {
        if (typeof bt.stop === 'function' && (bt.on || bt.running)) bt.stop();
        else if (typeof bt.toggle === 'function' && (bt.on || bt.running)) bt.toggle();
      }
    } catch (e) {}
    try { if (S.auto) S.auto = false; } catch (e) {}
    try { S.targetKey = -1; } catch (e) {}
    return { ok: true, msg: 'ปิด AUTO ชั่วคราว' + (why ? ' — ' + why : '') };
  },
  // ---------- 🔧 กัน "ติดเสา / หลบแล้วไม่หาตัวตีต่อ" ----------
  //   อาการที่ผู้ใช้แจ้ง (เป็นกันทุกตัวละคร ไม่ใช่แค่บอทนี้): AUTO เล็งมอนหลังเสา → ดาเมจติด BLOCK
  //   ยืนตีอยู่ที่เดิมโดนมันตีฝ่ายเดียว และพอขยับหนีออกมาแล้ว S.targetKey กลายเป็น -1 ก็ไม่มีใครเลือก
  //   เป้าใหม่ = ยืนนิ่งให้มันตีต่อ
  //   วิธีแก้: เลือกเป้าที่ \"เดินไปถึงได้จริง\" (กรองด้วย findPath) ไม่ใช่ใกล้สุดอย่างเดียว + ขยับตัวหลุดแนวเสา
  //   เรียกจาก autoWatch ทุก ~5 วิ จึงครอบคลุมทุกโหมด (เควส / ฟาร์มmap / โควตา / บอส)
  fixStuck: function (opts) {
    var S = window.S; if (!S || !S.hero) return { ok: false };
    // 🚫 กฎเหล็ก: fixStuck เรียก __bot(true) ตรง ๆ (อ้อม enableAuto) จึงต้องห้ามตัวเองในเมืองด้วย
    var tz = (((opts || {}).towns) || ['0', '2']).map(String);
    if (tz.indexOf(String(S.info && S.info.map)) >= 0) return { ok: true, inTown: true };
    var h = S.hero, o = opts || {}, rad = o.radius || 30, waitMs = o.waitMs || 4000;
    var st = window.__vhgStuck || (window.__vhgStuck = { key: null, hp: null, at: Date.now() });
    var mons = [];
    try {
      S.ents.forEach(function (e, k) {
        if (!e || e.kind !== 'monster' || e.dead > 0 || e.rx == null) return;
        // ข้ามหุ่นฝึกซ้อมในเมือง (เช่น "หุ่นฟางซ้อมตี") — ไม่ใช่ศัตรูจริง เดินไปตีเสียเวลาและดูผิดปกติ
        if (/หุ่น|ซ้อม|dummy|training/i.test(String(e.name || ''))) return;
        var d = Math.hypot(e.rx - h.rx, e.ry - h.ry);
        if (d <= rad) mons.push({ k: k, e: e, d: d });
      });
    } catch (e) { return { ok: false }; }
    if (!mons.length) { st.key = null; st.hp = null; st.at = Date.now(); return { ok: true, noMob: true }; }
    mons.sort(function (a, b) { return a.d - b.d; });
    // เป้าต้องเดินไปถึงได้ (path ไม่ยาวเกินระยะตรงมากเกินไป) — ไม่งั้นจะเลือกตัวหลังเสาซ้ำแล้วซ้ำอีก
    var reach = function (m) {
      try { var p = S.grid.findPath(Math.round(h.rx), Math.round(h.ry), Math.round(m.e.rx), Math.round(m.e.ry)); return !!(p && p.length > 1) && p.length <= Math.max(10, m.d * 2.5); } catch (e) { return true; }
    };
    var pick = function (skipKey) {
      for (var i = 0; i < mons.length; i++) { if (mons[i].k === skipKey) continue; if (reach(mons[i])) return mons[i]; }
      return null;
    };
    var ck = S.targetKey, cur = null;
    try { cur = (ck != null && ck >= 0) ? S.ents.get(ck) : null; } catch (e) {}
    var curOk = !!(cur && cur.kind === 'monster' && !(cur.dead > 0) && cur.rx != null);
    var now = Date.now();
    var walkTo = function (x, y) { try { if (typeof window.__walk === 'function') window.__walk(Math.round(x), Math.round(y)); } catch (e) {} };
    var autoOn = function () { try { if (typeof window.__bot === 'function') window.__bot(true); } catch (e) {} };
    var nm = function (m) { return (m.e.name || 'มอน') + ' Lv' + ((m.e.level | 0)); };

    if (!curOk) {                                   // (1) ไม่มีเป้า / เป้าตายหรือหลุดจากจอ = ตัวการ "ยืนนิ่ง"
      var n1 = pick(-1);
      if (!n1) return { ok: true, noReach: true };
      try { S.targetKey = n1.k; } catch (e) {}
      autoOn(); walkTo(n1.e.rx, n1.e.ry);
      st.key = n1.k; st.hp = n1.e.hp; st.at = now;
      return { ok: true, msg: '🎯 ไม่มีเป้าตี → จับใหม่ ' + nm(n1) + ' (ห่าง ' + Math.round(n1.d) + ') เดินเข้าไปหา' };
    }
    if (st.key === ck && cur.hp === st.hp) {         // (2) เป้าเดิม เลือดไม่ลดเลย = น่าจะโดนเสากั้น
      var waited = Math.round((now - (st.at || now)) / 1000);
      if (now - (st.at || now) < waitMs) return { ok: true, waiting: true };
      var n2 = pick(ck);
      try { if (n2) S.targetKey = n2.k; else S.targetKey = -1; } catch (e) {}
      var ang = Math.random() * Math.PI * 2, step = 7 + Math.random() * 6;
      var bx = Math.round(h.rx + Math.cos(ang) * step), by = Math.round(h.ry + Math.sin(ang) * step);
      try { if (S.grid && !S.grid.walkable(bx, by)) { bx = Math.round(h.rx); by = Math.round(h.ry); } } catch (e) {}
      autoOn(); if (bx !== Math.round(h.rx) || by !== Math.round(h.ry)) walkTo(bx, by);
      st.key = n2 ? n2.k : null; st.hp = n2 ? n2.e.hp : null; st.at = now;
      return { ok: true, msg: '🔄 ' + waited + ' วิ เลือด ' + nm({ e: cur, d: 0 }) + ' ไม่ลด (ติดเสา?) → ' + (n2 ? ('เลื่อนเป้าไป ' + nm(n2) + ' (ห่าง ' + Math.round(n2.d) + ')') : 'หาตัวใหม่ไม่เจอ ขยับตัวก่อน') + ' + ถอยหลุดแนวเสา' };
    }
    st.key = ck; st.hp = cur.hp; st.at = now;
    return { ok: true, fine: true };
  },
  // 🚪 เดินไป "ยืนบนประตูวาร์ป" ที่เปิดไว้ (เจอจริง: เปิดประตูสำเร็จแล้วแต่ตัวละครมัวไปตีมอน ไม่เข้าประตูสักที)
  //   ⚠️ ชื่อจริงในเกมคือ "ประตูวาปของ <ชื่อตัวละคร>" — สะกด "วาป" ไม่มี ร (วัดสด 12:33: ตัวละครยืนห่างประตู 1.4 ช่อง
  //   แต่ regex เดิมเขียน "ประตูวาร์ป" เลยหาไม่เจอ แล้วบอทก็ยิ่งยิง net.portal() ซ้ำทับของเดิมทุก 5 วิ)
  walkToPortal: function () {
    var S = window.S; if (!S || !S.hero) return { ok: false, msg: 'ยังไม่เข้าเกม' };
    var h = S.hero, best = null, bd = 9999, bk = null;
    try {
      S.ents.forEach(function (e, k) {
        if (!e || e.rx == null) return;
        if (!/ประตูวาป|ประตูวาร์ป|portal|กลับเมือง|ประตูกลับ|วาปกลับ/i.test(String(e.name || ''))) return;
        var d = Math.hypot(e.rx - h.rx, e.ry - h.ry);
        if (d < bd) { bd = d; best = e; bk = k; }
      });
    } catch (e) { return { ok: false, msg: e.message }; }
    // ประตูที่เกมแสดงอาจอยู่ในสถานะ "ไม่พร้อม (อีก N นาที)" — วงสีม่วงยังอยู่แต่วาร์ปไม่ได้
    //   (เจอจริง: ผู้ใช้ถ่ายภาพวงประตูตรงหน้า + แถบบนจอ "ประตูวาป ไม่พร้อม (อีก 7 นาที)")
    var banner = '';
    try {
      var bn = document.querySelectorAll('[class*="warn" i],[class*="toast" i],[class*="msg" i],[class*="tip" i],div');
      for (var bi = 0; bi < bn.length && !banner; bi++) {
        var bt = String(bn[bi].textContent || '').replace(/\s+/g, ' ').trim();
        if (/ประตูวาป[\s\S]{0,20}ไม่พร้อม/i.test(bt) && bt.length < 90) banner = bt;
      }
    } catch (e) {}
    var notReady = /ไม่พร้อม/.test(String(best && best.name || '')) || !!banner;
    if (notReady) {
      var mmn = (String((best && best.name) || '') + ' ' + banner).match(/อีก\s*(\d+)\s*นาที/);
      return { ok: true, notReady: true, waitMin: mmn ? +mmn[1] : null, name: String((best && best.name) || banner).slice(0, 46), msg: '⛔ ประตูวาร์ปกำลังคูลดาวน์' + (mmn ? (' อีก ~' + mmn[1] + ' นาที') : '') + ' (วงที่เห็นใช้ไม่ได้) → ใช้เส้นทางอื่นดีกว่า' };
    }
    if (!best) {
      var names = [];
      try { S.ents.forEach(function (e) { if (e && e.kind === 'npc' && names.length < 4) names.push(String(e.name || '?').slice(0, 16)); }); } catch (e) {}
      return { ok: false, npc: names, msg: 'ไม่เจอประตูวาร์ปในแมพนี้ (npc ที่เห็น: ' + (names.join(', ') || 'ไม่มี') + ')' };
    }
    var nm = String(best.name || '').slice(0, 40);
    if (bd > 1.2) { try { if (typeof window.__walk === 'function') window.__walk(Math.round(best.rx), Math.round(best.ry)); } catch (e) {} }
    if (bd <= 3.5) {
      if (!window.__vhgTpTalkAt || Date.now() - window.__vhgTpTalkAt > 4000) {
        window.__vhgTpTalkAt = Date.now();
        try { if (S.hero.path) S.hero.path = []; } catch (e) {}
        try { if (window.__net && typeof window.__net.talk === 'function') window.__net.talk(bk); } catch (e) {}
      }
      return { ok: true, onIt: true, d: Math.round(bd * 10) / 10, name: nm, msg: '🌀 ยืนบนประตูวาร์ปแล้ว (' + nm + ' ห่าง ' + (Math.round(bd * 10) / 10) + ') → ส่งคำสั่งคุยกับประตู' };
    }
    return { ok: true, onIt: false, d: Math.round(bd), name: nm, msg: '🌀 เดินเข้าประตูวาร์ป ' + nm + ' (ห่าง ' + Math.round(bd) + ' ช่อง)' };
  },
  // 🔍 หาแถบคำสั่ง "คุย: <ชื่อ>" ที่โผล่ด้านล่างจอ (ผู้ใช้ยืนยัน: คลิกแถบนี้ = เข้าประตูเหมือนกัน)
  //   คืนพิกัดกลางแถบเพื่อให้ node ยิง page.mouse.click (เมาส์จริง) เพราะ event สังเคราะห์เกมไม่รับ
  portalPrompt: function () {
    var best = null, any = null;
    try {
      var all = document.querySelectorAll('div,span,button,a,li');
      for (var i = 0; i < all.length; i++) {
        var el = all[i];
        if (el.offsetParent === null) continue;                       // มองไม่เห็น = ข้าม
        var t = String(el.textContent || '').replace(/\s+/g, ' ').trim();
        if (!/^คุย\s*[:：]/.test(t) || t.length > 60) continue;
        var r = el.getBoundingClientRect();
        if (r.width < 40 || r.height < 10) continue;
        var a = r.width * r.height;
        var cand = { cx: Math.round(r.left + r.width / 2), cy: Math.round(r.top + r.height / 2), w: Math.round(r.width), h: Math.round(r.height), t: t.slice(0, 40), a: a };
        if (!any || a < any.a) any = cand;
        // แถบที่เกี่ยวกับประตูวาร์ปต้องมาก่อน (เจอจริง: ในจอมีทั้ง "คุย: เวย์พอยต์" และ "คุย: ประตูวาป...")
        if (/วาป|วาร์ป|ประตู|portal/i.test(t) && (!best || a < best.a)) best = cand;
      }
    } catch (e) { return { ok: false, msg: e.message }; }
    var hit = best || any;
    return { ok: !!hit, hit: hit, preferPortal: !!best };
  },
  // 🧹 อ่านสถานะโหมด "ฟาร์ม map ปกติ" — done เป็นสัญญาณครั้งเดียว (bag=กระเป๋าเต็ม, town=หลุดเข้าเมือง) อ่านแล้วล้างธง
  fieldRoamState: function () {
    var S = window.S, F = window.__vhgField, O = window.__vhgRoamOpts || {};
    var d = window.__vhgFieldDone || null; window.__vhgFieldDone = null;
    return {
      ok: true, done: d, field: !!O.field, mode: O.mode || 'hunt', running: !!window.__vhgRoamTimer,
      map: (S.info && S.info.map), pts: F ? (F.pts || []).length : 0, i: F ? (F.i || 0) : 0,
      cycles: F ? (F.cycles || 0) : 0, bossEngaged: !!(F && F.bossEngaged), bossKilled: !!(F && F.bossKilled),
      goal: F && F.goal ? [F.goal[0], F.goal[1]] : null,
      dexCount: (F && F.dexCount) ? F.dexCount : {},
      hero: (S.hero && S.hero.rx != null) ? [Math.round(S.hero.rx), Math.round(S.hero.ry)] : null,
    };
  },
  // ---------- ⚡ พุ่งด้วยสกิลเคลื่อนที่ (เลียนแบบ "กดค้างคลิกขวา") ----------
  //   ถอดจากแพ็กเก็ตจริง (capture 01:35): เล็งพื้นที่ = {t:'skill',k:3,id:0,x,y,at:[hx,hy]}
  //                                        เล็งตัวมอน  = {t:'skill',k:1,id:<key>,x,y,at:[hx,hy]}
  //   วัดจริง: ขยับ ~4.2 ช่อง/ครั้ง (สูงสุด 15.8) · เกมยิงซ้ำเองทุก ~300-600ms ตอนกดค้าง · ค่าใช้ 33 มานา/ครั้ง
  //   ⚠️ ข้อมูลผู้ใช้: พุ่งใส่ตัวมอนจะได้มานาคืน (มีออปชั่น "ดูดมานา") → ลำดับความสำคัญคือ
  //      หาเอนทิตี้มอนใกล้เส้นทางก่อน ถ้าเจอให้คาสต์ใส่ตัวมัน (k=1) = เดินทาง+ตี+มานาคืน ในตัวเดียว
  //      ถ้าไม่มีมอนจริง ๆ จึงคาสต์เล็งพื้นที่ (k=3) และกรณีนั้นเท่านั้นที่เข้มเรื่องมานา
  leapStart: function (opts) {
    var S = window.S, net = window.__net;
    if (!S || !S.hero || !net || typeof net.raw !== 'function') return { ok: false, msg: 'ไม่พบระบบสกิลในหน้านี้' };
    var o = opts || {};
    if (o.x == null || o.y == null) return { ok: false, msg: 'ไม่มีพิกัดเป้าหมาย' };
    var towns = ((o.towns && o.towns.length) ? o.towns : ['0', '2']).map(String);
    if (towns.indexOf(String(S.info && S.info.map)) >= 0) return { ok: false, inTown: true, msg: 'อยู่ในเมือง — เดินธรรมดา (ตามที่ตั้งไว้)' };
    var stop = function (why) {
      var L = window.__vhgLeap; if (L && why) L.why = why;
      if (window.__vhgLeapTimer) { clearInterval(window.__vhgLeapTimer); window.__vhgLeapTimer = null; }
    };
    window.__vhgLeap = { tx: o.x | 0, ty: o.y | 0, stop: o.stopDist == null ? 6 : +o.stopDist, mpFloor: o.mpFloor == null ? 150 : +o.mpFloor, groundOnly: !!o.groundOnly, n: 0, mob: 0, ground: 0, why: '', last: null, moved: 0, bestD: null, progAt: 0 };
    if (window.__vhgLeapTimer) return { ok: true, already: true, msg: '' };
    window.__vhgLeapTimer = setInterval(function () {
      try {
        var SS = window.S, h = SS && SS.hero, L = window.__vhgLeap;
        if (!h || !L) { stop('ไม่มีตัวละคร'); return; }
        if (SS.dead || h.dead > 0) return;                       // ตายอยู่ = ไม่ยิง
        var cur = [Math.round(h.rx), Math.round(h.ry)];
        if (L.last) L.moved += Math.hypot(cur[0] - L.last[0], cur[1] - L.last[1]);
        L.last = cur;
        var d = Math.hypot(h.rx - L.tx, h.ry - L.ty);
        if (d <= L.stop) { stop('ถึงระยะ ' + L.stop + ' ช่อง'); return; }
        // กัน \"กระโดดอยู่ที่เดิม\": ถ้าพุ่งแล้วไม่ใกล้เป้าหมายขึ้นเลยภายใน 5 วิ = ติดสิ่งกีดขวาง (เสา/หน้าผา/มุมอับ)
        //   ปล่อยมือให้ตัวเดินหลักหาทางอื่น (เจอจริง: พุ่งหาเป้าหลังเสาแล้วเด้งอยู่ที่เดิม)
        if (L.bestD == null || d < L.bestD - 1.5) { L.bestD = d; L.progAt = Date.now(); }
        else if (Date.now() - (L.progAt || Date.now()) > 5000) { stop('พุ่ง 5 วิไม่ใกล้เป้าหมาย (ห่าง ' + Math.round(d) + ' ช่องเท่าเดิม = ติดสิ่งกีดขวาง)'); return; }
        // 1) พุ่งใส่ตัวมอนก่อน (ได้มานาคืนจากออปชั่นดูดมานา) — แต่ต้อง "ใกล้ตัว" จริง
        //    เจอจริง: ใช้รัศมี 18 จากจุดถัดไป = ไกลเกินระยะสกิล เซิร์ฟไม่ขยับให้ (ยิง 6 ครั้งไม่กระโดด)
        var best = null, bk = null, bd = 999;
        try {
          var ux0 = (L.tx - h.rx) / d, uy0 = (L.ty - h.ry) / d;
          SS.ents.forEach(function (e, k) {
            if (!e || e.kind !== 'monster' || e.dead > 0 || e.rx == null) return;
            var de = Math.hypot(e.rx - h.rx, e.ry - h.ry);
            if (de > 12) return;                                     // เกินระยะสกิล = ส่งไปก็เงียบ
            if (((e.rx - h.rx) * ux0 + (e.ry - h.ry) * uy0) <= 0) return; // อยู่หลังเรา = ไม่แวะ (ยกเว้นไม่มีทางเลือกอื่น)
            if (de < bd) { bd = de; best = e; bk = k; }
          });
        } catch (e) {}
        var mp = (SS.info && SS.info.mana != null) ? SS.info.mana : 0;
        if (best && !L.groundOnly) {
          L.mob++;
          try { net.raw({ t: 'skill', k: 1, id: bk, x: Math.round(best.rx), y: Math.round(best.ry), at: [Math.round(h.rx), Math.round(h.ry)] }); L.n++; } catch (e) { stop('ยิงแพ็กเก็ตไม่ออก: ' + e.message); }
          return;
        }
        // 2) ไม่มีมอนให้พุ่งใส่ = พุ่งเล็งพื้นที่ (เสียมานาเปล่า ๆ) → เข้มเรื่องมานาไว้
        if (mp <= L.mpFloor) { stop('มานาเหลือ ' + mp + ' (กันไว้ ' + L.mpFloor + ' · ไม่มีมอนให้ดูด)'); return; }
        var step = Math.min(d, 12), ux2 = (L.tx - h.rx) / d, uy2 = (L.ty - h.ry) / d;
        L.ground++;
        try { net.raw({ t: 'skill', k: 3, id: 0, x: Math.round(h.rx + ux2 * step), y: Math.round(h.ry + uy2 * step), at: [Math.round(h.rx), Math.round(h.ry)] }); L.n++; } catch (e) { stop('ยิงแพ็กเก็ตไม่ออก: ' + e.message); }
      } catch (e) { stop('ผิดพลาด: ' + e.message); }
    }, 420);
    return { ok: true, msg: '⚡ เริ่มพุ่ง → (' + (o.x | 0) + ',' + (o.y | 0) + ')', dist: Math.round(Math.hypot(S.hero.rx - o.x, S.hero.ry - o.y)) };
  },
  leapStop: function () {
    if (window.__vhgLeapTimer) { clearInterval(window.__vhgLeapTimer); window.__vhgLeapTimer = null; }
    return { ok: true };
  },
  leapState: function () {
    var L = window.__vhgLeap;
    return { running: !!window.__vhgLeapTimer, n: L ? (L.n || 0) : 0, mob: L ? (L.mob || 0) : 0, ground: L ? (L.ground || 0) : 0,
      moved: L ? Math.round((L.moved || 0) * 10) / 10 : 0, per: L && L.n ? Math.round((L.moved || 0) / L.n * 10) / 10 : 0,
      why: L ? (L.why || '') : '', target: L ? [L.tx, L.ty] : null };
  },
  // ---------- 📕 สมุดมอนสเตอร์ (ปุ่ม N) ----------
  //   ใช้ตั้งโควตาฆ่ารายตัว: อ่านชื่อมอน + เลเวล + ยอด "ล่าแล้ว" ของแต่ละแมพ
  //   โครงสร้างจริง (วัดสด): .bk-grp select = ตัวเลือกกลุ่ม/แมพ, .bk-cell[data-id] = แถวมอน,
  //   ยอดล่าอยู่เฉพาะในแผง .bk-right ซึ่งเปลี่ยนตาม "ช่องที่เลือก" เท่านั้น
  //   ⚠️ event สังเคราะห์ (click / dispatchEvent pointer) เกมไม่รับ → ฝั่ง node ต้องยิงเมาส์จริงผ่าน CDP
  //      ฟังก์ชันนี้จึงแค่ "ลอกตา": คืนตำแหน่งกลางแต่ละช่องให้ node ไปคลิก แล้วเรียกใหม่เพื่อยอด
  dexPeek: async function (mapLabel) {
    var sl = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
    var num = function (s) { return s ? +(String(s).replace(/,/g, '')) : 0; };
    var sel = document.querySelector('.bk-grp select');
    if (!sel) return { ok: false, msg: 'ไม่พบหน้าต่างสมุดมอนสเตอร์ (ต้องกด N เปิดก่อน)' };
    var maps = Array.prototype.map.call(sel.options, function (o) { return { v: o.value, t: String(o.textContent || '').trim() }; });
    if (mapLabel) {
      var hit = maps.filter(function (m) { return m.t === mapLabel || String(m.v) === String(mapLabel); })[0];
      if (hit && String(sel.value) !== String(hit.v)) {
        sel.value = hit.v;
        try { sel.dispatchEvent(new Event('change', { bubbles: true })); } catch (e) {}
        await sl(500);
      }
    }
    var hd = document.querySelector('.bk-head');
    var rt = document.querySelector('.bk-right');
    var hTx = hd ? String(hd.textContent || '').replace(/\s+/g, ' ').trim() : '';
    var rTx = rt ? String(rt.textContent || '').replace(/\s+/g, ' ') : '';
    var km = rTx.match(/ล่าแล้ว:?\s*([\d,]+)/);
    var gm = rTx.match(/([\d,]+)\s*\/\s*([\d,]+)/);
    var hm = hTx.match(/^(.*?)เลเวล\s*(\d+)/);
    var cells = Array.prototype.slice.call(document.querySelectorAll('.bk-cell')).map(function (c) {
      var b = c.getBoundingClientRect();
      var nm = String(c.textContent || '').replace(/\s+/g, ' ').trim();
      var lm = nm.match(/เลเวล\s*(\d+)/);
      return { id: c.dataset ? (c.dataset.id || '') : '', name: lm ? nm.slice(0, nm.indexOf('เลเวล')).trim() : nm,
        lv: lm ? +lm[1] : null, cx: Math.round(b.left + b.width / 2), cy: Math.round(b.top + b.height / 2),
        on: /(^|\s)sel(\s|$)/.test(String(c.className)) };
    });
    // ⚠️ "X / Y" ในแผงขวาไม่ใช่เป้าของมอนเสมอไป (บางทีที่จับได้คือ "แต้มสมุด 165/1,374")
    //   เจอจริง: ทหารโครงกระดูก 2031 ตัว แต่ goal ถูก parse ได้ 1374 → พรีฟิลแล้ว "ครบโควตา" ทันทีโดยไม่ล่า
    //   จึงรับเป็น goal เฉพาะเมื่อมากกว่ายอดล่าจริงเท่านั้น ที่เหลือให้ 0 = ไม่รู้ (ให้คนกรอกเอง)
    var killed = km ? num(km[1]) : 0, gGoal = gm ? num(gm[2]) : 0;
    return {
      ok: true, map: sel.options[sel.selectedIndex] ? String(sel.options[sel.selectedIndex].textContent || '').trim() : '',
      maps: maps.map(function (m) { return m.t; }), cells: cells,
      selName: hm ? hm[1].trim() : '', selLv: hm ? +hm[2] : null,
      killed: killed, goal: gGoal > killed ? gGoal : 0,
    };
  },
  voyAction: async function (act) {
    var S = window.S, net = window.__net;
    if (!S || !S.hero || !net) return { ok: false, msg: 'ยังไม่ได้เข้าเกม' };
    var sl = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
    var rnd = function (a, b) { return a + Math.random() * (b - a); };
    var raw = function (o) { try { net.raw(o); } catch (e) { if (S.link) S.link.send(o); } };
    var findTable = function () {
      var t = null, tKey = null, alt = null, altKey = null;
      try {
        S.ents.forEach(function (e, k) {
          if (!t && e && e.kind === 'npc' && /โต๊ะนำร่อง|chart table/i.test(e.name || '')) { t = e; tKey = k; }
          else if (!alt && e && e.kind === 'npc' && (e.art === 1025 || /seren|เซเรน|navigator/i.test(e.name || ''))) { alt = e; altKey = k; }
        });
      } catch (e) {}
      if (!t) { t = alt; tKey = altKey; }
      if (!t) { try { t = S.ents.get(30021); if (t) tKey = 30021; } catch (e) {} }
      return t ? { key: tKey, x: t.rx, y: t.ry } : null;
    };
    // เกม stream entity เฉพาะระยะใกล้ → ไม่เจอโต๊ะ = อาจอยู่ไกล → เดินไปพิกัดที่รู้ก่อน
    var TABLE_POS = { 2: { x: 138, y: 130 }, 0: { x: 138, y: 130 } };
    var walkToKnownTable = async function () {
      var fp = TABLE_POS[(S.info && S.info.map) || 0];
      if (!fp) return false;
      var h = S.hero;
      try {
        var p0 = S.grid.findPath(h.rx, h.ry, fp.x - 2, fp.y + 1);
        if (p0 && p0.length) {
          net.move(p0);
          for (var w = 0; w < 40; w++) { await sl(rnd(450, 600)); if (!h.path || !h.path.length) break; }
          await sl(rnd(1200, 1800)); // รอ entity stream เข้า
          return true;
        }
      } catch (e) {}
      return false;
    };
    var readChart = function (slot) { return ((S.voyUi && S.voyUi.m && S.voyUi.m.charts) || []).find(function (c) { return c.s === slot; }); };
    // rarity จริงอยู่ที่ item.rar (m.charts เป็น snapshot ตอนเปิดโต๊ะ — ไม่ update หลังใช้ ออร์บ)
    var rarOf = function (slot) { try { var it = S.panels.inv.get(slot); return it ? (it.rar | 0) : -1; } catch (e) { return -1; } };
    // tier จริงอ่านจาก inv ฝั่ง client (id 14848 = อันดับ 1) — คืน null ตอนยังไม่ซิงค์
    var tierOf = function (slot) { try { var it = S.panels.inv.get(slot); return (it && it.id >= 14848) ? (it.id - 14847) : null; } catch (e) { return null; } };
    // เซิร์ฟเวอร์ไม่บังคับระยะกับโต๊ะ (ผู้ใช้ยืนยัน: เปิดจากไกลได้) → ไม่ต้องเดิน แค่ talk + รอ m เปิด
    // ⚠️ ต้องปิด AUTO ของเกมก่อน — ไม่งั้นตัวละครเดิน/สู้ต่อเนื่อง เซิร์ฟจะ ignore talk
    var autoOff = function () {
      try {
        if (S.auto) S.auto = false;
        var bt = S.bot;
        if (bt) {
          if (typeof bt.stop === 'function' && (bt.on || bt.running)) bt.stop();
          else if (typeof bt.toggle === 'function' && (bt.on || bt.running)) bt.toggle();
        }
      } catch (e) {}
    };
    var ensureTable = async function (force) {
      if (S.voyUi && S.voyUi.m && !force) return true;
      if (force && S.voyUi && S.voyUi.m) { try { net.closeTalk(); } catch (e) {} await sl(rnd(700, 1100)); }
      autoOff();
      var h = S.hero;
      var walkTo = async function (tx, ty, stopDist) {
        stopDist = stopDist || 4;
        var dist = function () { return Math.sqrt((h.rx - tx) * (h.rx - tx) + (h.ry - ty) * (h.ry - ty)); };
        var t0 = Date.now(), best = dist(), progAt = t0, lastIssue = 0;
        // เดิมยิง __walk ซ้ำทุก ~0.4 วิ = รีเซ็ต path ตัวเอง + งบเวลา 5 วิไม่พอเดิน 20+ ช่อง (เจอจริง 16:37: ยืน 117,121 โต๊ะอยู่ 138,130 → "เปิดโต๊ะไม่สำเร็จ")
        while (Date.now() - t0 < 25000) {
          var dd = dist();
          if (dd <= stopDist) return true;
          if (dd < best - 0.5) { best = dd; progAt = Date.now(); }
          else if (Date.now() - progAt > 6000) return false; // เดินไม่เข้าใกล้เลย 6 วิ = ติดสิ่งกีดขวาง
          var walking = h.path && h.path.length;
          if (!walking || Date.now() - lastIssue > 3000) { // ยิงคำสั่งใหม่เฉพาะตอนหยุดเดิน หรือเดินวนไม่เข้าใกล้
            try { if (typeof window.__walk !== 'function') return false; window.__walk(Math.round(tx), Math.round(ty)); lastIssue = Date.now(); } catch (e) { return false; }
          }
          await sl(rnd(350, 500));
        }
        return dist() <= stopDist + 4;
      };
      var t = findTable();
      var FP = { 2: { x: 138, y: 130 }, 0: { x: 138, y: 130 } }[(S.info && S.info.map) || 0];
      if (!t && FP) { // entity ยังไม่ stream → เดินไปพิกัดโต๊ะที่รู้ แล้ว scan ใหม่
        await walkTo(FP.x - 2, FP.y + 1); t = findTable();
        if (!t) { await walkTo(FP.x - 2, FP.y + 1); t = findTable(); }
      }
      if (t) window.__vhgTable = t;
      var key = t ? t.key : 30021;
      for (var round = 0; round < 3; round++) {
        // ทุก round เช็คระยะใหม่: ตัวเราอาจถูกดึงออกนอกโต๊ะ (AUTO/เก็บของ) ระหว่างคุย → เดิมเช็คครั้งเดียวแล้วคุยทั้งที่ห่าง 28 ช่อง
        var near = t || findTable();
        if (near) {
          var dd2 = Math.sqrt((h.rx - near.x) * (h.rx - near.x) + (h.ry - near.y) * (h.ry - near.y));
          if (dd2 > 6) { if (!await walkTo(near.x - 1, near.y + 1) && FP) await walkTo(FP.x - 2, FP.y + 1); }
        } else if (FP) { await walkTo(FP.x - 2, FP.y + 1); }
        for (var w1 = 0; w1 < 6; w1++) { if (!h.path || !h.path.length) break; await sl(rnd(400, 600)); }
        autoOff();
        // ปิดช่องคุยค้างก่อน (ถ้า client ยังนับว่ามีหน้าต่างเปิดอยู่ เซิร์ฟจะเงียบกับ talk ใหม่ — เจอจริง 16:07-16:16 ยิง 8 ครั้งไม่ตอบ)
        try { net.closeTalk(); } catch (e) {}
        await sl(rnd(250, 450));
        try { net.talk(key); } catch (e) {}
        for (var w2 = 0; w2 < 11; w2++) { await sl(rnd(400, 550)); if (S.voyUi && S.voyUi.m) return true; }
      }
      return false;
    };
    var what = act.what;
    if (what === 'state') { // เปิดโต๊ะ (ถ้ายังไม่เปิด) แล้วส่งลิสต์ที่เซิร์ฟเห็น กลับให้ฝั่งวงวนใช้เช็คซ้ำ
      if (!await ensureTable(true)) return { ok: false, msg: 'เปิดโต๊ะนำร่องไม่สำเร็จ' };
      var mm = (S.voyUi && S.voyUi.m) || {};
      return { ok: true, charts: (mm.charts || []).map(function (c) { return { s: c.s | 0, tier: c.tier | 0, r: c.r | 0, n: c.n | 0 }; }), party: mm.party == null ? null : mm.party, price: mm.price == null ? null : mm.price };
    }
    if (what === 'buy') {
      var tier = Math.max(1, Math.min(14, act.tier | 0));
      if (!await ensureTable(true)) return { ok: false, msg: 'เปิดโต๊ะนำร่องไม่สำเร็จ (ยืนใกล้เซเรนหรือยัง?)' };
      raw({ t: 'voy', op: 'buy', tier: tier });
      await sl(rnd(600, 1000));
      return { ok: true, msg: 'ส่งคำสั่งซื้อสมุดอันดับ ' + tier + ' แล้ว' };
    }
    if (what === 'trade') {
      if (!await ensureTable(true)) return { ok: false, msg: 'เปิดโต๊ะนำร่องไม่สำเร็จ' };
      raw({ t: 'voy', op: 'trade', tier: Math.max(1, act.tier | 0) });
      await sl(rnd(600, 1000));
      return { ok: true, msg: 'ส่งคำสั่งสุ่มเลื่อนอันดับ (fee 5,000) แล้ว' };
    }
    if (what === 'leave') { raw({ t: 'voy', op: 'leave' }); return { ok: true, msg: 'ออกเดินทางกลับแล้ว' }; }
    if (what === 'orb') {
      var slot = act.s | 0;
      var item = S.panels.inv.get(slot);
      if (!item || item.id < 14848) {
        // slot ย้าย (บอทเกมจัดกระเป๋า) → หาช่องสมุดที่ rar<2 เอง
        slot = -1; var bestT = -1;
        try { S.panels.inv.forEach(function (v, k2) { if (v && v.id >= 14848 && v.id <= 14900 && (v.rar | 0) < 2 && v.id > bestT) { bestT = v.id; slot = k2; } }); } catch (e) {}
        if (slot < 0) return { ok: false, msg: 'ไม่พบสมุดที่ยังไม่แรร์ในกระเป๋า' };
        item = S.panels.inv.get(slot);
      }
      if (!item || item.id < 14848) return { ok: false, msg: 'ช่อง ' + slot + ' ไม่ใช่สมุดนำร่อง' };
      if (!await ensureTable(true)) return { ok: false, msg: 'เปิดโต๊ะไม่สำเร็จ — ยืนใกล้เซเรนแล้วหยุดนิ่ง?' };
      var used = [];
      var findOrb = function (id) { var found = -1; try { S.panels.inv.forEach(function (v, k2) { if (found < 0 && v && v.id === id) found = k2; }); } catch (e) {} return found; };
      // 'ok' = ใช้ออร์บแล้ว rarity ขยับจริง | 'none' = ไม่มีออร์บชิ้นนี้ | 'stuck' = ใช้แล้วแต่ไม่ขยับ
      var apply = async function (orbId, label) {
        var os = findOrb(orbId); if (os < 0) return 'none';
        var before = rarOf(slot);
        raw({ t: 'cur', s: os, to: slot });
        for (var w = 0; w < 12; w++) { await sl(rnd(400, 700)); if (rarOf(slot) !== before) { used.push(label); return 'ok'; } }
        return 'stuck';
      };
      var missing = [];
      // กติกาจริงจากคำอธิบายออร์บในเกม:
      //   ปลุกพลัง (11778) = ธรรมดา → เมจิก
      //   เสริมพลัง (11779) = เมจิก +1 ม็อด (ความหายากเท่าเดิม → ใช้ให้อัปแรร์ไม่ได้ ห้ามเสียออร์บฟรี)
      //   เลื่อนขั้น (11781) = เมจิก → แรร์
      // → ต้องเลือกตาม "ความหายากปัจจุบัน" ของสมุด ไม่ใช่ไล่ตัวแรกเสมอ
      var rNow = rarOf(slot);
      var plan = rNow <= 0 ? [[11778, 'ปลุกพลัง'], [11781, 'เลื่อนขั้น']] : [[11781, 'เลื่อนขั้น']];
      for (var pi = 0; pi < plan.length && rarOf(slot) < 2; pi++) {
        if (plan[pi][1] === 'เลื่อนขั้น' && rarOf(slot) !== 1) break; // ยังไม่เมจิก = เลื่อนขั้นใช้ไม่ได้
        var rr = await apply(plan[pi][0], plan[pi][1]);
        if (rr === 'none') { missing.push(plan[pi][1]); break; }     // ไม่มีออร์บ → หยุด (ไปลงเรือตามสภาพ)
        if (rr === 'stuck') { break; }                               // ใช้ออร์บถูกตัวแล้วไม่ขยับ → หยุด อย่าเผาออร์บเพิ่ม
      }
      try { net.closeTalk(); } catch (e) {}
      var rf = rarOf(slot);
      return {
        ok: rf >= 2, rar: rf, did: used, missing: missing,
        msg: 'ใช้ออร์บ: ' + (used.join(' → ') || 'ไม่ได้ใช้เลย') + (missing.length ? ' · ไม่มีออร์บ ' + missing.join(',') : '') + ' · rar=' + rf + (rf >= 2 ? ' ✓ แรร์แล้ว' : ' (ยังไม่แรร์)'),
      };
    }
    if (what === 'sail') {
      if (S.voyUi && S.voyUi.run) return { ok: false, msg: 'กำลังเดินทางอยู่ — จบรอบก่อน' };
      var node = act.node | 0;
      if (!await ensureTable(true)) return { ok: false, msg: 'เปิดโต๊ะไม่สำเร็จ — ยืนใกล้เซเรนแล้วหยุดนิ่ง?' };
      // เลือกจาก "ลิสต์ที่เซิร์ฟส่ง" ก่อน (S.voyUi.m.charts เป็น snapshot ตอนเปิดโต๊ะ — สมุดที่ซื้อใหม่อาจยังไม่เข้า S.panels.inv ฝั่ง client)
      //   แต่ต้องกรอง "ช่องผี" ออก: วัดสด 17:0x เซิร์ฟยังส่งช่อง 133 เป็นสมุดอันดับ 1 ทั้งที่ inv ช่องนั้นเป็นไอเทม 20493 แล้ว
      var cl = (act.srvCharts && act.srvCharts.length ? act.srvCharts : ((S.voyUi && S.voyUi.m && S.voyUi.m.charts) || []))
        .map(function (c) { return { s: c.s | 0, tier: c.tier | 0, n: c.n | 0, invTier: tierOf(c.s), invRar: (c.s != null ? rarOf(c.s) : -1) }; })
        .filter(function (c) { return !(c.invTier == null && c.invRar >= 0); }); // ทิ้งเฉพาะ "ช่องที่มีของแต่ไม่ใช่สมุด" (phantom) — ช่องว่าง = ยังไม่ซิงค์ ต้องเก็บไว้
      if (!cl.length) {
        // fallback: โต๊ะถูกปิด (srvCharts/m.charts ว่าง) → สแกน S.panels.inv ตรง ๆ ทุกช่อง (รวม quickslot < bagFirst)
        try { S.panels.inv.forEach(function (v, k) {
          if (v && v.id >= 14848 && v.id <= 14900) cl.push({ s: k, tier: v.id - 14847, n: v.dur || v.n || 1, invTier: v.id - 14847, invRar: v.rar | 0 });
        }); } catch (e) {}
      }
      if (!cl.length) return { ok: false, msg: 'เซิร์ฟไม่เห็นว่าในกระเป๋ามีสมุดนำร่องเลย (ทั้งลิสต์โต๊ะ+inv)' };
      // ใช้ช่องที่ฝั่งวงวนเลือกมาให้ (เลือกตามอันดับสูง→ความหายากสูง) ถ้าไม่ระบุ/ไม่ตรงค่อยเลือกเอง
      var want = (act.s == null) ? null : (act.s | 0);
      var pick = null, pr = -1;
      if (want != null) {
        for (var wi = 0; wi < cl.length; wi++) if (cl[wi].s === want) { pick = cl[wi]; break; }
        if (pick) pr = rarOf(pick.s);
      }
      if (!pick) {
        cl.sort(function (a, b) { return (b.tier | 0) - (a.tier | 0) || (rarOf(b.s) | 0) - (rarOf(a.s) | 0); }); // อันดับสูงก่อน แล้วความหายากสูง
        pick = cl[0] || null; pr = pick ? rarOf(pick.s) : -1;
      }
      if (!pick) return { ok: false, msg: 'ไม่พบสมุดในกระเป๋า' };
      var tierNow = tierOf(pick.s);
      var tName = (tierNow != null ? 'อันดับ ' + tierNow : 'อันดับ ' + (pick.tier | 0)) + (tierNow == null ? ' (ตามข้อมูลเซิร์ฟ)' : '');
      raw({ t: 'voy', op: 'sail', s: pick.s, node: node });
      // ยังไม่แรร์ก็ลงเรือได้ (ของจะดรอปน้อยลง) — ห้ามปฏิเสธ เพราะอาจไม่มีออร์บเหลือ
      return { ok: true, msg: '🚢 ออกเดินทาง → เกาะ node ' + node + ' (' + tName + ' · ' + (pr >= 2 ? 'แรร์' : (pr < 0 ? 'ยังไม่ซิงค์ความหายาก → ของอาจน้อยลง' : 'rar=' + pr + ' ยังไม่แรร์ → ของจะน้อยลง')) + ')' };
    }
    return { ok: false, msg: 'คำสั่งไม่รู้จัก: ' + what };
  },
};

// ---------- เลือกสมุดที่จะใช้ลงเรือ (logic ฝั่ง node — ใช้ทดสอบได้) ----------
// กฎ: ใช้ได้เฉพาะอันดับ >= ที่ตั้งไว้, เรียง อันดับสูงก่อน → ความหายากสูงก่อน
// (มี 15 ในกระเป๋า = ใช้ 15 ไม่ต้องไปซื้อ 14)  ⚠️ ฝั่งหน้าเกม (voyAction sail) ทำตามกฎเดียวกันนี้
function pickChart(charts, targetTier) {
  const t = targetTier | 0;
  return (charts || [])
    .filter((c) => c && (c.tier | 0) >= t)
    .sort((a, b) => (b.tier | 0) - (a.tier | 0) || (b.r | 0) - (a.r | 0))[0] || null;
}

module.exports = {
  id: 'caelmora',
  name: 'Caelmora',
  gameUrl: 'https://caelmora.com/',
  TOWN_MAPS: TOWN_MAPS, HOME_TOWN: HOME_TOWN, POTION: POTION,
  pickChart: pickChart,
  decodeWorldFrame: decodeWorldFrame,
  preLaunch: preLaunch,   // ★ hook ใหม่ (accounts.js เรียกก่อน page.goto)
  page: page,
};
