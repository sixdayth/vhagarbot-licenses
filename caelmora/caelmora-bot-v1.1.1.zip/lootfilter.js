// ============================================================
//  lootfilter.js — เครื่องมือ "กฎกรองของ" แบบเดียวกับในเกม
// ------------------------------------------------------------
//  ใช้ได้ 2 ที่จากไฟล์เดียว (ต้นฉบับเดียว ไม่ต้องก๊อป):
//    • ฝั่ง node  → require('./lootfilter')  (ใช้ทดสอบ + แสดงผลในแดชบอร์ด)
//    • ฝั่งหน้าเกม → server อ่านไฟล์นี้เป็นข้อความ แล้วส่งเข้า page
//                    ผ่าน opts.lfSrc → new Function(lfSrc + ';return {...})')
//
//  รูปแบบกฎ = ไฟล์ที่เกม export ออกมา (ลิงก์ wiki /รหัส CMF1.xxxx):
//     { n:"ชื่อ", o:{pick:false}, r:[ { if:{...}, look:{...}, hide:true, pick:false }, ... ] }
//
//  เงื่อนไขที่รองรับ (ทุกคีย์ต้อง "จริงพร้อมกัน", ค่าใน [] เป็น "หรือกัน"):
//     grp  : กลุ่มไอเทม  เช่น ["weapon","offhand","armour","jewel"]
//     id   : รหัสไอเทม   เช่น [11786,11785]
//     rr   : ความหายาก   เช่น [0,1]   (0=ปกติ 1=เมจิก 2=แรร์ 3=Unique)
//     il   : เลเวลไอเทม  [ต่ำสุด,สูงสุด] เช่น [95,200]
//     sock : จำนวนรูโซล  [ต่ำสุด,สูงสุด]
//     cat  : หมวดดิบในนิยามไอเทม เช่น ["chart","slate"]
//     name : คำที่ต้องมีในชื่อ (ไทยหรืออังกฤษ)
//  การตัดสินใจ — ฟิลเตอร์ของเกมเป็น BLACKLIST: **ค่าเริ่มต้น = เก็บ**
//     กฎข้อแรกที่ตรงจะเป็นตัวตัดสิน
//     hide:true หรือ pick:false → ไม่เก็บ
//     กฎอื่นที่ตรง              → เก็บ
//     ไม่ตรงกฎไหนเลย            → เก็บ (กฎมีไว้ "ห้าม" ไม่ใช่ "อนุญาต")
//  คีย์ `look` (สี/ขนาด/เสียง) เป็นเรื่องแสดงผลล้วน ๆ บอทไม่สนใจ
//  คีย์เงื่อนไขที่ไม่รู้จัก → ข้ามกฎข้อนั้นทิ้ง (ไม่เดา) และรายงานกลับมาด้วย
//     ใต้กติกา blacklist การข้ามกฎ = ยังเก็บของนั้นอยู่ (ปลอดภัยกว่าทำของหลุด)
// ============================================================
/* eslint-disable */
var LF_GROUPS = ['weapon', 'offhand', 'armour', 'jewel', 'tjewel', 'card', 'key', 'wonder', 'orb', 'shard', 'mat', 'uncut', 'rune', 'flask', 'charm', 'other'];
var LF_SUPPORTED_IF = ['grp', 'id', 'rr', 'sock', 'il', 'cat', 'name'];

// แมพหมวดในเกม → "กลุ่ม" ที่ฟิลเตอร์ใช้ (ตรงกับที่เกมใช้)
function groupOf(def) {
  var ae = def && def.cat;
  if (!ae) return 'other';
  if (ae === 'weapon' || ae === 'offhand' || ae === 'flask' || ae === 'charm' || ae === 'uncut' || ae === 'rune') return ae;
  if (ae === 'helmet' || ae === 'body' || ae === 'gloves' || ae === 'boots') return 'armour';
  if (ae === 'ring' || ae === 'amulet' || ae === 'belt') return 'jewel';
  if (ae === 'jewel') return 'tjewel';
  if (ae === 'card') return 'card';
  if (ae === 'sigil' || ae === 'chart' || ae === 'slate' || ae === 'dgkey' || ae === 'dgsigil') return 'key';
  if (ae === 'augury' || def.imprint || def.glass || def.key === 'SGS' || def.key === 'SG' || def.key === 'IMP') return 'wonder';
  if (ae === 'currency') {
    var kk = def.key || '';
    if (/^SHARD/.test(kk)) return 'shard';
    if (/^(HONE|RIVET|RESIN|CHISEL\d|AWL|FILING_AWL|INSIGHT)$/.test(kk)) return 'mat';
    return 'orb';
  }
  return 'other';
}

// ถอดรหัส "รหัสแชร์" ของเกม: "CMF1.<base64>" | base64 ล้วน | object ที่ parse แล้ว
function decodeCmf(code) {
  if (!code) return null;
  if (typeof code === 'object') return code;
  var t = String(code).trim();
  if (t.charAt(0) === '{') { try { return JSON.parse(t); } catch (e) { return { error: 'JSON ไม่ถูกต้อง: ' + e.message }; } }
  if (t.indexOf('http') === 0) { var m = t.match(/CMF[0-9]+\.[A-Za-z0-9+\/=_-]+/); if (m) t = m[0]; }
  if (t.indexOf('.') < 0) return { error: 'รูปแบบรหัสไม่ถูกต้อง (ควรขึ้นต้นด้วย CMF1.)' };
  var b64 = t.slice(t.indexOf('.') + 1).replace(/[-_]/g, function (c) { return c === '-' ? '+' : '/'; });
  var json;
  try {
    if (typeof Buffer !== 'undefined') json = Buffer.from(b64, 'base64').toString('utf8');
    else json = decodeURIComponent(escape(atob(b64)));
  } catch (e) { return { error: 'base64 ไม่ถูกต้อง: ' + e.message }; }
  try { return JSON.parse(json); } catch (e) { return { error: 'ถอดรหัสแล้วแต่ไม่ใช่ JSON: ' + e.message }; }
}

// ตรวจว่าไอเทมหนึ่งชิ้นผ่านเงื่อนไขของกฎหนึ่งข้อไหม
// คืน true / false / 'unknown' (มีคีย์ที่ไม่รู้จัก → ข้ามกฎข้อนี้)
function matchIf(cond, ctx) {
  if (!cond || typeof cond !== 'object') return true;
  for (var k in cond) {
    if (LF_SUPPORTED_IF.indexOf(k) < 0) return 'unknown';
    var v = cond[k];
    if (k === 'grp') { if (!inList(v, ctx.grp)) return false; }
    else if (k === 'id') { if (!inList(v, ctx.id)) return false; }
    else if (k === 'rr') { if (!inList(v, ctx.rar)) return false; }
    else if (k === 'cat') { if (!inList(v, ctx.cat)) return false; }
    else if (k === 'name') { if (!nameHit(v, ctx.name)) return false; }
    else if (k === 'sock') {
      var lo = Array.isArray(v) ? v[0] : v, hi = Array.isArray(v) && v.length > 1 ? v[1] : lo;
      var n = ctx.sock || 0;
      if (!(n >= lo && n <= hi)) return false;
    }
    else if (k === 'il') {
      var ilo = Array.isArray(v) ? v[0] : v, ihi = Array.isArray(v) && v.length > 1 ? v[1] : ilo;
      var il = ctx.il || 0;
      if (!(il >= ilo && il <= ihi)) return false;
    }
  }
  return true;
}
function inList(list, val) {
  if (list == null) return true;
  if (!Array.isArray(list)) list = [list];
  for (var i = 0; i < list.length; i++) { if (list[i] === val) return true; }
  return false;
}
function nameHit(pat, name) {
  if (pat == null) return true;
  var arr = Array.isArray(pat) ? pat : [pat];
  var n = String(name || '');
  for (var i = 0; i < arr.length; i++) { if (arr[i] && n.indexOf(String(arr[i])) >= 0) return true; }
  return false;
}

// ตัดสินว่า "เก็บ" ไหม → { keep, why, rule }
// ⚠️ ฟิลเตอร์ของเกมเป็นแบบ BLACKLIST: ค่าเริ่มต้น = เก็บ
//    กฎข้อแรกที่ตรงจะตัดสิน — hide / pick:false = ไม่เก็บ, กฎอื่นที่ตรง = เก็บ
//    กฎที่มีคีย์ไม่รู้จัก → ข้าม (ผลคือยังเก็บอยู่ = ทางที่ปลอดภัยกว่าทำของหลุด)
function decide(rules, ctx) {
  if (!Array.isArray(rules) || !rules.length) return { keep: true, why: 'ไม่มีกฎ → เก็บหมด' };
  var unknown = 0;
  for (var i = 0; i < rules.length; i++) {
    var rl = rules[i] || {};
    var m = matchIf(rl.if, ctx);
    if (m === 'unknown') { unknown++; continue; }
    if (!m) continue;
    if (rl.hide) return { keep: false, why: 'กฎ#' + (i + 1) + ' ซ่อนไว้', rule: i };
    if (rl.pick === false) return { keep: false, why: 'กฎ#' + (i + 1) + ' ไม่ให้เก็บ', rule: i };
    return { keep: true, why: 'กฎ#' + (i + 1), rule: i };
  }
  return { keep: true, why: 'ไม่ตรงกฎที่ห้าม → เก็บ' + (unknown ? ' (ข้าม ' + unknown + ' กฎที่บอทไม่รู้จัก)' : ''), rule: -1 };
}

// สรุปว่ากฎมีคีย์อะไรที่บอทยังไม่รองรับบ้าง (ไว้เตือนในแดชบอร์ด)
function unknownKeys(rules) {
  var out = {};
  (rules || []).forEach(function (rl, i) {
    var c = (rl && rl['if']) || {};
    for (var k in c) if (LF_SUPPORTED_IF.indexOf(k) < 0) { (out[k] = out[k] || []).push(i + 1); }
  });
  return out;
}

// วางแผนฝากคลัง: คืน { put:[ช่องที่ฝาก], kept:{id:จำนวนที่เก็บ} }
// เก็บทั้งกองเสมอ (ไม่แบ่งกอง) → อาจได้มากกว่าที่กำหนดเล็กน้อย แต่ปลอดภัยกว่าฝากทิ้งผิดชิ้น
function planDeposit(slots, keep) {
  var quota = {}, put = [], kept = {};
  for (var id in keep) if (Object.prototype.hasOwnProperty.call(keep, id)) quota[+id] = keep[id] | 0;
  (slots || []).forEach(function (s) {
    if (!s || s.slot == null || s.id == null) return;
    var n = s.n || 1;
    if (quota[s.id] != null && quota[s.id] > 0) { quota[s.id] -= n; kept[s.id] = (kept[s.id] || 0) + n; return; }
    put.push(s.slot);
  });
  return { put: put, kept: kept };
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { groupOf, decodeCmf, matchIf, decide, unknownKeys, planDeposit, LF_SUPPORTED_IF, LF_GROUPS };
}
