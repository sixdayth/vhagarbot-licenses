// ============================================================
//  accounts.js — เครื่องยนต์ "หลายบัญชี" ของ VhagarBot (แกนกลาง ไม่ผูกเกม)
// ------------------------------------------------------------
//  1 Account = 1 หน้าต่าง Chrome + 1 โปรไฟล์ (ล็อกอินคนละบัญชีเกม) + ผู้เฝ้าของตัวเอง
//  server.js จะสร้าง Account ตามรายการใน config.accounts[] แล้วรวมสถานะส่งให้แดชบอร์ด
//  ทุกอย่างที่เกี่ยวข้องกับ "ตัวเกม" (อ่านค่า, เดินทาง, ขาย, ซื้อยา, แพ็กเก็ต)
//  อยู่ใน game-adapter.js ทั้งหมด — ไฟล์นี้แค่ "เรียกใช้" ผ่านตัวแปร GAME
//  ★ ทำเกมใหม่ → เปลี่ยนแค่ game-adapter.js ไฟล์เดียว ไม่ต้องแตะไฟล์นี้
// ============================================================
'use strict';
const fs = require('fs');
const path = require('path');
const puppeteer = require('puppeteer-core');
const buildinfo = require('./buildinfo');
const GAME = require('./game-adapter');

const BASE_DIR = process.pkg ? path.dirname(process.execPath) : __dirname;
const PROFILES_ROOT = path.join(BASE_DIR, 'profiles');
const RELEASE = !!buildinfo.release;
const DEV_ONLY = new Set(buildinfo.devOnly || []);
const isDevOnly = (k) => RELEASE && DEV_ONLY.has(k);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ข้อความต้นฉบับของ lootfilter.js — ส่งเข้าหน้าเกมเป็น opts.lfSrc (ไฟล์เดียวใช้ได้ 2 ฝั่ง)
let LF_SRC = '';
try { LF_SRC = fs.readFileSync(path.join(BASE_DIR, 'lootfilter.js'), 'utf8'); } catch (e) { console.log('[lootfilter] ไม่พบ lootfilter.js — โหมดกฎจะปิดตัว'); }
function jitterLoop(fn, baseMs, spread = 0.25) {
  let stopped = false;
  const run = async () => {
    if (stopped) return;
    try { await fn(); } catch (e) {}
    if (stopped) return;
    setTimeout(run, Math.max(200, Math.round(baseMs * (1 + (Math.random() * 2 - 1) * spread))));
  };
  setTimeout(run, Math.round(baseMs));
  return () => { stopped = true; };
}

class Account {
  constructor(cfg, index, gameUrl, viewport, getGlobal, saveFn) {
    this.cfg = cfg;            // { name, enabled, farmMap, role }
    this.index = index;
    this.gameUrl = gameUrl;
    this.viewport = viewport;
    this.getGlobal = getGlobal; // fn() → liveConfig (ค่ารวม)
    this.saveFn = saveFn || (() => {}); // บันทึกลงไฟล์ config
    this.browser = null; this.page = null; this.cdp = null;
    this.timers = [];
    this.logs = []; // บันทึกการทำงาน (timestamped)
    this.gameInfo = { selfId: null, name: cfg.name || null, job: null, lv: null, mapId: null, hp: null, maxHp: null, sp: null, maxSp: 1 };
    this.state = {
      name: cfg.name, enabled: !!cfg.enabled, farmMap: cfg.farmMap || '', role: cfg.role || 'farm',
      connected: false, pageTitle: '', farmOn: false,
      ws: { in: 0, out: 0 }, gameStats: null, traveling: false, travelNote: '',
      lastFarmMap: null, lastError: '', autoWatch: { count: 0 }, potion: { count: 0, lastAt: 0 },
      startedAt: Date.now(), running: false,
    };
  }

  get global() { return this.getGlobal(); }
  // settings ต่อบัญชี: ค่ารวม (global) เป็น default, cfg.settings ทับทีละตัว
  S() {
    const g = this.global;
    const s = this.cfg.settings || {};
    const pick = (k) => (s[k] !== undefined ? s[k] : g[k]);
    return {
      humanDelay: pick('humanDelay'), autoPotion: pick('autoPotion'), autoWatch: pick('autoWatch'),
      sellConfig: pick('sellConfig'), autoTown: pick('autoTown'), enterCharacter: pick('enterCharacter'),
      autoFarm: pick('autoFarm'), buyPotion: pick('buyPotion'), autoLogin: pick('autoLogin'), voyFarm: pick('voyFarm'), lootFilter: pick('lootFilter'), wsLog: g.wsLog,
    };
  }
  log(msg) {
    this.logs.push({ t: new Date().toLocaleTimeString('th-TH', { hour12: false }), msg });
    if (this.logs.length > 120) this.logs.shift();
  }
  townMaps() { const aw = this.S().autoWatch; return (aw && aw.townMaps) || GAME.TOWN_MAPS; }

  async launch() {
    const exe = ['C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', 'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe', 'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe', 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe'].find((p) => fs.existsSync(p));
    if (!exe) throw new Error('หา Chrome/Edge ไม่เจอ');
    const safeName = (this.cfg.name || ('acct' + this.index)).replace(/[^\w\u0E00-\u0E7F-]/g, '_');
    const userDataDir = path.join(PROFILES_ROOT, safeName);
    if (!fs.existsSync(userDataDir)) fs.mkdirSync(userDataDir, { recursive: true });
    const x = 30 + (this.index % 4) * 40, y = 30 + Math.floor(this.index / 4) * 30;
    const headless = !!this.cfg.headless;
    // ขนาดหน้าต่าง: เดิมบังคับ defaultViewport = ค่า config "ทุกกรณี" → Chrome override device metrics
    //   ให้หน้าเกมเล็กกว่าหน้าต่างจริง แถบล่าง (ปุ่มสกิล/เม็ดเลือด) โดนตัด ต้องลากยืดเองทุกครั้ง
    //   โหมดมีหน้าต่างจึงปล่อย viewport = null ให้ Chrome ใช้ขนาดจริง + เปิดแบบ maximized (บัญชีแรก)
    const winArgs = ['--disable-blink-features=AutomationControlled', '--test-type', '--disable-infobars', '--hide-crash-restore-bubble'];
    if (headless) {
      winArgs.push(`--window-size=${this.viewport.width},${this.viewport.height}`);
    } else if (this.index === 0) {
      winArgs.push('--start-maximized');
    } else {
      winArgs.push(`--window-size=${this.viewport.width},${this.viewport.height}`, `--window-position=${x},${y}`);
    }
    this.browser = await puppeteer.launch({
      executablePath: exe, headless: headless, defaultViewport: headless ? this.viewport : null, userDataDir,
      args: winArgs,
    });
    this.log(headless ? 'เปิดบัญชี (โหมดซ่อนหน้าต่าง/headless)' : 'เปิดบัญชี');
    this.page = (await this.browser.pages())[0] || await this.browser.newPage();
    await this.page.evaluateOnNewDocument(() => { try { Object.defineProperty(navigator, 'webdriver', { get: () => undefined }); } catch (e) {} });
    await this.attachCdp();
    this.page.on('pageerror', (err) => { this.state.lastError = String(err.message).slice(0, 200); });
    // hook สำหรับ adapter: เปิด request interception / patch JS ของเกม / inject script ก่อนโหลดหน้า
    if (typeof GAME.preLaunch === 'function') {
      try { await GAME.preLaunch(this.page, this); } catch (e) { this.log('⚠️ preLaunch: ' + (e.message || e)); }
    }
    try { await this.page.goto(this.gameUrl, { waitUntil: 'domcontentloaded', timeout: 60000 }); this.state.connected = true; }
    catch (e) { this.state.lastError = e.message; }
    if (!headless) {
      // ขยายเต็มจอ "หลังโหลดหน้า" — เรียกตอนเพิ่ง launch แล้ว Chrome ทับด้วยขนาดเดิมจาก session-restore
      await this.maximizeWindow();
      setTimeout(() => { this.maximizeWindow(); }, 1500);
    }
    this.state.running = true;
    this.startWatchers();
    if (this.global.autoFarm && this.global.autoFarm.enabled) this.farmStart();
    return true;
  }

  // ขยายหน้าต่างเกมเต็มจอด้วย CDP: ต้อง "set ขนาดเต็มจอก่อน → ค่อย state:'maximized'"
  // (ส่ง maximize เปล่า ๆ ไม่ขยับ และ --start-maximized ก็ไว้ใจไม่ได้ — ทดสอบจริงทั้งคู่)
  async maximizeWindow() {
    try {
      if (!this.page || !this.page.target) return;
      const cdpW = await this.page.target().createCDPSession();
      const { windowId } = await cdpW.send('Browser.getWindowForTarget');
      const mw = (this.viewport && this.viewport.maxWidth) || 1920;
      const mh = (this.viewport && this.viewport.maxHeight) || 1040;
      await cdpW.send('Browser.setWindowBounds', { windowId, bounds: { left: 0, top: 0, width: mw, height: mh } });
      await new Promise((r) => setTimeout(r, 600));
      await cdpW.send('Browser.setWindowBounds', { windowId, bounds: { state: 'maximized' } });
      await cdpW.detach();
    } catch (e) { this.log('⚠️ ขยายหน้าต่างอัตโนมัติไม่สำเร็จ: ' + (e.message || e)); }
  }

  // ---------- ดักแพ็กเก็ต WebSocket → ให้ adapter ถอดรหัสเป็นค่าผู้เล่น ----------
  async attachCdp() {
    this.cdp = await this.page.createCDPSession();
    await this.cdp.send('Network.enable');
    this.cdp.on('Network.webSocketCreated', () => {});
    const logFrame = (dir, data) => {
      if (RELEASE || this.global.wsLog === false) return;
      // เก็บเฉพาะ frame ข้อความ JSON (Caelmora ใช้ CmLink JSON) — ข้าม binary (MuSocket) + ตัดยาว
      const s = typeof data === 'string' ? data : '';
      if (!s || (s[0] !== '{' && s[0] !== '[')) return;
      try { fs.appendFileSync(path.join(BASE_DIR, 'logs', 'ws-' + this.index + '.jsonl'), JSON.stringify({ t: new Date().toISOString(), dir, len: s.length, data: s.slice(0, 2000) }) + '\n'); } catch (e) {}
    };
    this.cdp.on('Network.webSocketFrameReceived', (ev) => {
      const data = ev.response?.payloadData || '';
      this.state.ws.in++;
      try {
        const gi = GAME.decodeWorldFrame(data);
        if (gi) this.mergeGameInfo(gi);
      } catch (e) {}
      logFrame('in', data);
    });
    this.cdp.on('Network.webSocketFrameSent', (ev) => {
      this.state.ws.out++;
      logFrame('out', ev.response?.payloadData || '');
    });
  }
  mergeGameInfo(gi) {
    const g = this.gameInfo;
    if (!g.selfId && gi.selfId) g.selfId = gi.selfId;
    if (gi.hp != null) g.hp = gi.hp;
    if (gi.sp != null) { g.sp = gi.sp; if (g.sp > g.maxSp) g.maxSp = g.sp; }
    if (gi.mapId) g.mapId = gi.mapId;
    if (gi.maxHp) g.maxHp = gi.maxHp;
    if (gi.name) g.name = gi.name;
    if (gi.job) g.job = gi.job;
    if (gi.lv) g.lv = gi.lv;
  }

  startWatchers() {
    const g = () => this.S();
    // ผู้อ่านค่า + AUTO ยา
    this.timers.push(jitterLoop(async () => {
      if (!this.page) return;
      const s = await this.page.evaluate(GAME.page.readStats).catch(() => null);
      if (!s) return;
      // log ตอนตาย/ฟื้น/เลเวลอัพ/เปลี่ยนแมพ
      const prev = this._lastS || {};
      if (s.dead && !prev.dead) { this.log('☠️ ตาย'); (this._deaths = this._deaths || []).push(Date.now()); }
      if (!s.dead && prev.dead) this.log('✅ ฟื้นแล้ว');
      if (prev.lv != null && s.lv != null && s.lv > prev.lv) this.log('⬆️ เลเวลอัพ → ' + s.lv);
      if (prev.mapId && s.mapId && s.mapId !== prev.mapId) this.log('🧭 ไป ' + (s.zone || s.mapId));
      this._lastS = s;
      this.state.gameStats = s;
      const ap = g().autoPotion;
      if (ap && ap.enabled && !s.dead && s.maxHp > 0) {
        const towns = this.townMaps();
        if (!towns.includes(s.mapId)) {
          const ratio = s.hp / s.maxHp, now = Date.now(); let cd;
          if (ratio <= 0.2) cd = 650 + Math.random() * 400; else if (ratio <= 0.35) cd = 1300 + Math.random() * 700; else cd = (ap.cooldownMs ?? 2500) * (0.85 + Math.random() * 0.4);
          if (ratio <= (ap.threshold ?? 0.5) && now - (this.state.potion.lastAt || 0) > cd) {
            this.state.potion.lastAt = now; this.state.potion.count++;
            const key = ap.key || '1'; this.page.keyboard.down(key).then(() => setTimeout(() => this.page.keyboard.up(key), 50 + Math.random() * 40)).catch(() => {});
          }
        }
      }
    }, 1000, 0.3));
    // ผู้เฝ้า AUTO
    this.timers.push(jitterLoop(async () => {
      const aw = g().autoWatch; if (!aw || aw.enabled === false) return;
      // กันวนลูปตาย: ถ้าตาย >=3 ครั้งใน 3 นาที = หยุดกด AUTO ชั่วคราว (ยาหมด/แมพโหดเกิน)
      const now = Date.now();
      this._deaths = (this._deaths || []).filter((t) => now - t < 3 * 60000);
      if (this._deaths.length >= 3) {
        if (!this._pauseLogged || now - this._pauseLogged > 60000) { this._pauseLogged = now; this.log('⚠️ ตายบ่อย — หยุด AUTO ชั่วคราว 3 นาที (เติมยา/เปลี่ยนแมพที่เบาขึ้น)'); }
        return;
      }
      const towns = this.townMaps();
      const st = await this.page.evaluate(GAME.page.probeAuto).catch(() => null);
      if (!st || !st.online || !st.hasPlayer || st.dead || st.on || st.traveling || towns.includes(st.mapId)) return;
      await this.page.evaluate(GAME.page.enableAuto);
      this.state.autoWatch.count++;
    }, 5000, 0.3));
    // จำ map ล่าสุด + กลับเมืองเมื่อกระเป๋าเต็ม
    this.timers.push(jitterLoop(async () => {
      const s = await this.readGame(); if (!s) return;
      if (!s.inTown && !s.traveling && !s.dead && s.mapId && (!this.state.lastFarmMap || this.state.lastFarmMap.id !== s.mapId)) this.state.lastFarmMap = { id: s.mapId, name: s.mapName };
    }, 8000, 0.3));
    this.timers.push(jitterLoop(async () => {
      const at = g().autoTown; if (!at || !at.enabled || !(at.fullPct > 0)) return;
      const s = await this.readGame(); if (!s || s.dead || s.traveling || s.inTown) return;
      if (s.pct >= at.fullPct) this.runCycle();
    }, 15000, 0.3));
    // ผู้เฝ้าซื้อยา: ยาใกล้หมด → กลับเมืองไปซื้อ → กลับฟาร์ม
    this.timers.push(jitterLoop(async () => {
      const bp = g().buyPotion; if (!bp || !bp.enabled) return;
      const gs = this.state.gameStats; if (!gs || !gs.name) return; // ยังไม่เข้าเกม
      const hp = gs.potions || 0, sp = gs.spPotions || 0;
      const needHp = bp.hp && bp.hp.on && hp < (bp.hp.min || 0);
      const needSp = bp.sp && bp.sp.on && sp < (bp.sp.min || 0);
      if (!needHp && !needSp) return;
      if (this._cycleBusy) return;
      this.runBuyCycle(needHp, needSp);
    }, 20000, 0.25));
    // เชื่อมต่อใหม่ + เลือกตัวละคร + ติดตามเดินทาง + title
    // ⚠️ autoLogin ต้องเปิดใน config เท่านั้น (default ปิด) — กันบอทกด Guest เองตอนผู้ใช้จะล็อกอินปกติ
    this.timers.push(jitterLoop(async () => {
      const al = g().autoLogin;
      if (al && al.enabled) {
        const st = await this.page.evaluate(GAME.page.probeReconnect).catch(() => null);
        if (st) {
          if (st.ss) await this.page.evaluate(GAME.page.clickServer, { guest: !!al.guest, user: al.user || '', pass: al.pass || '' }).catch(() => {});
          else if (st.cs) {
            const want = (g().enterCharacter && g().enterCharacter.enabled) ? String(g().enterCharacter.name || '').trim() : '';
            await this.page.evaluate(GAME.page.enterCharacter, want).catch(() => {});
          }
        }
      }
      const t = await this.page.evaluate(GAME.page.probeTravel).catch(() => null);
      if (t) { this.state.traveling = t.on; this.state.travelNote = t.note; }
      try { this.state.pageTitle = await this.page.title(); this.state.connected = !this.page.isClosed(); } catch (e) { this.state.connected = false; }
    }, 3000, 0.3));
    // 🚢 Voyage Farm Loop — วนถี่ขึ้นตอนอยู่บนเกาะ (ตัว roam จริงรันในหน้าเกมทุก 1.5 วิ)
    this.timers.push(jitterLoop(async () => {
      const vf = g().voyFarm; if (!vf || !vf.enabled) return;
      await this.voyFarmStep();
    }, 8000, 0.25));
  }

  async readGame() {
    return this.page.evaluate(GAME.page.readState, this.townMaps()).catch(() => null);
  }

  humanWait(base) { const hd = this.S().humanDelay; if (hd && hd.enabled !== false && hd.minSec > 0) { const mn = hd.minSec * 1000, mx = Math.max(mn, (hd.maxSec || hd.minSec) * 1000); return mn + Math.random() * (mx - mn); } return base; }

  async farmLoop() {
    while (this.state.farmOn) {
      const actions = (this.S().autoFarm && this.S().autoFarm.actions) || [];
      for (const act of actions) {
        if (!this.state.farmOn) break;
        try {
          if (act.type === 'key') { await this.page.keyboard.down(act.key); await sleep(55 + Math.random() * 40); await this.page.keyboard.up(act.key); }
          else if (act.type === 'click') { await this.page.mouse.move(act.x + (Math.random() * 8 - 4), act.y + (Math.random() * 8 - 4)); await sleep(50 + Math.random() * 50); await this.page.mouse.down(); await sleep(50 + Math.random() * 40); await this.page.mouse.up(); }
        } catch (e) { this.state.lastError = e.message; }
        await sleep(this.humanWait(act.intervalMs || 1000));
      }
      if (!actions.length) await sleep(1000);
    }
  }
  farmStart() { if (this.state.farmOn || !this.page) return { ok: false, msg: 'ไม่พร้อม' }; if (!(this.S().autoFarm.actions || []).length) return { ok: false, msg: 'ยังไม่มีคำสั่งฟาร์ม' }; this.state.farmOn = true; this.log('▶️ เริ่มฟาร์ม (กดสกิลอัตโนมัติ)'); this.farmLoop(); return { ok: true, msg: 'เริ่มฟาร์มแล้ว' }; }
  farmStop() { this.state.farmOn = false; this.log('⏹ หยุดฟาร์ม'); return { ok: true, msg: 'หยุดฟาร์มแล้ว' }; }

  async goTown() { const r = await this.page.evaluate(GAME.page.goTown).catch((e) => ({ ok: false, msg: e.message })); if (r.ok) this.log('🏠 ' + r.msg); return r; }
  async warpTo(id) { const r = await this.page.evaluate(GAME.page.warpTo, id).catch((e) => ({ ok: false, msg: e.message })); if (r.ok) this.log('🔥 ' + r.msg); return r; }
  async approachShop() { await this.page.evaluate(GAME.page.approachShop).catch(() => {}); }

  async sellPreview() { try { return await this.page.evaluate(GAME.page.analyzeSell, this.S().sellConfig || {}); } catch (e) { return { error: e.message }; } }
  async sellRun(what) { try { const r = await this.page.evaluate(GAME.page.sellExecute, GAME.page.analyzeSell.toString(), this.S().sellConfig || {}, what || 'all'); if (r.ok) this.log('💰 ' + r.msg); return r; } catch (e) { return { ok: false, msg: e.message }; } }

  // ซื้อยาที่ร้าน: ต้องใกล้ NPC → วนซื้อจนครบ
  async buyPotionsInShop(needHp, needSp) {
    const bp = this.S().buyPotion || {};
    const plan = [];
    if (needHp && bp.hp) plan.push({ pid: bp.hp.size || GAME.POTION.hp.size, n: bp.hp.buy || 100 });
    if (needSp && bp.sp) plan.push({ pid: bp.sp.size || GAME.POTION.sp.size, n: bp.sp.buy || 100 });
    if (!plan.length) return { ok: false, msg: 'ไม่ได้เลือกยาที่จะซื้อ' };
    return this.page.evaluate(GAME.page.buyPotions, plan).catch((e) => ({ ok: false, msg: e.message }));
  }

  async runCycle() {
    if (this._cycleBusy) return; this._cycleBusy = true;
    try {
      let s = await this.readGame();
      if (s && !s.inTown) await this.goTown();
      for (let i = 0; i < 100; i++) { await sleep(3000); s = await this.readGame(); if (s && s.inTown && !s.traveling) break; }
      s = await this.readGame(); if (s && s.inTown && !s.nearShop) { await this.approachShop(); for (let i = 0; i < 40; i++) { await sleep(2500); s = await this.readGame(); if (s && s.nearShop) break; } }
      await sleep(1500);
      const cfg = this.S().sellConfig || {};
      if (cfg.materials && cfg.materials.enabled) await this.sellRun('mats');
      if (cfg.gear && cfg.gear.enabled) await this.sellRun('gear');
      const t = this.state.lastFarmMap || (this.cfg.farmMap ? { id: this.cfg.farmMap } : null);
      if (t && t.id) await this.warpTo(t.id);
    } catch (e) { this.state.lastError = e.message; } finally { this._cycleBusy = false; }
  }

  async runBuyCycle(needHp, needSp) {
    if (this._cycleBusy) return; this._cycleBusy = true;
    try {
      this.log('💊 ยาใกล้หมด → กลับเมืองไปซื้อ');
      let s = await this.readGame();
      if (s && !s.inTown) await this.goTown();
      for (let i = 0; i < 100; i++) { await sleep(3000); s = await this.readGame(); if (s && s.inTown && !s.traveling) break; }
      s = await this.readGame(); if (s && s.inTown && !s.nearShop) { await this.approachShop(); for (let i = 0; i < 40; i++) { await sleep(2500); s = await this.readGame(); if (s && s.nearShop) break; } }
      await sleep(1500);
      const r = await this.buyPotionsInShop(needHp, needSp);
      this.log(r.ok ? ('✅ ซื้อยาแล้ว ' + r.bought + ' ขวด (-' + (r.spent || 0).toLocaleString() + ' เหรียญ)') : ('⚠️ ซื้อยาไม่สำเร็จ: ' + r.msg));
      const t = this.state.lastFarmMap || (this.cfg.farmMap ? { id: this.cfg.farmMap } : null);
      if (t && t.id) await this.warpTo(t.id);
    } catch (e) { this.state.lastError = e.message; } finally { this._cycleBusy = false; }
  }

  // ---------- 🚢 Voyage Farm Loop ----------
  // config.voyFarm = { enabled, isle (node), tier (สมุดเป้าหมาย 2..15), bagPct, minZen, lootSeconds (วิ: เก็บของหลังบอสตายกี่วิค่อยออกเกาะ) }
  // ตัวเลือกที่ส่งเข้าตัวเดินในหน้าเกม (รวม src ของกฎกรองของด้วย)
  roamOpts(vf) {
    const v = vf || this.S().voyFarm || {};
    return {
      filter: this.S().lootFilter || { mode: 'game' },
      mode: v.mode || 'hunt',
      bagPct: v.bagPct || 85,
      minZen: v.minZen || 0,
      lootSec: +v.lootSeconds || 15,
      lfSrc: LF_SRC,
    };
  }
  voyFarmStop(reason) {
    const g = this.getGlobal();
    if (g.voyFarm) g.voyFarm.enabled = false;
    const acc = (g.accounts || [])[this.index];
    if (acc && acc.settings && acc.settings.voyFarm) acc.settings.voyFarm.enabled = false;
    try { this.saveFn(); } catch (e) {}
    this.log('⏹ หยุดวงวน Voyage: ' + reason);
  }
  async voyFarmStep() {
    if (this._voyBusy || this._cycleBusy) return;
    if (!this.page || this.page.isClosed()) return;
    this._voyBusy = true;
    try {
      const vf = this.S().voyFarm || {};
      const tier = Math.max(1, Math.min(15, vf.tier | 0 || 15));
      const node = vf.isle | 0;
      if (!node) { this.voyFarmStop('ยังไม่ได้เลือกเกาะปลายทาง'); return; }
      const P = (fn, arg) => this.page.evaluate(fn, arg).catch((e) => ({ error: e.message }));
      let d = await P(GAME.page.voyagePanel);
      if (!d || d.error) { this.log('⚠️ Voyage: ยังไม่พร้อม (' + ((d && (d.error || d.msg)) || 'ไม่มีข้อมูล') + ')'); return; }

      // === ขา 1: อยู่บนเกาะ → kick ตัวเดินต่อเนื่องในหน้าเกม (tick 1.5 วิ) แล้วเก็บ log มาแสดง ===
      if (d.onIsle) {
        const rs = await P(GAME.page.voyRoamStart, this.roamOpts(vf));
        if (rs && rs.msg) this.log(rs.msg);
        const rl = await P(GAME.page.voyRoamLog);
        if (Array.isArray(rl)) rl.forEach((x) => x && this.log(x)); else if (rl) this.log(rl);
        if (vf.minZen > 0 && d.zen != null && d.zen < vf.minZen) this.voyFarmStop('เงินเหลือ ' + d.zen.toLocaleString());
        return;
      }

      // === ขา 2: ต้องอยู่ map ที่มีโต๊ะ (เมือง 0/2) — ติดบนเกาะ/ที่อื่น → วาร์ปกลับก่อน ===
      if (d.map != null && d.map !== '0' && d.map !== '2' && d.map !== 0 && d.map !== 2) {
        this.log('🧭 ไม่ได้อยู่เมือง (map ' + d.map + ') → วาร์ปกลับ Solhaven ก่อน');
        await this.warpTo('2');
        await sleep(8000);
      }
      d = await P(GAME.page.voyagePanel); if (!d || d.error) return;

      // === ขา 2.5: กระเป๋าเต็ม → เดินไปฝากของกับ "คาฟี ผู้ดูแลคลัง" (แทนที่จะเลิกวน) ===
      const keepEach = Math.max(0, +vf.keepOrbCount || 20);
      const KEEP_ORBS = { 11778: keepEach, 11779: keepEach, 11781: keepEach, 11782: keepEach }; // ปลุกพลัง/เสริมพลัง/เลื่อนขั้น/นักปราชญ์
      const bpct = (d.bag && d.bag.pct) || 0;
      const fullAt = vf.bagPct || 85;
      if (bpct >= fullAt) {
        this.log('📦 กระเป๋าเต็ม ' + bpct + '% (' + d.bag.used + '/' + d.bag.cap + ' ช่อง) → ไปฝากที่คาฟี เหลือออร์บไว้ใช้อย่างละ ' + keepEach);
        const dep = await P(GAME.page.stashDeposit, { keep: KEEP_ORBS, tab: 0, lfSrc: LF_SRC });
        const depMsg = (dep && dep.msg) || 'ไม่ได้รับคำตอบจากการฝากของ';
        String(depMsg).split('\n').forEach((ln, i) => { if (ln.trim()) this.log((i === 0 ? '📦 ' : '') + ln.trim()); });
        if (!dep || !dep.done) return; // ยังเดินไปหา NPC / เปิดหน้าคลัง → ทำต่อรอบถัดไป
        d = await P(GAME.page.voyagePanel); if (!d || d.error) return;
        const pctNow = (d.bag && d.bag.pct) || 0;
        if (pctNow >= 95) { this.voyFarmStop('กระเป๋าเกือบเต็ม ' + pctNow + '% และฝากเพิ่มไม่ได้ — ต้องเคลียร์คลัง/ซื้อแผ่นคลังก่อน'); return; }
        if (pctNow >= fullAt) this.log('⚠️ ฝากได้บางส่วน กระเป๋ายังอยู่ ' + pctNow + '% — จะลองฝากใหม่รอบถัดไป');
      }

      // === ขา 3: หา/สร้างสมุดอันดับเป้าหมาย ===
      // หมายเหตุสำคัญ: "รวมสมุด" ของเกมกิน 3 เล่มที่ **อันดับเดียวกันและความหายากเดียวกัน**
      // และร้านขายแต่แบบ "ปกติ" (rar 0) → นับรวมข้ามความหายากไม่ได้เด็ดขาด (เคยทำให้ซื้อเกิน+รวมไม่ออกวนลูป)
      const RAR = ['ปกติ', 'เมจิก', 'แรร์', 'Unique'];
      const need = d.trade || 3;
      const scan = () => {
        const cs = (d && d.charts) || [];
        const g = {};
        for (const c of cs) { const k = (c.tier | 0) + '|' + (c.r | 0); (g[k] = g[k] || []).push(c); }
        const groups = Object.keys(g).map((k) => { const p = k.split('|').map(Number); return { tier: p[0], r: p[1], n: g[k].reduce((a, c) => a + (c.n || 1), 0) }; });
        // เลือกลำดับความสำคัญ: อันดับ "สูงกว่าหรือเท่าที่ตั้งไว้" ก่อน (มี 15 ในกระเป๋า = ใช้ 15 ไม่ต้องซื้อ 14)
        return { cs, groups, best: GAME.pickChart(cs, tier) };
      };
      const logCharts = (tag) => {
        const cs = scan().cs;
        this.log('🧾 ' + tag + ': ' + (cs.length ? cs.map((c) => `อันดับ ${c.tier} ×${c.n || 1} [${RAR[c.r | 0] || 'r' + (c.r | 0)}]`).join(' + ') : 'ไม่มีสมุดในกระเป๋า'));
      };
      logCharts('สมุดในกระเป๋าตอนถึงโต๊ะ');

      // ร้านขายสมุดได้ถึงอันดับ d.buy (=14) → ซื้อตรงเล่มเดียวจบ
      // การ "รวม" เป็นการเสี่ยงดวง แพ้=เสีย 3 เล่ม จึงใช้เฉพาะอันดับที่ร้านไม่ขาย (15) เท่านั้น
      const BUY_MAX = d.buy || 14;
      let s = scan();
      let chart = s.best;
      if (!chart && tier <= BUY_MAX) {
        const unit = (d.prices && d.prices[tier - 1]) || 0;
        if (vf.minZen > 0 && d.zen != null && d.zen - unit < vf.minZen) { this.voyFarmStop('เงินไม่พอซื้อสมุดอันดับ ' + tier + ' (เหลือ ' + (d.zen || 0).toLocaleString() + ' ต้องใช้ ' + unit.toLocaleString() + ')'); return; }
        this.log('🛒 ซื้อสมุดอันดับ ' + tier + ' ตรง ๆ (' + unit.toLocaleString() + ' Zen) — ร้านขายถึงอันดับ ' + BUY_MAX + ' ไม่ต้องเสี่ยงรวม');
        await P(GAME.page.voyAction, { what: 'buy', tier });
        for (let w = 0; w < 6; w++) { // รอของเข้ากระเป๋าจริง
          await sleep(1600);
          d = await P(GAME.page.voyagePanel); if (!d || d.error) continue;
          s = scan(); chart = s.best;
          if (chart) break;
        }
        if (!chart) { this.voyFarmStop('ซื้อสมุดอันดับ ' + tier + ' ไม่เข้ากระเป๋า (เซิร์ฟไม่ตอบ — อาจติด limit รายวัน)'); return; }
        logCharts('หลังซื้อ');
      } else if (!chart) {
        const mixed = s.groups.filter((x) => x.tier === tier - 1);
        if (mixed.length > 1) this.log('ℹ️ มีสมุดอันดับ ' + (tier - 1) + ' ปนกันหลายความหายาก (' + mixed.map((x) => RAR[x.r] + ' ×' + x.n).join(', ') + ') — จะนับ/ซื้อเติมเฉพาะแบบปกติ');
        // กลุ่มที่รวมได้ทันที (ครบ need) — เอาความหายากสูงสุดก่อน
        let ready = s.groups.filter((x) => x.tier === tier - 1 && x.n >= need).sort((a, b) => b.r - a.r)[0] || null;
        // ยังไม่ครบ → ซื้อเติมลงกลุ่ม "ปกติ" (rar 0) เพราะร้านขายแบบเดียว
        let topUp = ready || s.groups.filter((x) => x.tier === tier - 1 && x.r === 0)[0] || { tier: tier - 1, r: 0, n: 0 };
        let attempts = 0;
        while (!chart && attempts++ < 8) {
          let have = topUp.n;
          if (have < need) {
            const unit = (d.prices && d.prices[tier - 2]) || 0;
            let buyFail = 0;
            while (have < need && buyFail < 3) {
              if (vf.minZen > 0 && d.zen != null && d.zen - unit < vf.minZen) { this.voyFarmStop('เงินไม่พอซื้อสมุด (เหลือ ' + d.zen.toLocaleString() + ')'); return; }
              this.log('🛒 ซื้อสมุดอันดับ ' + (tier - 1) + ' แบบปกติ (' + have + '/' + need + ')' + (attempts > 1 ? ' [ลองครั้งที่ ' + attempts + ']' : ''));
              await P(GAME.page.voyAction, { what: 'buy', tier: tier - 1 });
              const prev = have;
              for (let w = 0; w < 5; w++) { // รอของเข้ากระเป๋าจริงก่อน (เซิร์ฟช้าได้) กันซื้อเกิน
                await sleep(1600);
                d = await P(GAME.page.voyagePanel); if (!d || d.error) continue;
                have = scan().groups.filter((x) => x.tier === tier - 1 && x.r === 0).reduce((a, x) => a + x.n, 0);
                if (have > prev) break;
              }
              if (have <= prev) buyFail++;
            }
            if (have < need) { this.voyFarmStop('ซื้อสมุดไม่ผ่าน (เซิร์ฟไม่ตอบ — อาจติด limit รายวัน)'); return; }
          }
          logCharts('ก่อนรวมสมุด');
          this.log('🎲 รวมสมุดอันดับ ' + (tier - 1) + ' ×' + need + ' [แบบ' + RAR[topUp.r] + '] → อันดับ ' + tier + ' (เสี่ยงดวงครั้งที่ ' + attempts + ')');
          await P(GAME.page.voyAction, { what: 'trade', tier: tier - 1 });
          for (let w = 0; w < 8; w++) { // เซิร์ฟตอบ trade ช้าได้ — poll สูงสุด ~15 วิ
            await sleep(2000);
            d = await P(GAME.page.voyagePanel); if (!d || d.error) continue;
            s = scan(); chart = s.best;
            if (chart) break;
          }
          if (!chart) {
            logCharts('หลังรวม (ดวงไม่ออก)');
            this.log('🎲 รวมไม่สำเร็จ ซื้อใหม่ลองอีกที');
            s = scan();
            topUp = s.groups.filter((x) => x.tier === tier - 1 && x.r === 0)[0] || { tier: tier - 1, r: 0, n: 0 };
          }
        }
        if (!chart) { this.voyFarmStop('รวมสมุด ' + (attempts - 1) + ' ครั้งไม่ผ่านเลย (ซวยจริง) — เติมเงินแล้วเปิดใหม่'); return; }
      }

      // === ขา 4: พยายามอัปเป็นแรร์ — ทำไม่ได้ให้ลงเรือตามสภาพ (ห้ามหยุดวงวน ห้ามวนลูป) ===
      if ((chart.r | 0) < 2) {
        const o = d.orbs || {};
        // มีแค่ "เลื่อนขั้น" ตัวเดียวที่เปลี่ยน เมจิก → แรร์ (ปลุกพลัง/เสริมพลังช่วยไม่ได้)
        if (!(o.ascension >= 1)) {
          this.log('⚠️ ไม่มีออร์บเลื่อนขั้นในกระเป๋า → ลงเรือด้วยสมุดอันดับ ' + chart.tier + ' แบบ ' + (RAR[chart.r | 0] || chart.r) + ' ก่อน (มีแต่ปลุกพลัง/เสริมพลังอัปเป็นแรร์ไม่ได้)');
        } else {
          this.log('✨ ใช้ออร์บอัปสมุดอันดับ ' + chart.tier + ' → แรร์ (เลื่อนขั้นในกระเป๋า ' + (o.ascension || 0) + ' เม็ด)');
          const orbRes = await P(GAME.page.voyAction, { what: 'orb', s: chart.slot });
          this.log('✨ ' + ((orbRes && orbRes.msg) || 'ไม่มีผลตอบ'));
          await sleep(2000);
          d = await P(GAME.page.voyagePanel);
          if (d && !d.error) { s = scan(); if (s.best) chart = s.best; }
          if ((chart.r | 0) < 2) this.log('⚠️ อัปเป็นแรร์ไม่สำเร็จ (rar=' + (chart.r | 0) + ') — จะลงเรือตามที่มี ไม่หยุดวงวน');
        }
      }
      if (chart && (chart.tier | 0) > tier) this.log('📈 ใช้สมุดอันดับ ' + chart.tier + ' ที่มีอยู่ในกระเป๋า (สูงกว่าที่ตั้งไว้ ' + tier + ') — ประหยัดไม่ต้องซื้อใหม่');
      logCharts('สมุดที่จะใช้ลงเรือ');

      // === ขา 5: ออกเดินทาง ===
      this.log('🚢 ออกเดินทาง → เกาะ node ' + node + ' (สมุดอันดับ ' + chart.tier + ' แบบ ' + (RAR[chart.r | 0] || chart.r) + ')');
      const r = await P(GAME.page.voyAction, { what: 'sail', node, s: chart.slot });
      if (r && r.ok === false) this.log('⚠️ ' + r.msg);
      else setTimeout(() => { // ถึงเกาะแล้วเริ่มเดินทันที (ตรวจ onIsle ก่อน ไม่งั้นห้าม kick)
        this.page.evaluate(GAME.page.voyagePanel).then((on) => {
          if (on && on.onIsle) {
            return this.page.evaluate(GAME.page.voyRoamStart, this.roamOpts(this.S().voyFarm));
          }
        }).catch(() => {});
      }, 5000);
    } catch (e) { this.state.lastError = e.message; } finally { this._voyBusy = false; }
  }

  async command(action, payload) {
    if (!this.page) return { ok: false, msg: 'บัญชียังไม่พร้อม' };
    if (action === 'farm-on') return this.farmStart();
    if (action === 'farm-off') return this.farmStop();
    if (action === 'town') return this.goTown();
    if (action === 'farmmap') return this.warpTo(payload.map);
    if (action === 'cycle-now') { this.runCycle(); return { ok: true, msg: 'เริ่มรอบขาย' }; }
    if (action === 'reload') { if (isDevOnly('reload')) return { ok: false, msg: 'ปิดใช้ในเวอร์ชันนี้' }; await this.page.reload({ waitUntil: 'domcontentloaded' }).catch(() => {}); return { ok: true, msg: 'รีเฟรชแล้ว' }; }
    if (action === 'dump-dom') { if (isDevOnly('dumpcode')) return { ok: false, msg: 'ปิดใช้ในเวอร์ชันนี้' }; const h = await this.page.content(); fs.writeFileSync(path.join(BASE_DIR, 'logs', 'dom-' + this.index + '.html'), h); return { ok: true, msg: 'ดึงโค้ดเกมแล้ว' }; }
    if (action === 'ws-clear') { if (isDevOnly('clearstats')) return { ok: false, msg: 'ปิดใช้ในเวอร์ชันนี้' }; return { ok: true, msg: 'ล้างสถิติแล้ว' }; }
    return { ok: false, msg: 'คำสั่งไม่ถูกต้อง' };
  }

  async screenshot() { if (isDevOnly('view') || !this.page) return null; try { return await this.page.screenshot({ type: 'png' }); } catch (e) { return null; } }

  status() {
    const s = this.state;
    return {
      index: this.index, name: s.name, enabled: s.enabled, running: s.running, connected: s.connected,
      pageTitle: s.pageTitle, farmOn: s.farmOn, ws: s.ws, gameStats: s.gameStats, traveling: s.traveling,
      travelNote: s.travelNote, lastFarmMap: s.lastFarmMap, lastError: s.lastError, headless: !!this.cfg.headless,
      autoWatch: { count: s.autoWatch.count }, potion: { count: s.potion.count },
      settings: this.cfg.settings || null, log: this.logs.slice(-40),
      uptimeSec: Math.floor((Date.now() - s.startedAt) / 1000),
    };
  }

  async stop() { this.timers.forEach((stop) => { try { stop(); } catch (e) {} }); this.timers = []; this.state.farmOn = false; this.state.running = false; try { if (this.browser) await this.browser.close(); } catch (e) {} this.browser = null; this.page = null; }
}

module.exports = { Account };
